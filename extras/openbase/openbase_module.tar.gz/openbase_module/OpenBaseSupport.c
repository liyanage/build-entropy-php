/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

int copyIntoArray(char *array[],char *values, int *maxinit);
int copyString(unsigned char **tostring, int *tosize, int position, const char *str, int length);
int copyToIndex(char **tostring, int *tosize, int position, const char *str, const char tochar, int *isDone);
int copyBytes(char *destination, const char *source, int size);

int copyIntoArray(char *array[],char *values, int *maxinit)
{
    int ct = 0;
    char *deststr, *sourcestr;

    if (!array[0] || (*maxinit == 0)) {
        array[0] = (char *)malloc(64);
        if (*maxinit == 0) *maxinit = 1;
    }
    //printf("copyIntoArray -> %s\n", values);
    
    deststr = array[0];
    sourcestr = values;
    while (*sourcestr!='\0') {
        if (*sourcestr == '|') {
            *deststr = '\0';
            ct = ct + 1;
            if (!array[ct] || (*maxinit <= ct)) {
                array[ct] = (char *)malloc(64);
                if (*maxinit < ct) *maxinit = *maxinit + 1;
            }
            deststr = array[ct];
        } else {
            *deststr = *sourcestr; deststr++;
        }
        sourcestr = sourcestr + 1;
    }
    *deststr = '\0';
    ct = ct + 1;

    return ct;
}

int copyString(unsigned char **tostring, int *tosize, int position, const char *str, int length)
{
    int ct = 0;
    char *strdest;
    int newlength;

    newlength = 0;
    strdest = (char*)*tostring + position;
    while (ct < length) {
    	if (*str == '\0')
    	{
    		 *strdest = '\\';
    		 *(strdest+1) = '0';
    		 strdest += 2;
    		 newlength += 2;
    	}
    	else
    	{
	        *strdest = *str; strdest++; newlength++;
		}
        if ((newlength + position) > (*tosize - 5)) {
            *tosize = *tosize * 2;
            *tostring = (unsigned char*)realloc(*tostring, *tosize);
            strdest = (char*)*tostring + newlength + position;
        }
        ct++; str++;
    }
    *strdest = '\0';
    return newlength;
}

int copyToIndex(char **tostring, int *tosize, int position, const char *str, const char tochar, int *isDone)
{
    int ct = 0;
    char *strdest;
    int newlength;

    newlength = 0;
    *isDone = 0;
    strdest = *tostring;
    str = str + position;
    while (tochar != *str) {
        if (*str == '\0') {
            *isDone = 1;
            break;
        }
        *strdest = *str; strdest++; newlength++;
        if (newlength > (*tosize - 5)) {
            *tosize = *tosize * 2;
            *tostring = (char*)realloc(*tostring, *tosize);
            strdest = *tostring + newlength;
        }
        ct++; str++;
    }
    *strdest = '\0';
    return newlength;
}

int copyBytes(char *destination, const char *source, int size)
{
    int ct;
    
    for (ct = 0; ct < size; ct++) {
        *destination = *source;
        destination++; source++;
    }
    return 1;
}

