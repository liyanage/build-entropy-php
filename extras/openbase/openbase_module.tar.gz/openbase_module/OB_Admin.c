/*
	OB_Admin.c
	OpenBase Unified Client
	�1996-2002 OpenBase International, Ltd.
	All rights reserved
	
	Derived from CommAPI.c in old client.

	Disclaimer:
	-----------
	THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF 
	ANY KIND, EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT 
	LIMITATION THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF 
	THIS SOFTWARE. OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY 
	DEFECT IN, THIS SOFTWARE. IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, 
	SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE 
	POSSIBILITY OF SUCH DAMAGE.

	WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE 
	OPENBASE API SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#ifdef __cplusplus
extern "C" {
#endif

//================================================================================
//	Includes
//================================================================================

	#ifndef _OB_ADMIN_H
	#include "OB_Admin.h"
	#endif
	
	#ifndef _OB_COMMUNICATIONS_H
	#include "CommAPI.h"
	#endif

	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	
//================================================================================
//	Implementations
//================================================================================

//--------------------------------------------------------------------------------
//	oba_newAdminConnection
//--------------------------------------------------------------------------------

OpenBaseAdminConnection* oba_newAdminConnection(const char *hostName)
{
	OpenBaseAdminConnection* result = NULL;

	result = (OpenBaseAdminConnection *) malloc(sizeof(OpenBaseAdminConnection));
	if (result != NULL)
	{
    	result->connection = ob_newNetConn();
    	if (!ob_connectToPort(result->connection, 20221, hostName))
    	{
			oba_deallocAdminConnection(result);
			result = NULL;
    	}
	}

	return result;
}

//--------------------------------------------------------------------------------
//	oba_deallocAdminConnection
//--------------------------------------------------------------------------------

void oba_deallocAdminConnection(OpenBaseAdminConnection* admin_conn)
{
	if (admin_conn != NULL)
	{
		ob_sendExitSignal(admin_conn->connection);
		
		ob_deallocNetConn(admin_conn->connection);
		admin_conn->connection = NULL;
		
		free(admin_conn);
	}
}

//--------------------------------------------------------------------------------
//	oba_getDatabaseList
//--------------------------------------------------------------------------------

OpenBaseDatabaseList* oba_getDatabaseList(OpenBaseAdminConnection* admin_conn, const char* group_code)
{
	OpenBaseDatabaseList* result = NULL;
	int i;
	const char* database_list = NULL;
	int len;
	
	if (admin_conn != NULL)
	{
		result = (OpenBaseDatabaseList*) malloc(sizeof(OpenBaseDatabaseList));
		if (result != NULL)
		{
			for (i = 0; i < OB_MAX_DATABASES; i++)
			{
				result->databases[i] = NULL;
				result->hosts[i] = NULL;
				result->keys[i] = NULL;
			}
			result->databaseCount = 0;
			
			//	now send the request and process it.
			ob_prepareDictionary(admin_conn->connection);
			ob_addDictionaryPair(admin_conn->connection, "action", "databaseListForHost7");
			
			//	does it need an ip address?? ouch!
			//	ob_addDictionaryPair(admin_conn->connection, "ipaddress", "");
			
			if ((group_code != NULL) && (strcmp(group_code, "") != 0))
			{
				ob_addDictionaryPair(admin_conn->connection, "groupcode", group_code);
			}
			
			if (ob_sendBuffer(admin_conn->connection))
			{
				YIELD_THREAD;
				if (ob_readResult(admin_conn->connection))
				{
					database_list = ob_resultValueForKey(admin_conn->connection, "data", &len);
				}
			}
			
			if (database_list != NULL)
			{
				const char* delimiters = " \t\r\n(){};,=";
				int index = 0;
				
				//	format should be an array of dictionaries
				const char* key = strtok((char*) database_list, delimiters);
				while (key != NULL)
				{
					const char* value = strtok(NULL, delimiters);
					if (value != NULL)
					{
						if (strcmp(key, "databaseName") == 0)
						{
							if (result->databases[index] != NULL)
							{
								index++;
							}
							if (index < OB_MAX_DATABASES)
							{
								result->databases[index] = malloc(strlen(value) + 1);
								if (result->databases[index] != NULL)
								{
									strcpy(result->databases[index], value);
								}
							}
						}
						else if (strcmp(key, "hostName") == 0)
						{
							if (result->hosts[index] != NULL)
							{
								index++;
							}
							if (index < OB_MAX_DATABASES)
							{
								result->hosts[index] = malloc(strlen(value) + 1);
								if (result->hosts[index] != NULL)
								{
									strcpy(result->hosts[index], value);
								}
							}
						}
						else if (strcmp(key, "key") == 0)
						{
							if (result->keys[index] != NULL)
							{
								index++;
							}
							if (index < OB_MAX_DATABASES)
							{
								result->keys[index] = malloc(strlen(value) + 1);
								if (result->keys[index] != NULL)
								{
									strcpy(result->keys[index], value);
								}
							}
						}
					}
					key = strtok(NULL, delimiters);	
				}
				
				result->databaseCount = index + 1;
				
				/*
				//	This just gets the raw data
				
				result->databases[0] = malloc(strlen(database_list) + 1);
				if (result->databases[0] != NULL)
				{
					strcpy(result->databases[0], database_list);
					result->databaseCount = 1;
				}
				*/
			}
		}
	}
	
	return result;
}
	
//--------------------------------------------------------------------------------
//	oba_deallocDatabaseList
//--------------------------------------------------------------------------------

void oba_deallocDatabaseList(OpenBaseDatabaseList* database_list)
{
	int i;
	
	if (database_list != NULL)
	{
		for (i = 0; i < database_list->databaseCount; i++)
		{
			DEALLOC(database_list->databases[i]);
			DEALLOC(database_list->hosts[i]);
			DEALLOC(database_list->keys[i]);
		}
		free(database_list);
	}
}

//--------------------------------------------------------------------------------
//	oba_addDatabaseToGroupCode
//--------------------------------------------------------------------------------

int oba_addDatabaseToGroupCode(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *groupCode, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
	ob_prepareDictionary(adminConnection->connection);
	ob_addDictionaryPair(adminConnection->connection, "action", "addDatabaseToHostCode");
	ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
	ob_addDictionaryPair(adminConnection->connection, "password", password);
	ob_addDictionaryPair(adminConnection->connection, "hostCode", groupCode);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_startDatabase
//--------------------------------------------------------------------------------

int oba_startDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "startDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    ob_addDictionaryPair(adminConnection->connection, "callBack", "");
    ob_addDictionaryPair(adminConnection->connection, "callbackHost", "");
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_newDatabase
//--------------------------------------------------------------------------------

int oba_newDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "newDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_duplicateDatabase
//--------------------------------------------------------------------------------

int oba_duplicateDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *duplicatedName,  const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "duplicateDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
    ob_addDictionaryPair(adminConnection->connection, "duplicatedName", duplicatedName);
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_renameDatabase
//--------------------------------------------------------------------------------

int oba_renameDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *newDatabaseName, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "renameDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
    ob_addDictionaryPair(adminConnection->connection, "newName", newDatabaseName);
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_moveDatabase
//--------------------------------------------------------------------------------

int oba_moveDatabase(OpenBaseAdminConnection *adminConnection, const char *sourceDatabaseName, const char *sourcePassword, const char *targetHost, const char *targetHostPassword)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "moveDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", sourceDatabaseName);
    ob_addDictionaryPair(adminConnection->connection, "sourcePassword", sourcePassword);
    ob_addDictionaryPair(adminConnection->connection, "hostName", targetHost);
    ob_addDictionaryPair(adminConnection->connection, "destPassword", targetHostPassword);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_deleteDatabase
//--------------------------------------------------------------------------------

int oba_deleteDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "deleteDatabase");
    ob_addDictionaryPair(adminConnection->connection, "databaseName", databaseName);
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_checkPassword
//--------------------------------------------------------------------------------

int oba_checkPassword(OpenBaseAdminConnection *adminConnection, const char *password)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "checkPassword");
    ob_addDictionaryPair(adminConnection->connection, "password", password);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

//--------------------------------------------------------------------------------
//	oba_setPassword
//--------------------------------------------------------------------------------

int oba_setPassword(OpenBaseAdminConnection *adminConnection, const char *oldpassword, const char *newpassword)
{
    const char *returnValue = NULL;
    int len = 0;
    
    ob_prepareDictionary(adminConnection->connection);
    ob_addDictionaryPair(adminConnection->connection, "action", "setPasswordTo");
    ob_addDictionaryPair(adminConnection->connection, "oldPassword", oldpassword);
    ob_addDictionaryPair(adminConnection->connection, "newPassword", newpassword);
    if (!ob_sendBuffer(adminConnection->connection)){
        return 0;
    }
    
    YIELD_THREAD;
    
    if (!ob_readResult(adminConnection->connection)) {
        return 0;
    }
    returnValue = ob_resultValueForKey(adminConnection->connection, "result", &len);
    if (returnValue && strcmp(returnValue,"succeed") == 0) {
        return 1;
    }
    return 0;
}

#ifdef __cplusplus
}
#endif

