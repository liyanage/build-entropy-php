/* include standard header */
#include "php.h"
/* include OpenBase headers */
#include "OpenBaseConnection.h"
#include "CommAPI.h"
#include "NetClient.h"

int obPhpConnectionType;
int obPhpPersistentConnectionType;

#define OB_BUFFERSIZE 4096
#define FREE

//================================================================================
//	PhpOpenBase
//================================================================================

typedef struct {
    OpenBase*	connection;			//	the connection
    int			persistent;			//	was this allocated persistent?
    char**		columnValue;		//	what is this for??
} PhpOpenBase;

PhpOpenBase*	allocate_PhpOpenBase(int persistent);
void			deallocate_PhpOpenBase(PhpOpenBase* php_openbase);

//--------------------------------------------------------------------------------
//	allocate_PhpOpenBase
//--------------------------------------------------------------------------------

PhpOpenBase* allocate_PhpOpenBase(int persistent)
{
	PhpOpenBase* result = NULL;
	
	if (persistent)
	{
		//	needs to survive past end of script
		result = malloc(sizeof(PhpOpenBase));
	}
	else
	{
		result = emalloc(sizeof(PhpOpenBase));
	}
	
	if (result != NULL)
	{
		result->connection = ob_newConnection();
		if ( result->connection == NULL )
		{
			deallocate_PhpOpenBase(result);
			return NULL;
		}
		result->persistent = persistent;
		result->columnValue = malloc(sizeof(char *));
		if (result->columnValue != NULL)
		{
			result->columnValue[0] = NULL;
		}
		if ((result->connection == NULL) && (result->columnValue == NULL))
		{
			deallocate_PhpOpenBase(result);
			result = NULL;
		}
	}
	
	return result;
}

//--------------------------------------------------------------------------------
//	deallocate_PhpOpenBase
//--------------------------------------------------------------------------------

void deallocate_PhpOpenBase(PhpOpenBase* php_openbase)
{
	if (php_openbase != NULL)
	{
		if (php_openbase->connection != NULL)
		{
			ob_deallocConnection(php_openbase->connection);
			php_openbase->connection = NULL;
		}
		
		if (php_openbase->columnValue != NULL)
		{
			char** cursor = php_openbase->columnValue;
			while (*cursor)
			{
				free(*cursor);
				*cursor = NULL;
				cursor++;
			}
			
			free(php_openbase->columnValue);
			php_openbase->columnValue = NULL;
		}
		
		if (php_openbase->persistent)
		{
			free(php_openbase);
			php_openbase = NULL;
		}
		else
		{
			efree(php_openbase);
			php_openbase = NULL;
		}
	}
}


int counter(PhpOpenBase * thePhpConnection) {
    int i;
    char * * theCursor;
    
    i = 0;
    theCursor = thePhpConnection->columnValue;
    while(*theCursor) {
        theCursor++;
        i++;
    }
    return i;
}

/* declaration of functions to be exported */
ZEND_FUNCTION(ob_connect);
ZEND_FUNCTION(ob_pconnect);
ZEND_FUNCTION(ob_disconnect);

ZEND_FUNCTION(ob_makecommand);
ZEND_FUNCTION(ob_executecommand);
ZEND_FUNCTION(ob_rowsaffected);
ZEND_FUNCTION(ob_nextrowwithresult);
ZEND_FUNCTION(ob_nextrowwitharray);
ZEND_FUNCTION(ob_nextrowwithassocarray);

ZEND_FUNCTION(ob_resultcolumnname);
ZEND_FUNCTION(ob_resultcolumnvalue);
ZEND_FUNCTION(ob_resultcolumncount);

ZEND_FUNCTION(ob_begintransaction);
ZEND_FUNCTION(ob_bufferhascommands);
ZEND_FUNCTION(ob_clearcommands);
ZEND_FUNCTION(ob_commandbuffer);
ZEND_FUNCTION(ob_committransaction);
ZEND_FUNCTION(ob_databasename);
ZEND_FUNCTION(ob_abortfetch);
ZEND_FUNCTION(ob_hostname);
ZEND_FUNCTION(ob_iscolumnnull);
ZEND_FUNCTION(ob_loginname);
ZEND_FUNCTION(ob_password);
ZEND_FUNCTION(ob_resultcolumntype);
ZEND_FUNCTION(ob_resultreturned);
ZEND_FUNCTION(ob_resulttablename);
ZEND_FUNCTION(ob_rollbacktransaction);
ZEND_FUNCTION(ob_servermessage);
ZEND_FUNCTION(ob_uniquerowidfortable);
ZEND_FUNCTION(ob_uniquerowidfortablecolumn);
ZEND_FUNCTION(ob_insertblob);
ZEND_FUNCTION(ob_insertclob);
ZEND_FUNCTION(ob_retrieveblob);
ZEND_FUNCTION(ob_retrieveclob);
//	ZEND_FUNCTION(ob_deallocBLOB);

ZEND_FUNCTION(ob_setclientencoding);
ZEND_FUNCTION(ob_clientencoding);
ZEND_FUNCTION(ob_databaseencoding);

PHP_MINIT_FUNCTION(openbaseModule);
PHP_MINFO_FUNCTION(openbaseModule);

/* compiled function list so Zend knows what's in this module */
zend_function_entry openbase_module_functions[] =
{
    ZEND_FE(ob_connect, NULL)
    ZEND_FE(ob_pconnect, NULL)
    ZEND_FE(ob_disconnect, NULL)
    
    ZEND_FE(ob_makecommand, NULL)
    ZEND_FE(ob_executecommand, NULL)
    ZEND_FE(ob_rowsaffected, NULL)
    ZEND_FE(ob_nextrowwithresult, NULL)
    ZEND_FE(ob_nextrowwitharray, NULL)
    ZEND_FE(ob_nextrowwithassocarray, NULL)
    
    ZEND_FE(ob_resultcolumnvalue, NULL)
    ZEND_FE(ob_resultcolumnname, NULL)
    ZEND_FE(ob_resultcolumncount, NULL)

    ZEND_FE(ob_begintransaction, NULL)
    ZEND_FE(ob_bufferhascommands, NULL)
    ZEND_FE(ob_clearcommands, NULL)
    ZEND_FE(ob_commandbuffer, NULL)
    ZEND_FE(ob_committransaction, NULL)
    ZEND_FE(ob_databasename, NULL)
    ZEND_FE(ob_abortfetch, NULL)
    ZEND_FE(ob_hostname, NULL)
    ZEND_FE(ob_iscolumnnull, NULL)
    ZEND_FE(ob_loginname, NULL)
    ZEND_FE(ob_password, NULL)
    ZEND_FE(ob_resultcolumntype, NULL)
    ZEND_FE(ob_resultreturned, NULL)
    ZEND_FE(ob_resulttablename, NULL)
    ZEND_FE(ob_rollbacktransaction, NULL)
    ZEND_FE(ob_servermessage, NULL)
    ZEND_FE(ob_uniquerowidfortable, NULL)
    ZEND_FE(ob_uniquerowidfortablecolumn, NULL)
    ZEND_FE(ob_insertblob, NULL)
    ZEND_FE(ob_insertclob, NULL)
    ZEND_FE(ob_retrieveblob, NULL)
    ZEND_FE(ob_retrieveclob, NULL)
    //	ZEND_FE(ob_deallocBLOB, NULL)
    
    ZEND_FE(ob_setclientencoding, NULL)
    ZEND_FE(ob_clientencoding, NULL)
    ZEND_FE(ob_databaseencoding, NULL)
    
    {NULL, NULL, NULL}
};

/* compiled module information */

zend_module_entry openbase_module_entry =
{
    STANDARD_MODULE_HEADER,
    "OpenBase Module",
    openbase_module_functions,
    PHP_MINIT(openbaseModule),
    NULL,
    NULL,
    NULL,
    NULL,
    STANDARD_MODULE_PROPERTIES
};

/* implement standard "stub" routine to introduce ourselves to Zend */
#if COMPILE_DL_OPENBASE_MODULE
ZEND_GET_MODULE(openbase)
#endif

void writeToFile(const char * message, ...) {
    FILE * theFilePtr;
    va_list ptr;
    
    theFilePtr = fopen("/tmp/phpresult", "a+");
    va_start(ptr, message);
    vfprintf(theFilePtr, message, ptr);
    va_end(ptr);
    fprintf(theFilePtr, "\n");
    fclose(theFilePtr);
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_connect)
{
    zval**	database_name_param	= NULL;
    zval**	hostname_param		= NULL;
    zval**	user_param			= NULL;
    zval**	password_param		= NULL;
    
    const char*	database_name	= NULL;
    const char*	hostname		= NULL;
    const char*	user			= NULL;
    const char*	password		= NULL;

	PhpOpenBase*	php_openbase	= NULL;
	int				error_code		= 0;
	
	
    if((ZEND_NUM_ARGS() != 4) || (zend_get_parameters_ex(4, &database_name_param, &hostname_param, &user_param, &password_param) != SUCCESS))
	{
		WRONG_PARAM_COUNT;
	}
	
	convert_to_string_ex(database_name_param);
	convert_to_string_ex(hostname_param);
	convert_to_string_ex(user_param);
	convert_to_string_ex(password_param);
	
	database_name	= Z_STRVAL_PP(database_name_param);
	hostname		= Z_STRVAL_PP(hostname_param);
	user			= Z_STRVAL_PP(user_param);
	password		= Z_STRVAL_PP(password_param);

	php_openbase = allocate_PhpOpenBase(0);
	if (php_openbase != NULL)
	{
		if (ob_connectToDatabase(php_openbase->connection, database_name, hostname, user, password, "php", "php", &error_code))
		{
			error_code = 0;
			RETURN_RESOURCE(zend_list_insert(php_openbase, obPhpConnectionType));
		}
		else
		{
			//	messages are const char* in the unit, so this is safe
			const char* message = ob_connectErrorMessage(php_openbase->connection);
			
			deallocate_PhpOpenBase(php_openbase);
			php_openbase = NULL;
			
			RETURN_STRING((char*) message, 1);
		}
	}
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_pconnect)
{
    zval**	database_name_param	= NULL;
    zval**	hostname_param		= NULL;
    zval**	user_param			= NULL;
    zval**	password_param		= NULL;
    zval**	id_param			= NULL;
    
    const char*	database_name	= NULL;
    const char*	hostname		= NULL;
    const char*	user			= NULL;
    const char*	password		= NULL;
    const char*	id				= NULL;
    
	PhpOpenBase*	php_openbase	= NULL;
	int				error_code		= 0;
	
	char*			hashed_info			= NULL;
	int				hashed_info_length	= 0;
	
	if (ZEND_NUM_ARGS() == 5)
	{
		if (zend_get_parameters_ex(5, &database_name_param, &hostname_param, &user_param, &password_param, &id_param) != SUCCESS)
		{
			WRONG_PARAM_COUNT;
		}
		else
		{
			convert_to_string_ex(id_param);
			id = Z_STRVAL_PP(id_param);
		}
	}
	else if (ZEND_NUM_ARGS() == 4)
	{
		if (zend_get_parameters_ex(4, &database_name_param, &hostname_param, &user_param, &password_param) != SUCCESS)
		{
			WRONG_PARAM_COUNT;
		}
		else
		{
			id = "OPENBASE_PHP_DEFAULT";
		}
	}
	else
	{
		WRONG_PARAM_COUNT;
	}
	
	/*
    if((ZEND_NUM_ARGS() != 5) || (zend_get_parameters_ex(5, &database_name_param, &hostname_param, &user_param, &password_param, &id_param) != SUCCESS))
	{
		WRONG_PARAM_COUNT;
	}
	*/
	
	convert_to_string_ex(database_name_param);
	convert_to_string_ex(hostname_param);
	convert_to_string_ex(user_param);
	convert_to_string_ex(password_param);
	
	database_name	= Z_STRVAL_PP(database_name_param);
	hostname		= Z_STRVAL_PP(hostname_param);
	user			= Z_STRVAL_PP(user_param);
	password		= Z_STRVAL_PP(password_param);
	
	//	scan the resource list 
	hashed_info_length = 20 + strlen(database_name) + strlen(hostname) +
						strlen(user) + strlen(password) + strlen(id);
	hashed_info = emalloc(hashed_info_length);
	
	if (hashed_info != NULL)
	{
		list_entry	*le;
	
		sprintf(hashed_info, "OB_PC %s %s %s %s %s", database_name, hostname, user, password, id);

		if (zend_hash_find(&EG(persistent_list), hashed_info, strlen(hashed_info) + 1, (void **) &le) == FAILURE)
		{
			php_openbase = allocate_PhpOpenBase(1);
			if (php_openbase != NULL)
			{		
				if (ob_connectToDatabase(php_openbase->connection, database_name, hostname, user, password,  "php", "php", &error_code))
				{
					list_entry	new_le;
					
					Z_TYPE(new_le) = obPhpPersistentConnectionType;
					new_le.ptr = php_openbase;
					if (zend_hash_update(&EG(persistent_list), hashed_info, strlen(hashed_info) + 1,
											(void*) &new_le, sizeof(list_entry), NULL) == FAILURE)
					{
						deallocate_PhpOpenBase(php_openbase);
						php_openbase = NULL;
						
						efree(hashed_info);
						RETURN_STRING((char *) "Could not save persistent connection.", 1);
					}
					else
					{
						//	zend_printf("ob_pconnect step 6<br>%ld<br>", (int) php_openbase);	
						efree(hashed_info);
						RETURN_RESOURCE(zend_list_insert(php_openbase, obPhpPersistentConnectionType));
					}
				}
				else
				{
					//	messages are const char* in the unit, so this is safe
					const char* message = ob_connectErrorMessage(php_openbase->connection);

					deallocate_PhpOpenBase(php_openbase);
					php_openbase = NULL;
					
					efree(hashed_info);
					RETURN_STRING((char*) message, 1);
				}
			}
		}
		else
		{
			//	we have it, so return it
			php_openbase = le->ptr;

			//	zend_printf("ob_pconnect step 8<br>%ld<br>", (int) php_openbase);
			
			efree(hashed_info);
			RETURN_RESOURCE(zend_list_insert(php_openbase, obPhpPersistentConnectionType));
		}
		
		efree(hashed_info);
		hashed_info = NULL;
	}
}

ZEND_FUNCTION(ob_disconnect)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    ob_deallocConnection(thePhpConnection->connection);
	thePhpConnection->connection = NULL;
    RETURN_NULL();
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_makecommand)
{
    zval **theConnectionParameter;
    zval **theCommandParameter;
    PhpOpenBase * thePhpConnection;

#ifdef DEBUG
    writeToFile("ob_makeCommand 1");
#endif
    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theCommandParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);
    
    convert_to_string_ex(theCommandParameter);

    ob_makeCommand(thePhpConnection->connection, Z_STRVAL_PP(theCommandParameter));
#ifdef DEBUG
    writeToFile("ob_makeCommand 2");
#endif
    RETURN_NULL();
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_executecommand)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theResult;

#ifdef DEBUG
    writeToFile("ob_executeCommand 1");
#endif
    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    theConnection = thePhpConnection->connection;
    theResult = ob_executeCommand(theConnection);
    if(theResult) {
        int theNumberOfColumn;
        int i;
        char * * theCursor;
        
        theCursor = thePhpConnection->columnValue;
        while(*theCursor) {
#ifdef FREE
            free(*theCursor);
#endif
            theCursor++;
        }
#ifdef FREE
        free(thePhpConnection->columnValue);
#endif
        theNumberOfColumn = ob_resultColumnCount(theConnection);
        theCursor = thePhpConnection->columnValue = malloc((theNumberOfColumn + 1) * sizeof(char *));
        i = 0;
        while(i < theNumberOfColumn) {
            *theCursor = malloc(OB_BUFFERSIZE);
            ob_bindString(theConnection, *theCursor);
            theCursor++;
            i++;
        }
        *theCursor = NULL;
    }
#ifdef DEBUG
    writeToFile("ob_executeCommand 2");
#endif
    RETURN_BOOL(theResult);
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_nextrowwithresult)
{
    zval ***theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theNumberOfArguments;
    int theResult;
    char datetime_buffer[100];
    
    theNumberOfArguments = ZEND_NUM_ARGS();
    if(ZEND_NUM_ARGS() < 1) {
        WRONG_PARAM_COUNT;
    }
    theConnectionParameter = malloc(theNumberOfArguments * sizeof(zval **));
    if(zend_get_parameters_array_ex(theNumberOfArguments, theConnectionParameter) != SUCCESS) {
#ifdef FREE
        free(theConnectionParameter);
#endif
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, *theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    theConnection = thePhpConnection->connection;
    theResult = ob_nextRow(theConnection);
    if(theResult) {
        if(theNumberOfArguments - 1 > ob_resultColumnCount(theConnection)) {
            theNumberOfArguments = ob_resultColumnCount(theConnection) + 1;
        }
        for(; theNumberOfArguments >= 2; theNumberOfArguments--) {
        	#if ZEND_MODULE_API_NO < 20010901
            if(!ParameterPassedByReference(ht, theNumberOfArguments)) {
                zend_error(E_WARNING, "Parameter #%d wasn't passed by reference", theNumberOfArguments);
                break;
            }
            #endif
            switch(ob_resultColumnType(theConnection, theNumberOfArguments - 2)) {
                case OBTYPE_INT:
                case OBTYPE_LONG:
                case OBTYPE_LONGLONG:
                    ZVAL_LONG(*theConnectionParameter[theNumberOfArguments - 1], atol(thePhpConnection->columnValue[theNumberOfArguments - 2]));
                    break;
                case OBTYPE_FLOAT:
                    ZVAL_DOUBLE(*theConnectionParameter[theNumberOfArguments - 1], atof(thePhpConnection->columnValue[theNumberOfArguments - 2]));
                    break;
                case OBTYPE_CHAR:
                case OBTYPE_MONEY:
                case OBTYPE_DATE:
                case OBTYPE_TIME:
				case OBTYPE_BINARY:
				case OBTYPE_OBJECT_TEXT:
				case OBTYPE_TIMESTAMP: 
                case OBTYPE_OBJECT:
                    ZVAL_STRING(*theConnectionParameter[theNumberOfArguments - 1], thePhpConnection->columnValue[theNumberOfArguments - 2], 1);
                    break;
                case OBTYPE_DATETIME:
                	/*
                	strcpy(datetime_buffer, thePhpConnection->columnValue[theNumberOfArguments - 2]);
                	ob_NSDateTimeToPlatformDatetimeString(datetime_buffer, datetime_buffer);
                	strcpy(thePhpConnection->columnValue[theNumberOfArguments - 2], datetime_buffer);
                	*/
                    ZVAL_STRING(*theConnectionParameter[theNumberOfArguments - 1], thePhpConnection->columnValue[theNumberOfArguments - 2], 1);
            }
        }
    }
#ifdef FREE
    free(theConnectionParameter);
#endif
    RETURN_LONG(theResult);
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_nextrowwitharray)
{
    zval ***theConnectionParameter;
    zval **theArrayResult;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theNumberOfArguments;
    int theResult;
	char datetime_buffer[100];

    theNumberOfArguments = ZEND_NUM_ARGS();
    if(ZEND_NUM_ARGS() != 2) {
        WRONG_PARAM_COUNT;
    }

    theConnectionParameter = malloc(theNumberOfArguments * sizeof(zval **));
    if(zend_get_parameters_array_ex(theNumberOfArguments, theConnectionParameter) != SUCCESS) {
#ifdef FREE
        free(theConnectionParameter);
#endif
        WRONG_PARAM_COUNT;
    }

    /*
    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theArrayResult) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }
	*/
	
	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, *theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    theConnection = thePhpConnection->connection;
    theArrayResult = theConnectionParameter[1];
    
    #if ZEND_MODULE_API_NO < 20010901
    if(!ParameterPassedByReference(ht, 2)) {
        zend_error(E_WARNING, "Parameter #2 wasn't passed by reference");
        RETURN_NULL();
    }
    #endif
    theResult = ob_nextRow(theConnection);

    if(array_init(*theArrayResult) != SUCCESS)
    {
        zend_error(E_WARNING, "Impossible to create an array");
        RETURN_LONG(theResult);
    }
    if(theResult) {
        int theNumberOfColumn;
        int i;
        
        theNumberOfColumn = ob_resultColumnCount(theConnection);
        for(i = 0; i < theNumberOfColumn; i++)
        {
        	if (ob_isColumnNULL(theConnection, i))
        	{
				add_next_index_string(*theArrayResult, "NULL", 1);
        	}
        	else
        	{
				switch(ob_resultColumnType(theConnection, i))
				{
					case OBTYPE_INT:
					case OBTYPE_LONG:
					case OBTYPE_LONGLONG:
						add_next_index_long(*theArrayResult, atol(thePhpConnection->columnValue[i]));
						break;
					case OBTYPE_FLOAT:
						add_next_index_double(*theArrayResult, atof(thePhpConnection->columnValue[i]));
						break;
					case OBTYPE_CHAR:
					case OBTYPE_MONEY:
					//case OBTYPE_DATETIME:
					case OBTYPE_DATE:
					case OBTYPE_TIME:
					case OBTYPE_BINARY:
					case OBTYPE_OBJECT_TEXT:
					case OBTYPE_TIMESTAMP: 
					case OBTYPE_OBJECT:
						add_next_index_string(*theArrayResult, thePhpConnection->columnValue[i], 1);
						break;
					case OBTYPE_DATETIME:
						/*
						strcpy(datetime_buffer, thePhpConnection->columnValue[i]);
						ob_NSDateTimeToPlatformDatetimeString(datetime_buffer, datetime_buffer);
						strcpy(thePhpConnection->columnValue[i], datetime_buffer);
						*/
						add_next_index_string(*theArrayResult, thePhpConnection->columnValue[i], 1);
				}
            }
        }
    }
#ifdef FREE
    free(theConnectionParameter);
#endif
    RETURN_LONG(theResult);
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_nextrowwithassocarray)
{
    zval ***theConnectionParameter;
    zval **theArrayResult;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theNumberOfArguments;
    int theResult;
	char datetime_buffer[100];

    theNumberOfArguments = ZEND_NUM_ARGS();
    if(ZEND_NUM_ARGS() != 2) {
        WRONG_PARAM_COUNT;
    }

    theConnectionParameter = malloc(theNumberOfArguments * sizeof(zval **));
    if(zend_get_parameters_array_ex(theNumberOfArguments, theConnectionParameter) != SUCCESS) {
#ifdef FREE
        free(theConnectionParameter);
#endif
        WRONG_PARAM_COUNT;
    }

    /*
    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theArrayResult) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }
	*/
	
	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, *theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    theConnection = thePhpConnection->connection;
    theArrayResult = theConnectionParameter[1];
    
    #if ZEND_MODULE_API_NO < 20010901
    if(!ParameterPassedByReference(ht, 2)) {
        zend_error(E_WARNING, "Parameter #2 wasn't passed by reference");
        RETURN_NULL();
    }
    #endif
    theResult = ob_nextRow(theConnection);

    if(array_init(*theArrayResult) != SUCCESS)
    {
        zend_error(E_WARNING, "Impossible to create an array");
        RETURN_LONG(theResult);
    }
    if(theResult) {
        int theNumberOfColumn;
        int i;
        const char* column_name;
        
        theNumberOfColumn = ob_resultColumnCount(theConnection);
        for(i = 0; i < theNumberOfColumn; i++)
        {
        	column_name = ob_resultColumnName(theConnection, i);
        	
        	if (ob_isColumnNULL(theConnection, i))
        	{
				add_assoc_string(*theArrayResult, (char*) column_name, "NULL", 1);
        	}
        	else
        	{
				switch(ob_resultColumnType(theConnection, i))
				{
					case OBTYPE_INT:
					case OBTYPE_LONG:
					case OBTYPE_LONGLONG:
						//	add_next_index_long(*theArrayResult, atol(thePhpConnection->columnValue[i]));
						add_assoc_long(*theArrayResult, (char*) column_name, atol(thePhpConnection->columnValue[i]));
						break;
					case OBTYPE_FLOAT:
						//	add_next_index_double(*theArrayResult, atof(thePhpConnection->columnValue[i]));
						add_assoc_double(*theArrayResult, (char*) column_name, atof(thePhpConnection->columnValue[i]));
						break;
					case OBTYPE_CHAR:
					case OBTYPE_MONEY:
					//case OBTYPE_DATETIME:
					case OBTYPE_DATE:
					case OBTYPE_TIME:
					case OBTYPE_BINARY:
					case OBTYPE_OBJECT_TEXT:
					case OBTYPE_TIMESTAMP: 
					case OBTYPE_OBJECT:
						//	add_next_index_string(*theArrayResult, thePhpConnection->columnValue[i], 1);
						add_assoc_string(*theArrayResult, (char*) column_name, thePhpConnection->columnValue[i], 1);
						break;
					case OBTYPE_DATETIME:
						/*
						strcpy(datetime_buffer, thePhpConnection->columnValue[i]);
						ob_NSDateTimeToPlatformDatetimeString(datetime_buffer, datetime_buffer);
						strcpy(thePhpConnection->columnValue[i], datetime_buffer);
						*/
						
						//	add_next_index_string(*theArrayResult, thePhpConnection->columnValue[i], 1);
						add_assoc_string(*theArrayResult, (char*) column_name, thePhpConnection->columnValue[i], 1);
				}
            }
        }
    }
#ifdef FREE
    free(theConnectionParameter);
#endif
    RETURN_LONG(theResult);
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_rowsaffected)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_rowsAffected(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_resultcolumnname) {
    zval **theConnectionParameter;
    zval **theColumnNumberParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theColumnNumber;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theColumnNumberParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_long_ex(theColumnNumberParameter);
    theConnection = thePhpConnection->connection;
    theColumnNumber = (*theColumnNumberParameter)->value.lval;
    
    if((theColumnNumber < ob_resultColumnCount(theConnection)) && (theColumnNumber >= 0))
    {
        const char* column_name = ob_resultColumnName(theConnection, theColumnNumber);
        RETURN_STRING((char*) column_name, 1);
    } else {
        zend_error(E_WARNING, "Invalid column number");
        RETURN_NULL();
    }
}

ZEND_FUNCTION(ob_resultcolumnvalue) {
    zval **theConnectionParameter;
    zval **theColumnNumberParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theColumnNumber;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theColumnNumberParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_long_ex(theColumnNumberParameter);
    theConnection = thePhpConnection->connection;
    theColumnNumber = (*theColumnNumberParameter)->value.lval;
    
    if((theColumnNumber < ob_resultColumnCount(theConnection)) && (theColumnNumber >= 0)) {
        switch(ob_resultColumnType(theConnection, theColumnNumber)) {
            case OBTYPE_INT:
            case OBTYPE_LONG:
            case OBTYPE_LONGLONG:
                RETURN_LONG(atol(thePhpConnection->columnValue[theColumnNumber]));
                break;
            case OBTYPE_FLOAT:
                RETURN_DOUBLE(atof(thePhpConnection->columnValue[theColumnNumber]));
                break;
            case OBTYPE_CHAR:
            case OBTYPE_MONEY:
            case OBTYPE_DATETIME:
            case OBTYPE_DATE:
            case OBTYPE_TIME:
            case OBTYPE_OBJECT:
                RETURN_STRING(thePhpConnection->columnValue[theColumnNumber], 1);
                break;
            default:
                RETURN_NULL();
                break;
        }
    } else {
        zend_error(E_WARNING, "Invalid column number");
        RETURN_NULL();
    }
}

// implement function that is meant to be made available to PHP
ZEND_FUNCTION(ob_resultcolumncount)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_resultColumnCount(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_begintransaction)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_beginTransaction(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_bufferhascommands)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_bufferHasCommands(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_clearcommands)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    ob_clearCommands(thePhpConnection->connection);
    RETURN_NULL();
}

ZEND_FUNCTION(ob_commandbuffer)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_STRING((char *)ob_connectErrorMessage(thePhpConnection->connection), 1);
}

ZEND_FUNCTION(ob_committransaction)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_commitTransaction(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_databasename)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    const char* database_name;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    database_name = ob_databaseName(thePhpConnection->connection);
    RETURN_STRING((char*) database_name, 1);
}

ZEND_FUNCTION(ob_abortfetch)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_abortFetch(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_hostname)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    const char* host_name;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    host_name = ob_hostName(thePhpConnection->connection);
    RETURN_STRING((char*) host_name, 1);
}

ZEND_FUNCTION(ob_iscolumnnull)
{
    zval **theConnectionParameter;
    zval **theColumnNumberParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theColumnNumber;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theColumnNumberParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);
	
    convert_to_long_ex(theColumnNumberParameter);
    theConnection = thePhpConnection->connection;
    theColumnNumber = (*theColumnNumberParameter)->value.lval;
    
    if((theColumnNumber < ob_resultColumnCount(theConnection)) && (theColumnNumber >= 0)) {
        RETURN_LONG(ob_isColumnNULL(theConnection, theColumnNumber));
    } else {
        zend_error(E_WARNING, "Invalid column number");
        RETURN_NULL();
    }
}

ZEND_FUNCTION(ob_loginname)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_STRING((char *)ob_loginName(thePhpConnection->connection), 1);
}

ZEND_FUNCTION(ob_password)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    const char* password;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    password = ob_password(thePhpConnection->connection);
    RETURN_STRING((char*) password, 1);
}

ZEND_FUNCTION(ob_resultcolumntype)
{
    zval **theConnectionParameter;
    zval **theColumnNumberParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theColumnNumber;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theColumnNumberParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_long_ex(theColumnNumberParameter);
    theConnection = thePhpConnection->connection;
    theColumnNumber = (*theColumnNumberParameter)->value.lval;
    
    if((theColumnNumber < ob_resultColumnCount(theConnection)) && (theColumnNumber >= 0)) {
        RETURN_LONG(ob_resultColumnType(theConnection, theColumnNumber));
    } else {
        zend_error(E_WARNING, "Invalid column number");
        RETURN_NULL();
    }
}

ZEND_FUNCTION(ob_resultreturned)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);
    
    RETURN_LONG(ob_resultReturned(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_resulttablename)
{
    zval **theConnectionParameter;
    zval **theColumnNumberParameter;
    PhpOpenBase * thePhpConnection;
    OpenBase * theConnection;
    int theColumnNumber;
    const char* table_name;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theColumnNumberParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_long_ex(theColumnNumberParameter);
    theConnection = thePhpConnection->connection;
    theColumnNumber = (*theColumnNumberParameter)->value.lval;
    
    if((theColumnNumber < ob_resultColumnCount(theConnection)) && (theColumnNumber >= 0))
    {
        table_name = ob_resultTableName(theConnection, theColumnNumber);
        RETURN_STRING((char*) table_name, 1);
    } else {
        zend_error(E_WARNING, "Invalid column number");
        RETURN_NULL();
    }
}

ZEND_FUNCTION(ob_rollbacktransaction)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_LONG(ob_rollbackTransaction(thePhpConnection->connection));
}

ZEND_FUNCTION(ob_servermessage)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    RETURN_STRING((char *)ob_serverMessage(thePhpConnection->connection), 1);
}

ZEND_FUNCTION(ob_uniquerowidfortable)
{
    zval **theConnectionParameter;
    zval **theTableName;
    PhpOpenBase * thePhpConnection;
    int errorNum;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theTableName) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theTableName);

    RETURN_STRING((char *)ob_uniqueRowIdForTable(thePhpConnection->connection, Z_STRVAL_PP(theTableName)), 1)
}

ZEND_FUNCTION(ob_uniquerowidfortablecolumn)
{
    zval **theConnectionParameter;
    zval **theTableName;
    zval **theColumnName;
    PhpOpenBase * thePhpConnection;
    int errorNum;

    if((ZEND_NUM_ARGS() != 3) || (zend_get_parameters_ex(3, &theConnectionParameter, &theTableName, &theColumnName) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theTableName);
    convert_to_string_ex(theColumnName);

    RETURN_STRING((char *)ob_uniqueRowIdForTableColumn(thePhpConnection->connection, Z_STRVAL_PP(theTableName), Z_STRVAL_PP(theColumnName)), 1);
}

ZEND_FUNCTION(ob_insertblob)
{
    zval **theConnectionParameter;
    zval **theBlobString;
    PhpOpenBase * thePhpConnection;
    int errorNum;
    const char * blob_string;
    int blob_length;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theBlobString) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theBlobString);
    blob_string = Z_STRVAL_PP(theBlobString);
    blob_length = Z_STRLEN_PP(theBlobString);

    RETURN_STRING((char *)ob_insertBLOB(thePhpConnection->connection, blob_string, blob_length), 1);
}

ZEND_FUNCTION(ob_insertclob)
{
    zval **theConnectionParameter;
    zval **theBlobString;
    PhpOpenBase * thePhpConnection;
    int errorNum;
    const char * blob_string;
    int blob_length;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theBlobString) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theBlobString);
    blob_string = Z_STRVAL_PP(theBlobString);
    blob_length = Z_STRLEN_PP(theBlobString);

    RETURN_STRING((char *)ob_insertCLOB(thePhpConnection->connection, blob_string, blob_length), 1);
}

ZEND_FUNCTION(ob_retrieveblob)
{
    zval **theConnectionParameter;
    zval **theBlobId;
    PhpOpenBase * thePhpConnection;
    int errorNum;
    const char * theCString;
    int theBlobSize;
    const char * theBlobString;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theBlobId) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theBlobId);

    theBlobString = ob_retrieveBLOB(thePhpConnection->connection, Z_STRVAL_PP(theBlobId), &theBlobSize);
    if(theBlobString) {
        RETURN_STRINGL((char *)theBlobString, theBlobSize, 1);
    } else {
        RETURN_STRING("", 1);
    }
}

ZEND_FUNCTION(ob_retrieveclob)
{
    zval **theConnectionParameter;
    zval **theBlobId;
    PhpOpenBase * thePhpConnection;
    int errorNum;
    const char * theCString;
    int theBlobSize;
    const char * theBlobString;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &theBlobId) != SUCCESS)) {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_string_ex(theBlobId);

    theBlobString = ob_retrieveCLOB(thePhpConnection->connection, Z_STRVAL_PP(theBlobId), &theBlobSize);
    if(theBlobString) {
        RETURN_STRINGL((char *)theBlobString, theBlobSize, 1);
    } else {
        RETURN_STRING("", 1);
    }
}

ZEND_FUNCTION(ob_setclientencoding)
{
    zval **theConnectionParameter;
    zval **clientEncodingParameter;
    PhpOpenBase * thePhpConnection;
    long client_encoding;

    if((ZEND_NUM_ARGS() != 2) || (zend_get_parameters_ex(2, &theConnectionParameter, &clientEncodingParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    convert_to_long_ex(clientEncodingParameter);
    client_encoding = (*clientEncodingParameter)->value.lval;
    
	ob_setClientEncoding(thePhpConnection->connection, client_encoding);
    RETURN_NULL();
}

ZEND_FUNCTION(ob_clientencoding)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    long client_encoding;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    client_encoding = ob_clientEncoding(thePhpConnection->connection);
    RETURN_LONG(client_encoding);
}


ZEND_FUNCTION(ob_databaseencoding)
{
    zval **theConnectionParameter;
    PhpOpenBase * thePhpConnection;
    long database_encoding;

    if((ZEND_NUM_ARGS() != 1) || (zend_get_parameters_ex(1, &theConnectionParameter) != SUCCESS))
    {
        WRONG_PARAM_COUNT;
    }

	ZEND_FETCH_RESOURCE2(thePhpConnection, PhpOpenBase *, theConnectionParameter, -1, "OpenBase Connection", obPhpConnectionType, obPhpPersistentConnectionType);

    database_encoding = ob_databaseEncoding(thePhpConnection->connection);
    RETURN_LONG(database_encoding);
}


static void ob_connectionDestructor(zend_rsrc_list_entry *rsrc)
{
	PhpOpenBase* php_openbase;
	
	if (rsrc != NULL)
	{
		php_openbase = rsrc->ptr;
		if (php_openbase != NULL)
		{
			deallocate_PhpOpenBase(php_openbase);
		}
	}
}

PHP_MINIT_FUNCTION(openbaseModule)
{
    obPhpConnectionType = zend_register_list_destructors_ex(ob_connectionDestructor, NULL, "OpenBase Connection", module_number);
    obPhpPersistentConnectionType = zend_register_list_destructors_ex(NULL, ob_connectionDestructor, "OpenBase Peristent Connection", module_number);
    //	obPhpPersistentConnectionType = zend_register_list_destructors_ex(ob_connectionDestructor, NULL, "OpenBase Peristent Connection", module_number);
    
    //	register encoding constants
	REGISTER_LONG_CONSTANT("OB_ENCODING_ASCII",						OB_ENCODING_ASCII,						CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_UTF8",						OB_ENCODING_UTF8,						CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_UNICODE",					OB_ENCODING_UNICODE,					CONST_CS | CONST_PERSISTENT);
		
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_1",					OB_ENCODING_ISO8859_1,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_2",					OB_ENCODING_ISO8859_2,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_3",					OB_ENCODING_ISO8859_3,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_4",					OB_ENCODING_ISO8859_4,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_5",					OB_ENCODING_ISO8859_5,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_6",					OB_ENCODING_ISO8859_6,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_7",					OB_ENCODING_ISO8859_7,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_8",					OB_ENCODING_ISO8859_8,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_9",					OB_ENCODING_ISO8859_9,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_10",				OB_ENCODING_ISO8859_10,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_13",				OB_ENCODING_ISO8859_13,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_14",				OB_ENCODING_ISO8859_14,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_15",				OB_ENCODING_ISO8859_15,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO8859_16",				OB_ENCODING_ISO8859_16,					CONST_CS | CONST_PERSISTENT);
	
	//	REGISTER_LONG_CONSTANT("OB_ENCODING_ISO2022JP",				OB_ENCODING_ISO2022JP,						CONST_CS | CONST_PERSISTENT);
	//	REGISTER_LONG_CONSTANT("OB_ENCODING_EUC",					OB_ENCODING_EUC,							CONST_CS | CONST_PERSISTENT);
	//	REGISTER_LONG_CONSTANT("OB_ENCODING_SHIFTJIS",				OB_ENCODING_SHIFTJIS,						CONST_CS | CONST_PERSISTENT);
    
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_ROMAN",				OB_ENCODING_MACOS_ROMAN,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_ARABIC",				OB_ENCODING_MACOS_ARABIC,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_CENTEURO",			OB_ENCODING_MACOS_CENTEURO,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_CORPCHAR",			OB_ENCODING_MACOS_CORPCHAR,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_CROATIAN",			OB_ENCODING_MACOS_CROATIAN,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_CYRILLIC",			OB_ENCODING_MACOS_CYRILLIC,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_DEVANAGA",			OB_ENCODING_MACOS_DEVANAGA,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_DINGBATS",			OB_ENCODING_MACOS_DINGBATS,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_FARSI",				OB_ENCODING_MACOS_FARSI,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_GREEK",				OB_ENCODING_MACOS_GREEK,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_GUJARATI",			OB_ENCODING_MACOS_GUJARATI,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_GURMUKHI",			OB_ENCODING_MACOS_GURMUKHI,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_HEBREW",				OB_ENCODING_MACOS_HEBREW,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_ICELAND",				OB_ENCODING_MACOS_ICELAND,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_ROMANIAN",			OB_ENCODING_MACOS_ROMANIAN,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_SYMBOL",				OB_ENCODING_MACOS_SYMBOL,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_THAI",				OB_ENCODING_MACOS_THAI,					CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_TURKISH",				OB_ENCODING_MACOS_TURKISH,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_MACOS_UKRAINE",				OB_ENCODING_MACOS_UKRAINE,				CONST_CS | CONST_PERSISTENT);
	
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP437_LATINUS",			OB_ENCODING_DOS_CP437_LATINUS,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP737_GREEK",			OB_ENCODING_DOS_CP737_GREEK,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP775_BALTRIM",			OB_ENCODING_DOS_CP775_BALTRIM,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP850_LATIN1",			OB_ENCODING_DOS_CP850_LATIN1,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP852_LATIN2",			OB_ENCODING_DOS_CP852_LATIN2,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP855_CYRILLIC",		OB_ENCODING_DOS_CP855_CYRILLIC,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP857_TURKISH",			OB_ENCODING_DOS_CP857_TURKISH,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP860_PORTUGUESE",		OB_ENCODING_DOS_CP860_PORTUGUESE,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP861_ICELANDIC",		OB_ENCODING_DOS_CP861_ICELANDIC,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP862_HEBREW",			OB_ENCODING_DOS_CP862_HEBREW,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP863_CANADAF",			OB_ENCODING_DOS_CP863_CANADAF,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP864_ARABIC",			OB_ENCODING_DOS_CP864_ARABIC,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP865_NORDIC",			OB_ENCODING_DOS_CP865_NORDIC,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP866_CYRILLICRUSSIAN",	OB_ENCODING_DOS_CP866_CYRILLICRUSSIAN,	CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP869_GREEK2",			OB_ENCODING_DOS_CP869_GREEK2,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_DOS_CP874_THAI",			OB_ENCODING_DOS_CP874_THAI,				CONST_CS | CONST_PERSISTENT);
	
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP874_THAI",			OB_ENCODING_WIN_CP874_THAI,				CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1250_LATIN2",			OB_ENCODING_WIN_CP1250_LATIN2,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1251_CYRILLIC",		OB_ENCODING_WIN_CP1251_CYRILLIC,		CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1252_LATIN1",			OB_ENCODING_WIN_CP1252_LATIN1,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1253_GREEK",			OB_ENCODING_WIN_CP1253_GREEK,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1254_TURKISH",		OB_ENCODING_WIN_CP1254_TURKISH,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1255_HEBREW",			OB_ENCODING_WIN_CP1255_HEBREW,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1256_ARABIC",			OB_ENCODING_WIN_CP1256_ARABIC,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1257_BALTRIM",		OB_ENCODING_WIN_CP1257_BALTRIM,			CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("OB_ENCODING_WIN_CP1258_VIETNAMESE",		OB_ENCODING_WIN_CP1258_VIETNAMESE,		CONST_CS | CONST_PERSISTENT);

	REGISTER_LONG_CONSTANT("OB_ENCODING_NEXT",						OB_ENCODING_NEXT,						CONST_CS | CONST_PERSISTENT);

    return SUCCESS;
}

PHP_MINFO_FUNCTION(openbaseModule)
{
}
