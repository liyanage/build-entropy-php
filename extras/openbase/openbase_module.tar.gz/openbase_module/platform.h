// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
#define  MACOSX_UNIX 1
#undef MACOSX_CARBON 
#undef WINNT
#undef LINUX
#undef SOLARIS
#undef RHAPSODY

#if !( MACOSX_UNIX || MACOSX_CARBON || WINNT || LINUX || SOLARIS || RHAPSODY )

	#error Must select a platform
	
#endif

#ifndef __PLATFORM_SPECIFIC__

#define __PLATFORM_SPECIFIC__


	// commn def's here
	#ifndef NO
		#define	NO	0
	#endif
	#ifndef YES
		#define YES	1
	#endif

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT MAC OS X UNIX STYLE DEFINES HERE
	#ifdef MACOSX_UNIX

		#define OBSocketRead(socketFD, buffer, byteCount, flag) ob_socketread(socketFD, buffer, byteCount, flag)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT MAC OS X CARBON DEFINES HERE
	#ifdef MACOSX_CARBON

		#include <OpenTransport.h>
		#include <OpenTptInternet.h>
		
		#define TARGET_API_MAC_CARBON	1

		#ifndef macintosh
			#define macintosh 1
		#endif
				
		#define OBSocketRead(socketFD, buffer, byteCount, flag) ob_socketread(socketFD, buffer, byteCount, flag)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT WINDOWS DEFINES HERE
	#ifdef WINNT

		#define SWAPENDIAN	
		#define windows
		#define WIN32
		
		#define OBSocketRead(socketFD, buffer, byteCount) ob_socketread(socketFD, buffer, byteCount)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); closesocket(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT LINUX DEFINES HERE
	#ifdef LINUX

		#define SWAPENDIAN //note this may only apply if the platform is intel ...
		
		#define OBSocketRead(socketFD, buffer, byteCount, flag) ob_socketread(socketFD, buffer, byteCount, flag)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 

	
	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT SOLARIS DEFINES HERE
	#ifdef SOLARIS
		
		#define OBSocketRead(socketFD, buffer, byteCount, flag) ob_socketread(socketFD, buffer, byteCount, flag)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// PUT RHAPSODY DEFINES HERE
	#ifdef RHAPSODY
		
		#define OBSocketRead(socketFD, buffer, byteCount, flag) ob_socketread(socketFD, buffer, byteCount, flag)
		#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount, 0)
		#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)
		#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

	#endif 


#endif // __PLATFORM_SPECIFIC__
