/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "longlong.h"
#include "conversion.h"

void convert_movePointToLeft(char *str)
{
        int len;
        char hold[50];

        len = strlen(str);

        if (len <= 2) {
            strcpy(hold,"0.00");
            strcpy(&hold[4-len],str);
            strcpy(str, hold);
            return;
        }
        strcpy(hold,&str[len-2]);
        strcpy(&str[len-2],".");
        strcpy(&str[len-1],hold);

        return;
}


void convert_convertToMoney(long long value, char *string, const char *prefix, const char *postfix)
{
        char	*ptr, buffer[256];
        int neg=0;

        ob_lltoa(value, string);
        convert_movePointToLeft(string);

        if (string[0]=='-') {
                neg = 1;
        }

        if ((ptr = index(string, '.')) == (void *)0) {
                return;
        }
        
        while ((ptr - string - neg)>3) {
                ptr = ptr - 3;
                strcpy(buffer,ptr);
                *ptr = ',';
                strcpy(&ptr[1], buffer);
        }

        sprintf(buffer, "%s%s%s", prefix, string, postfix);
        strcpy(string, buffer);

        return;
}


char *convert_convertFromTime(char *str, int formatType)
{
        int mm,hh;
        char am_pm[5];

        if (str[0]=='\0') {
                return str;
        }

        hh=atoi(&str[1]);
        mm=atoi(&str[4]);
        switch(formatType) {
                case '1':
                        sprintf(str,"%02d:%02d",hh,mm);
                        break;
                default:
                        if ((hh>11) && (hh<24)) {
                                if (hh>12) hh=hh-12;
                                strcpy(am_pm,"pm");
                        } else {
                                strcpy(am_pm,"am");
                                if (hh==0) hh=12;
                        }

                        sprintf(str,"%d:%02d %s",hh,mm,am_pm);
                        break;
        }

        return str;
}

char *convert_convertFromDate(char *str, int formatType)
{
        int mm,dd,yy;
        char amonth[10];

        if (strcmp(str,"")==0) return str;
        if (str[0]!='@') return str;

        yy=atoi(&str[1]);
        mm=atoi(&str[6]);
        dd=atoi(&str[9]);
        switch(formatType) {
                case 2:
                        sprintf(str,"%02d-%02d-%4d", mm, dd,  yy);
                        break;
                case 3:
                        sprintf(str,"%02d/%02d/%4d", mm, dd, yy);
                        break;
                case 4:
                        sprintf(str,"%d.%d.%4d", dd, mm, yy);
                        break;

                default:
                        switch(mm)
                        {
                        case 1:
                                strcpy(amonth,"Jan");
                                break;
                        case 2:
                                strcpy(amonth,"Feb");
                                break;
                        case 3:
                                strcpy(amonth,"Mar");
                                break;
                        case 4:
                                strcpy(amonth,"Apr");
                                break;
                        case 5:
                                strcpy(amonth,"May");
                                break;
                        case 6:
                                strcpy(amonth,"Jun");
                                break;
                        case 7:
                                strcpy(amonth,"Jul");
                                break;
                        case 8:
                                strcpy(amonth,"Aug");
                                break;
                        case 9:
                                strcpy(amonth,"Sep");
                                break;
                        case 10:
                                strcpy(amonth,"Oct");
                                break;
                        case 11:
                                strcpy(amonth,"Nov");
                                break;
                        case 12:
                                strcpy(amonth,"Dec");
                                break;
                        }
                        if (formatType == 1) {
                                sprintf(str,"%d %s %d",dd,amonth,yy);
                        } else {
                                sprintf(str,"%s %d, %d",amonth,dd,yy);
                        }
                        break;
        }

        return str;
}

void strip(char * in, char *out)
{
	int i = 0, j = 0;
	while (in[i] != '\0')
	{
		if (isdigit(in[i]) || in[i] == '.')
		{
			out[j] = in[i];
			j++;
		}
		i++;
	}
	out[j] = '\0';
}


int moneyToInt(char *money)
{
	char tmp[256];
	strip(money, tmp);
	return atoi(tmp);	
}

long moneyToLong(char *money)
{
	char tmp[256];
	strip(money, tmp);
	return atol(tmp);	
}

double moneyToDouble(char *money)
{
	char tmp[256];
	strip(money, tmp);
	return atof(tmp);	
}



