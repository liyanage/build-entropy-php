/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "API_Header.h"

#ifdef OPEN_TRANSPORT
#include <OpenTransport.h>
#include <OpenTptInternet.h>
#endif

#include <strings.h>
#include "CommAPI.h"
#include "NetClientLib.h"
#include "OpenBaseConnection.h"

#define NO   0
#define YES  1


/********************************************************************/
#ifdef macintosh

#include <OpenTransport.h>
#include <OpenTptInternet.h>

char* MapAddressToName ( char* ipAddress, char* domainName )
{
	domainName[0] = '\0'; // assume failure

	OSStatus err = InitOpenTransport();
	if (!err)
	{
		TInternetServices* isRef = OTOpenInternetServices(kDefaultInternetServicesPath,0,&err);
		if (!err)
		{
			InetHost ipAddr;
			err = OTInetStringToHost(ipAddress,&ipAddr);
			if (!err)
			{
				err = OTInetAddressToName(isRef,ipAddr,domainName);
				if (err) domainName[0] = '\0'; // failure was indicated
			}
		}
	}
	return domainName;
}

char* MapNameToAddress ( char* domainName, char* ipAddress )
{
	ipAddress[0] = '\0'; // assume failure

	OSStatus err = InitOpenTransport();
	if (!err)
	{
		TInternetServices* isRef = OTOpenInternetServices(kDefaultInternetServicesPath,0,&err);
		if (!err)
		{
			InetHostInfo hinfo;
			err = OTInetStringToAddress(isRef,domainName,&hinfo);
			if (!err) OTInetHostToString(hinfo.addrs[0],ipAddress);
		}
	}
	return ipAddress;
}



#endif
/********************************************************************/

int _readDictionary(NetConn *conn);
int _readData(NetConn *conn);
unsigned char *_decriptionKeyMap(unsigned char *keyString);

int connectToPort(NetConn *conn, int portNumber,char *hostName)
{
    int ret = netConnect(portNumber, hostName);

    if (ret == -1) {
        return 0;
    }
    conn->socketConnection = (unsigned int)ret;
    return syncronizeVersion(conn);
}



// clearing data
void initComm(NetConn *conn)
{
    int ct;
    for (ct=0; ct < 30; ct++) {
        conn->resultKeys[ct] = NULL;
        conn->keyBufferSize[ct] = 0;
        conn->resultValues[ct] = NULL;
        conn->valueBufferSize[ct] = 0;
        conn->resultLength[ct] = 0;
    }
    conn->didInit = YES;
}

void clearComm(NetConn *conn)
{
    if (!conn->didInit) initComm(conn);
}


// SENDING INFORMATION TO SERVER
int prepareData(NetConn *conn, const char *data, int datalen, const char *parameter, const char *action)
{
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    int position = 0;
    
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)"|data|", 6, privateEncriptionMap);
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)action, strlen(action), privateEncriptionMap);
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)parameter, strlen(parameter), privateEncriptionMap);
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)data, datalen, privateEncriptionMap);
    
    conn->dictionaryLength = position;

    return position;
}

void prepareDictionary(NetConn *conn)
{
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);
    int position = 0;

    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)"|dict|", 6, privateEncriptionMap);

    conn->dictionaryLength = position;
}

void addDictionaryPair(NetConn *conn, const char *key, const char *value)
{
    int position;
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);

    position = conn->dictionaryLength;
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)key, strlen(key), privateEncriptionMap);
    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)value, strlen(value), privateEncriptionMap);
    conn->dictionaryLength = position;
}

int sendBuffer(NetConn *conn)
{
    int terminator = -1;
    int position;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    
    // add terminator
    position = conn->dictionaryLength;
    ob_intToBytes((*buffer + position), terminator);
    position = position + sizeof(int);
    conn->dictionaryLength = position;
    
    return netSndRaw(conn->dictionaryBuffer, conn->dictionaryLength, conn->socketConnection);
}

// RECEIVING FROM SERVER
int _readDictionary(NetConn *conn)
{
    int ct;
    int len = 0;
    
    for (ct = 0;; ct++) {
    	if (conn->resultKeys[ct] == NULL) {
	        conn->resultKeys[ct] = (unsigned char *)malloc(50);
            conn->keyBufferSize[ct] = 50;
    	}
        if (conn->resultValues[ct] == NULL) {
        	conn->resultValues[ct] = (unsigned char *)malloc(256); 
        	conn->valueBufferSize[ct] = 256;
		}
        
        //netRcvToken(&(conn->resultKeys[ct]), &(conn->keyBufferSize[ct]), conn->socketConnection, unsigned char *decodemap)

        len = (int)netRcvToken(&(conn->resultKeys[ct]), &(conn->keyBufferSize[ct]), conn->socketConnection, conn->privateDecriptionMap);
        if (len == -2L) { // terminator found
            break;
        }
        if (len == -1L) { // error
            return -1;
        }

        len = (int)netRcvToken(&(conn->resultValues[ct]), &(conn->valueBufferSize[ct]), conn->socketConnection, conn->privateDecriptionMap);

        if ((len == -1L) || (len == -2L)) { // error
            return -1;
        }
        conn->resultLength[ct] = len;
    }

    conn->numberOfKeys = ct;
    conn->resultLength[ct] = 0;
    return 1;
}

int _readData(NetConn *conn)
{
    int len = 0;

    if (conn->resultKeys[0] == NULL) {
    	conn->resultKeys[0] = (unsigned char *)malloc(256); 
    	conn->keyBufferSize[0] = 256;
	}
    if (conn->resultValues[0] == NULL) {
    	conn->resultValues[0] = (unsigned char *)malloc(256); 
    	conn->valueBufferSize[0] = 256;
	}
	
    if (conn->resultKeys[1] == NULL) {
    	conn->resultKeys[1] = (unsigned char *)malloc(256); 
    	conn->keyBufferSize[1] = 256;
	}
    if (conn->resultValues[1] == NULL) {
    	conn->resultValues[1] = (unsigned char *)malloc(256); 
    	conn->valueBufferSize[1] = 256;
	}

    if (conn->resultKeys[2] == NULL) {
    	conn->resultKeys[2] = (unsigned char *)malloc(256); 
    	conn->keyBufferSize[2] = 256;
	}
		
    if (conn->resultValues[2] == NULL) {
        conn->resultValues[2] = (unsigned char *)malloc(256);
        conn->valueBufferSize[2] = 256;
    }

    // only to get terminator
    if (conn->resultValues[3] == NULL) {
        conn->resultValues[3] = (unsigned char *)malloc(256);
        conn->valueBufferSize[3] = 256;
    }
	
    strcpy((char*)conn->resultKeys[0],"action");
    len = (int)netRcvToken(&(conn->resultValues[0]), &(conn->valueBufferSize[0]), conn->socketConnection, conn->privateDecriptionMap);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[0] = len;

    strcpy((char*)conn->resultKeys[1],"parameter");
    len = (int)netRcvToken(&(conn->resultValues[1]), &(conn->valueBufferSize[1]), conn->socketConnection, conn->privateDecriptionMap);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[1] = len;

    strcpy((char*)conn->resultKeys[2],"data");
    len = (int)netRcvToken(&(conn->resultValues[2]), &(conn->valueBufferSize[2]), conn->socketConnection, conn->privateDecriptionMap);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[2] = len;

    // this is only to get terminator
    len = (int)netRcvToken(&(conn->resultValues[3]), &(conn->valueBufferSize[3]), conn->socketConnection, conn->privateDecriptionMap);
    if (len != -2L) { // must be a terminator
        return -1;
    }

    
    conn->resultLength[3] = 0;
    conn->numberOfKeys = 3;
    return 1;
}

int readResult(NetConn *conn)
{
    char *header = (char*)malloc(10);
    int headerLength = 10;
    int ret = 0;
    int len = 0;
    
    clearComm(conn);

    len = (int)netRcvToken((unsigned char **)&header, &headerLength, conn->socketConnection, conn->privateDecriptionMap);
    if ((len == -1L) || (len == -2L)) { // error
        return 0;
    }

    if (strcmp((char*)header,"|dict|")==0) {
        ret = _readDictionary(conn);
    } else if (strcmp((char*)header,"|data|")==0){
        ret = _readData(conn);
    }
    free(header);
    return ret;
}

char *resultValueForKey(NetConn *conn, const char *key, int *valuelength)
{
    int ct;

    for (ct = 0; ct < conn->numberOfKeys; ct++) {
        if (strcmp(key, (char*)conn->resultKeys[ct])==0) {
            *valuelength = conn->resultLength[ct];
            return (char*)conn->resultValues[ct];
        }
    }
    return NULL;
}

unsigned char *_decriptionKeyMap(unsigned char *keyString)
{
    unsigned char *decriptMap = (unsigned char *)malloc(256);
    int ct;
    for (ct =0; ct < 256; ct++) {
        decriptMap[keyString[ct]] = (unsigned char)ct;
    }

    return decriptMap;
}


int syncronizeVersion(NetConn *conn)
{
    unsigned char buffer[20];
    int ret = 0;

    buffer[0] = '#';
    buffer[1] = strlen(COMM_VERSION);
    strcpy((char *)&buffer[2], (const char *)COMM_VERSION);

    ret = netSndRaw(buffer, 5, conn->socketConnection);
    if (!ret) {
        netClose(conn->socketConnection);
        return 0;
    }
    if (OBSocketRead(conn->socketConnection, buffer, 1) != 1) {
        netClose(conn->socketConnection);
        return 0;
    }
    if (*buffer == 1) {
        return 1;
    }
    netClose(conn->socketConnection);
    return 0;
}

void sendExitSignal(NetConn *conn)
{
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);
    int position = 0;

    position = position + copyAndFixString(buffer, len, position, (const unsigned char *)"|exit|", 6, privateEncriptionMap);

    conn->dictionaryLength = position;
    netSndRaw(conn->dictionaryBuffer, conn->dictionaryLength, conn->socketConnection);

    return;
}


void startPrivateTransmission(NetConn *conn)
{
	char *value;
    int len = 0;
    
    prepareDictionary(conn);
    addDictionaryPair(conn, "action", "privateConnection");
    sendBuffer(conn);
    if (!readResult(conn)) {
        return;
    }

    value = (char *)resultValueForKey(conn, "result", &len);
    if (!value || strcmp((const char *)value,"no") == 0 || len < 255) {
        return;
    }

    conn->privateEncriptionMap = (unsigned char *)malloc(256);
    conn->privateEncriptionMap[0] = '\0';
    memcpy((conn->privateEncriptionMap + 1), value, 255);
    conn->privateDecriptionMap = (unsigned char *)_decriptionKeyMap(conn->privateEncriptionMap);
    conn->privateConnection = YES;
}


