// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
#include "platform.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "CommAPI.h"
#include "OB_Memory.h"

#if MACOSX_CARBON 
	#include <strings.h>
	#include <OpenTransport.h>
#endif

#ifdef WINNT
	#include <wtypes.h>
#endif

#ifdef MACOSX_UNIX
	#include <sys/socket.h>
#endif

#include "NetClient.h"
#include "OpenBaseConnection.h"
#include "OpenBaseSupport.h"


#define DISABLE_PRIVATE_TRANSMISSION

int _readDictionary(NetConnPtr conn);

int _readData(NetConnPtr conn);

// ------------------------------------------------------------------------------------------

#ifdef MACOS_CARBON

	#ifdef TARGET_API_MAC_CARBON
	char* MapAddressToName ( char* ipAddress, char* domainName, 
							OTClientContextPtr outClientContext)
	#else
	char* MapAddressToName ( char* ipAddress, char* domainName, OTClientContextPtr)
	#endif

	{
	domainName[0] = '\0'; // assume failure
	OSStatus err;

	#ifdef TARGET_API_MAC_CARBON
		InetSvcRef isRef = OTOpenInternetServicesInContext( kDefaultInternetServicesPath, 
															0, &err, outClientContext);
	#else
		InetSvcRef isRef = OTOpenInternetServices(kDefaultInternetServicesPath, 0, &err);
	#endif

	if (!err)
	{
		InetHost ipAddr;
		err = OTInetStringToHost(ipAddress,&ipAddr);
		if (!err)
		{
			err = OTInetAddressToName(isRef,ipAddr,domainName);
			if (err) domainName[0] = '\0'; // failure was indicated
		}
	}
	return domainName;
}

#ifdef TARGET_API_MAC_CARBON
char* MapNameToAddress ( char* domainName, char* ipAddress, 
						 OTClientContextPtr outClientContext)
#else
char* MapNameToAddress ( char* domainName, char* ipAddress, OTClientContextPtr)
#endif
{
	ipAddress[0] = '\0'; // assume failure
	OSStatus err;

#ifdef TARGET_API_MAC_CARBON
	InetSvcRef isRef = OTOpenInternetServicesInContext( kDefaultInternetServicesPath, 
														0, &err, outClientContext);
#else
	InetSvcRef isRef = OTOpenInternetServices(kDefaultInternetServicesPath, 0, &err);
#endif
	if (!err)
	{
		InetHostInfo hinfo;
		err = OTInetStringToAddress(isRef,domainName,&hinfo);
		if (!err) OTInetHostToString(hinfo.addrs[0],ipAddress);
	}
	return ipAddress;
}

// ------------------------------------------------------------------------------------------
#else
#ifdef WINNT

char* MapNameToAddress ( char* domainName, char* ipAddress )
{
    unsigned long ulAddr;
    struct hostent *hostEntP;

    ipAddress[0] = '\0'; // assume failure

    ulAddr = inet_addr((char*)domainName);

    if (ulAddr != ((unsigned long)-1)) {
        strcpy(ipAddress, domainName);
    } else {
        hostEntP = gethostbyname((char*)domainName);
        if ((hostEntP != NULL) && (hostEntP->h_addr_list != NULL)) {
            char* address_ptr = hostEntP->h_addr_list[0];
            if (address_ptr != NULL) {
                char* address = inet_ntoa(*(in_addr*) address_ptr);
                if (address != NULL) {
                        strcpy(ipAddress, address);
                }
            }
        }
    }

    return ipAddress;
}

#endif
#endif


// ------------------------------------------------------------------------------------------

// ------------------------------------------------------------------------------------------

int connectToPort(NetConnPtr conn, int portNumber,const char *hostName)
{
#ifdef MACOS_CARBON
    EndpointRef     ret = kOTInvalidEndpointRef;
	TBind			server_info;
	TBind			client_info;
	unsigned char	server_address[256];
	unsigned char	client_address[256];
	OSStatus		err = noErr;

	server_info.addr.maxlen = 256;
	server_info.addr.buf = server_address;
	client_info.addr.maxlen = 256;
	client_info.addr.buf = client_address;
#else 

#ifdef WINNT
	struct sockaddr_in	client_address;			//	internet style socket address
	struct sockaddr_in	server_address;			//	internet style socket address
#else
	struct sockaddr	*client_address;			//	internet style socket address
	struct sockaddr	*server_address;			//	internet style socket address
#endif
	int ret = -1;
//	int client_len;
//	int server_len;
#endif
	

#ifdef MACOS_CARBON
    ret = netConnect(portNumber, hostName, conn->outClientContext);
    if (ret == kOTInvalidEndpointRef) 
    {
    	conn->socketConnection = kOTInvalidEndpointRef;	// ��dmr
        return 0;
    }
    conn->socketConnection = ret;
#else 
    ret = netConnect(portNumber, hostName);
    if (ret == -1) {
        return 0;
    }
    conn->socketConnection = (unsigned int)ret;
#endif

#ifdef MACOS_CARBON
	err = OTGetProtAddress(conn->socketConnection, &client_info, &server_info);
	if (err == noErr) 
	{
		sprintf(conn->serverAddress, "%u.%u.%u.%u", server_address[4],
					server_address[5], server_address[6], server_address[7]);
		sprintf(conn->clientAddress, "%u.%u.%u.%u", client_address[4],
					client_address[5], client_address[6], client_address[7]);
	}
#endif

#ifdef WINNT
	client_len = sizeof(client_address);
	if (getsockname(conn->socketConnection, (struct sockaddr*) &client_address, &client_len) == 0) {
		sprintf(conn->clientAddress, "%u.%u.%u.%u",
					client_address.sin_addr.S_un.S_un_b.s_b1,
					client_address.sin_addr.S_un.S_un_b.s_b2,
					client_address.sin_addr.S_un.S_un_b.s_b3,
					client_address.sin_addr.S_un.S_un_b.s_b4	);
					
	} else {
            sprintf(conn->clientAddress, "Error...");
	}

	server_len = sizeof(server_address);
	if (getpeername(conn->socketConnection, (struct sockaddr*) &server_address, &server_len) == 0) {
		sprintf(conn->serverAddress, "%u.%u.%u.%u",
					server_address.sin_addr.S_un.S_un_b.s_b1,
					server_address.sin_addr.S_un.S_un_b.s_b2,
					server_address.sin_addr.S_un.S_un_b.s_b3,
					server_address.sin_addr.S_un.S_un_b.s_b4	);
	} else {
            sprintf(conn->clientAddress, "Error...");
	}
#endif
    
    return syncronizeVersion(conn);
}

// ------------------------------------------------------------------------------------------

// clearing data
void initComm(NetConnPtr conn)
{
    int ct;

    for (ct = 0; ct < OB_MAX_KEYS; ct++) { 
        conn->resultKeys[ct] 		= NULL;
        conn->keyBufferSize[ct] 	= 0;
        conn->resultValues[ct] 		= NULL;
        conn->valueBufferSize[ct] 	= 0;
        conn->resultLength[ct] 		= 0;
    }

    conn->didInit = YES;

    conn->privateConnection = NO;
}

// ------------------------------------------------------------------------------------------

void clearComm(NetConnPtr conn)
{
if (0 == conn->didInit) 
	initComm(conn);
}


// ------------------------------------------------------------------------------------------

int ob_copyAndFixString(unsigned char **tostring, int *tosize, int position, const unsigned char *str, int length, unsigned char *codedmap)
{
    char *strdest;

    // make sure the string is long enough
    if ((length + position) > (*tosize - 10)) {
        *tosize = *tosize * 2;
        // if doubling size isn't enough
        if ((length + position) > (*tosize - 10)) {
            *tosize = (length + position + 10);
        }
        //	*tostring = (unsigned char *)realloc(*tostring, *tosize);
        *tostring = (unsigned char *)ob_realloc(*tostring, *tosize);
    }

    strdest = (char *)*tostring + position;

    // copy the size of the string to the buffer
    ob_intToBytes((unsigned char *)strdest, length);
    strdest = strdest + sizeof(int);

    // copy the string itself to the buffer
    if (!codedmap) {
        memcpy(strdest, str, length);
    } else { // encode during copy
        int ct;

        for (ct=0; ct != length; ct++) {
            strdest[ct] = codedmap[(unsigned int)str[ct]];
        }
    }
    strdest[length] = '\0';
    //printf("SEND TOKEN(%d) = %s\n", length, strdest);
    return (length + sizeof(int));
}

// ------------------------------------------------------------------------------------------

//extern int out ( const char* );

// SENDING INFORMATION TO SERVER
int prepareData(NetConnPtr conn, const char *data, int datalen, 
				const char *parameter, const char *action)
{
    unsigned char **buffer = &(conn->dictionaryBuffer);
    
    int *len = &(conn->dictionaryBufferSize);
    
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    
    int position = 0;
    
    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)"|data|", 6, privateEncriptionMap);
    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)action, strlen(action), privateEncriptionMap);
    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)parameter, strlen(parameter), privateEncriptionMap);
    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)data, datalen, privateEncriptionMap);
    conn->dictionaryLength = position;

    return position;
}

// ------------------------------------------------------------------------------------------

void prepareDictionary(NetConnPtr conn)
{
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);
    int position = 0;

    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)"|dict|", 6, privateEncriptionMap);

    conn->dictionaryLength = position;
}

// ------------------------------------------------------------------------------------------

void addDictionaryPair(NetConnPtr conn, const char *key, const char *value)
{
    int position;
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);

    position = conn->dictionaryLength;
    position = position + ob_copyAndFixString( buffer, len, position, (const unsigned char*)key,
    										strlen(key), privateEncriptionMap);
    position = position + ob_copyAndFixString( buffer, len, position, (const unsigned char*)value, 
    										strlen(value), privateEncriptionMap);
    conn->dictionaryLength = position;
}

// ------------------------------------------------------------------------------------------

int sendBuffer(NetConnPtr conn)
{
    int terminator = -1;
    int position;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    
    // add terminator
    position = conn->dictionaryLength;
    ob_intToBytes((*buffer + position), terminator);
    position = position + sizeof(int);
    conn->dictionaryLength = position;
    
    return netSndRaw(conn->dictionaryBuffer, conn->dictionaryLength, conn->socketConnection);
}

// ------------------------------------------------------------------------------------------

// RECEIVING FROM SERVER
int _readDictionary(NetConnPtr conn)
{
    int ct;
    int len = 0;
    int flag = 0;
	
    for (ct = 0;; ct++) {
    	if (conn->resultKeys[ct] == NULL) {
	        //	conn->resultKeys[ct] = (unsigned char *)malloc(50);
	        conn->resultKeys[ct] = (unsigned char *)ob_malloc(50);
            conn->keyBufferSize[ct] = 50;
    	}
        if (conn->resultValues[ct] == NULL) {
        	//	conn->resultValues[ct] = (unsigned char *)malloc(256); 
        	conn->resultValues[ct] = (unsigned char *)ob_malloc(256); 
        	conn->valueBufferSize[ct] = 256;
		}
       
        len = (int)netRcvToken(&(conn->resultKeys[ct]), &(conn->keyBufferSize[ct]), 
        						conn->socketConnection, conn->privateDecriptionMap, &flag);
        if (len == -2L) { // terminator found
            break;
        }
        if (len == -1L) { // error
            return -1;
        }

        len = (int)netRcvToken(&(conn->resultValues[ct]), &(conn->valueBufferSize[ct]), 
        						conn->socketConnection, conn->privateDecriptionMap, &flag);

        if ((len == -1L) || (len == -2L)) { // error
            return -1;
        }
        conn->resultLength[ct] = len;
    }

    conn->numberOfKeys = ct;
    conn->resultLength[ct] = 0;
    return 1;
}

// ------------------------------------------------------------------------------------------

int _readData(NetConnPtr conn)
{
    int len = 0;
	int flag = 0;
	
    if (conn->resultKeys[0] == NULL) {
    	//	conn->resultKeys[0] = (unsigned char *)malloc(256); 
    	conn->resultKeys[0] = (unsigned char *)ob_malloc(256); 
    	conn->keyBufferSize[0] = 256;
	}
    if (conn->resultValues[0] == NULL) {
    	//	conn->resultValues[0] = (unsigned char *)malloc(256); 
    	conn->resultValues[0] = (unsigned char *)ob_malloc(256); 
    	conn->valueBufferSize[0] = 256;
	}
	
    if (conn->resultKeys[1] == NULL) {
    	//	conn->resultKeys[1] = (unsigned char *)malloc(256); 
    	conn->resultKeys[1] = (unsigned char *)ob_malloc(256); 
    	conn->keyBufferSize[1] = 256;
	}
    if (conn->resultValues[1] == NULL) {
    	//	conn->resultValues[1] = (unsigned char *)malloc(256); 
    	conn->resultValues[1] = (unsigned char *)ob_malloc(256); 
    	conn->valueBufferSize[1] = 256;
	}

    if (conn->resultKeys[2] == NULL) {
    	//	conn->resultKeys[2] = (unsigned char *)malloc(256); 
    	conn->resultKeys[2] = (unsigned char *)ob_malloc(256); 
    	conn->keyBufferSize[2] = 256;
	}
		
    if (conn->resultValues[2] == NULL) {
        //	conn->resultValues[2] = (unsigned char *)malloc(256);
        conn->resultValues[2] = (unsigned char *)ob_malloc(256);
        conn->valueBufferSize[2] = 256;
    }

    // only to get terminator
    if (conn->resultValues[3] == NULL) {
        //	conn->resultValues[3] = (unsigned char *)malloc(256);
        conn->resultValues[3] = (unsigned char *)ob_malloc(256);
        conn->valueBufferSize[3] = 256;
    }
	
    strcpy((char*)conn->resultKeys[0],"action");
    len = (int)netRcvToken(&(conn->resultValues[0]), &(conn->valueBufferSize[0]), 
    						conn->socketConnection, conn->privateDecriptionMap, &flag);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[0] = len;

    strcpy((char*)conn->resultKeys[1],"parameter");
    len = (int)netRcvToken(&(conn->resultValues[1]), &(conn->valueBufferSize[1]), 
    						conn->socketConnection, conn->privateDecriptionMap, &flag);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[1] = len;

    strcpy((char*)conn->resultKeys[2],"data");
    len = (int)netRcvToken(&(conn->resultValues[2]), &(conn->valueBufferSize[2]), 
    						conn->socketConnection, conn->privateDecriptionMap, &flag);
    if ((len == -1L) || (len == -2L)) { // error
        return -1;
    }
    conn->resultLength[2] = len;

    // this is only to get terminator
    len = (int)netRcvToken(&(conn->resultValues[3]), &(conn->valueBufferSize[3]), 
    						conn->socketConnection, conn->privateDecriptionMap, &flag);
    if (len != -2L) { // must be a terminator
        return -1;
    }

    
    conn->resultLength[3] = 0;
    conn->numberOfKeys = 3;
    return 1;
}

// ------------------------------------------------------------------------------------------

int readResult(NetConn *conn)
{
    char *header = (char*)ob_malloc(10);
    int headerLength = 10;
    int ret = 0;
    int len = 0;
    int flag = 0;
	
    clearComm(conn);

    len = (int)netRcvToken((unsigned char **)&header, &headerLength, conn->socketConnection, conn->privateDecriptionMap, &flag);
    if ((len == -1L) || (len == -2L)) { // error
        ob_free(header);
        return 0;
    }

    if (strcmp((char*)header,"|dict|")==0) {
        ret = _readDictionary(conn);
    } else if (strcmp((char*)header,"|data|")==0){
        ret = _readData(conn);
    }
    ob_free(header);
    return ret;
}


// ------------------------------------------------------------------------------------------


char *resultValueForKey(NetConnPtr conn, const char *key, int *valuelength)
{
    int ct;

    for (ct = 0; ct < conn->numberOfKeys; ct++) {
        if (strcmp(key, (char*)conn->resultKeys[ct])==0) {
            *valuelength = conn->resultLength[ct];
            return (char*)conn->resultValues[ct];
        }
    }
    *valuelength = 0;
    return NULL;
}

// ------------------------------------------------------------------------------------------

static unsigned char *_decriptionKeyMap(unsigned char *keyString) //��dmr static!
{
    //	unsigned char *decriptMap = (unsigned char *)malloc(256);
    unsigned char *decriptMap = (unsigned char *)ob_malloc(256);
    int ct;
    for (ct =0; ct < 256; ct++) {
        decriptMap[keyString[ct]] = (unsigned char)ct;
    }

    return decriptMap;
}

// ------------------------------------------------------------------------------------------

int syncronizeVersion(NetConnPtr conn)
{
    unsigned char buffer[20];
    int ret = 0;
	int flag = 0;
	
    buffer[0] = '#';
    buffer[1] = strlen(COMM_VERSION);
    strcpy((char *)&buffer[2],COMM_VERSION);

    ret = netSndRaw(buffer, 5, conn->socketConnection);
    if (!ret) 
    {
        netClose(conn->socketConnection);
		#ifdef MACOS_CARBON
	        conn->socketConnection = kOTInvalidEndpointRef;	
		#endif
        return 0;
    }
    if (OBSocketRead(conn->socketConnection, (unsigned char *)buffer, 1, &flag) != 1) 
    {
        netClose(conn->socketConnection);
		#ifdef MACOS_CARBON
	    	conn->socketConnection = kOTInvalidEndpointRef;	
		#endif
        return 0;
    }
    if (*buffer == 1) {
        return 1;
    }
    netClose(conn->socketConnection);

	#ifdef MACOS_CARBON
	    conn->socketConnection = kOTInvalidEndpointRef;
	#endif
	
    return 0;
}

// ------------------------------------------------------------------------------------------

void sendExitSignal(NetConnPtr conn)
{
    unsigned char *privateEncriptionMap = conn->privateEncriptionMap;
    unsigned char **buffer = &(conn->dictionaryBuffer);
    int *len = &(conn->dictionaryBufferSize);
    int position = 0;

    position = position + ob_copyAndFixString(buffer, len, position, 
    			(const unsigned char*)"|exit|", 6, privateEncriptionMap);

    conn->dictionaryLength = position;
    netSndRaw(conn->dictionaryBuffer, conn->dictionaryLength, conn->socketConnection);

    return;
}

// ------------------------------------------------------------------------------------------

void startPrivateTransmission(NetConnPtr conn)
{
    unsigned char *value;
    int len = 0;
    
    prepareDictionary(conn);
    addDictionaryPair(conn, "action", "privateConnection");
    sendBuffer(conn);
    if (!readResult(conn)) {
        return;
    }

    value = (unsigned char *)resultValueForKey(conn, "result", &len);
    if (!value || strcmp((const char *)value,(const char*)"no") == 0 || len < 255) {
        return;
    }

    //	conn->privateEncriptionMap = (unsigned char *)malloc(256);
    conn->privateEncriptionMap = (unsigned char *)ob_malloc(256);
    conn->privateEncriptionMap[0] = '\0';
    memcpy((conn->privateEncriptionMap + 1), value, 255);
    conn->privateDecriptionMap = (unsigned char *)_decriptionKeyMap(conn->privateEncriptionMap);
    conn->privateConnection = YES;
}

// ------------------------------------------------------------------------------------------
