/* API_Header.h created by root on Mon 06-Dec-1999 */

#define RHAPSODY
//#define OPEN_TRANSPORT
//#define SWAPINDIAN

#ifdef i386
#define SWAPINDIAN
#endif
#ifdef x86
#define SWAPINDIAN
#endif

#define OBSocketRead(socketFD, buffer, byteCount) ob_socketread(socketFD, buffer, byteCount)
#define OBSocketWrite(socketFD, buffer, byteCount) send(socketFD, buffer, byteCount,0)
#define OBSocketClose(socketFD) shutdown(socketFD, 2); close(socketFD)


#define IS_NULL_VALUE(value)   (*value == -74) && (*(value+1) == '\0')

//================================================================================
//	Boolean constants
//================================================================================

#define OB_BOOL		int
#define	OB_TRUE		1
#define	OB_FALSE	0

//--------------------------------------------------------------------------------
//	Limits
//--------------------------------------------------------------------------------

enum
{
	OB_MAX_KEYS					= 30,
	OB_MAX_COLUMNS				= 400,
	OB_MAX_DATABASES			= 400
};

//================================================================================
//	Definitions
//================================================================================

#define YIELD_THREAD 	/*YieldToAnyThread()*/

#define DEALLOC(ptr)    if (ptr != NULL) { free(ptr); ptr = NULL; }


#ifdef __cplusplus
}
#endif
