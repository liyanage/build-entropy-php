// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
//
// [jsh] 11/07/2003
//		Moved ob_releaseBuffers here from OT_NetClient.cpp.
//		Added missing prototypes and deleted extraneous ones.
//		Added const keyword to bind functions.
//		Added pointer typedefs.
//		Added functions to access date and time formatting preferences.
//
// -----------------------------------------------------------------------------

#ifndef __OPENBASECONNECTION_H__
#define	__OPENBASECONNECTION_H__

#include "OpenBaseEncoding.h"

#ifdef __cplusplus
extern "C" {
#endif

enum
	{
	OBTYPE_CHAR					= 1,
	OBTYPE_INT					= 2,
	OBTYPE_FLOAT				= 3,
	OBTYPE_LONG					= 4,
	OBTYPE_MONEY				= 5,
	OBTYPE_DATE					= 6,
	OBTYPE_TIME					= 7,
	OBTYPE_OBJECT				= 8,
	OBTYPE_DATETIME				= 9,
	OBTYPE_LONGLONG				= 10,
	OBTYPE_BOOLEAN				= 11,
	OBTYPE_BINARY				= 12,
	OBTYPE_OBJECT_TEXT			= 13,
	OBTYPE_TIMESTAMP			= 14
	};

enum
	{
	ERR_SFTUSRLIM				= 1,
	ERR_DBSUSRLIM				= 2,
	ERR_DBSLIM					= 3,
	ERR_DBSDUP					= 4,
	ERR_NOSERVER				= 5,
	ERR_INCORRECT_LOGIN			= 6,
	ERR_SERVER_RESTARTING		= 7,
	ERR_WEBOBJECTS_VIOLATION	= 8,
	ERR_LITE_VIOLATION			= 9
	};
	
enum
	{
	OB_MAX_KEYS					= 30,
	OB_MAX_COLUMNS				= 400
	};
	
// -----------------------------------------------------------------------------

struct NetConnStruct 
{
	unsigned char* 		resultKeys[OB_MAX_KEYS];
	unsigned char* 		resultValues[OB_MAX_KEYS];
	int					keyBufferSize[OB_MAX_KEYS];
	int					valueBufferSize[OB_MAX_KEYS];
	int					resultLength[OB_MAX_KEYS];
	int					numberOfKeys;
	int					didInit;
	int					connectionPort;
	unsigned char* 		dictionaryBuffer;
	int					dictionaryBufferSize;
	int					dictionaryLength;
	
	/* for buffered reading */
	int					readPosition;

	/* for encryption */
	int					privateConnection;
	unsigned char* 		privateEncriptionMap;
	unsigned char* 		privateDecriptionMap;

	//	addresses of client and server
	char				clientAddress[256];
	char				serverAddress[256];

	#ifdef MACOS_CARBON
		OTClientContextPtr  outClientContext;
		EndpointRef			socketConnection;
	#else
		unsigned int			socketConnection;
	#endif

};
	
typedef struct NetConnStruct  NetConn;
typedef NetConn * NetConnPtr;
// -----------------------------------------------------------------------------

struct OpenBaseResultDataStruct 
{
    struct OpenBaseResultDataStruct *next;

    // result data
    char *resultData;
    int resultDataLength;
    int resultDataNeedsDealloc;
} ;

typedef struct OpenBaseResultDataStruct  OpenBaseResultData;
typedef OpenBaseResultData * OpenBaseResultDataPtr;

// -----------------------------------------------------------------------------

struct OpenBaseCursorStruct 
{
    struct OpenBaseCursorStruct *pushedResult;
    
    // result data
    //char *resultData;
    //int resultDataLength;
    OpenBaseResultDataPtr resultPage;
    
    // resultInformation
    int maxInitializedTables;
    int maxInitializedColumns;
    char *tableNames[OB_MAX_COLUMNS];
    char *columnNames[OB_MAX_COLUMNS];
    char targetTypes[OB_MAX_COLUMNS];
    unsigned char resultIsNull[OB_MAX_COLUMNS];
    int columnsReturned;
    int rowsAffected;
    
    char *bindVariables[OB_MAX_COLUMNS];
    char bindTargetTypes[OB_MAX_COLUMNS];
    int maxVariablesBound;
    
    // estimated column widths
    int	columnWidths[OB_MAX_COLUMNS];
    
    // state information
    int readMoreResult;
    int readPosition;
    const char *errorMessage;
    int skipConvert;

};

typedef struct OpenBaseCursorStruct OpenBaseCursor;
typedef OpenBaseCursor * OpenBaseCursorPtr;

// -----------------------------------------------------------------------------

struct OpenBaseStruct 
{
    NetConnPtr connection;
    NetConnPtr altConnection;
    OpenBaseCursorPtr resultset;
    
	/* login information */
    char databaseName[100];
    char databaseHost[100];
    char databaseLogin[100];
    char databasePassword[100];
    char softwareId[100];
	char clientName[100];
	
    char tmp[100];
	/* SQLBuffer */
    char *sqlBuffer;
    int sqlBufferSize;
    int position;


    // prepared SQL
    char *preparedSQL[OB_MAX_COLUMNS];
    int numberOfPreparedValues;
    int prepareValuePosition;
    
    char invalidate;
    int databaseEncoding;
    int clientEncoding;
    char insertedRowidValue[30];
    
    int autoReconnectFlag;
    int transactionInProgress;
    char secondaryHost[100];
    char secondaryDatabase[100];

	#ifdef MACOS_CARBON
	    OTClientContextPtr  outClientContext;
	#endif

};

typedef struct OpenBaseStruct OpenBase;
typedef OpenBase * OpenBasePtr;

// -----------------------------------------------------------------------------

#ifdef MACOS_CARBON 

	char	*MapNameToAddress(char* domainName, char* ipAddress, OTClientContextPtr outClientContext);

	OpenBasePtr ob_newConnection(OTClientContextPtr newClientContext);

#else

	OpenBasePtr ob_newConnection(void);

#endif


int				ob_abortFetch(OpenBasePtr conn);
int				ob_beginTransaction(OpenBasePtr conn);
int				ob_beginPassiveTransaction(OpenBasePtr conn); //jsh] 10/17/2003
int 			ob_isTransactionInProgress(OpenBasePtr conn);
void			ob_bindDouble(OpenBasePtr conn, const double* var);
void 			ob_bindBoolean(OpenBasePtr conn, const int *var);
void			ob_bindInt(OpenBasePtr conn, const int* var);
void			ob_bindLong(OpenBasePtr conn, const long* var);
void			ob_bindLongLong(OpenBasePtr conn, const int* var);
void			ob_bindString(OpenBasePtr conn, const char* var);
void 			ob_bindBinary(OpenBasePtr conn, const char *var);
int				ob_bufferHasCommands(OpenBasePtr conn);
void			ob_clearCommands(OpenBasePtr conn);
char* 			ob_commandBuffer(OpenBasePtr conn);
int				ob_commitTransaction(OpenBasePtr conn);
const char* 	ob_connectErrorMessage(OpenBasePtr conn);
int				ob_checkConnectionToDatabase(OpenBasePtr conn, const char *dbHostName); //jsh] 10/17/2003
int				ob_connectToDatabase(OpenBasePtr	connection, 
									 const char*	dbName, 
									 const char*	dbHostName, 
									 const char*	loginName, 
									 const char*	passwordString, 
									 const char*	softwareId,
									 const char*	clientName,
									 int*			returnCode);
									 
char* 			ob_databaseName(OpenBasePtr conn);

// -----------------------------------------------------------------------------
// [jsh] 11/07/2003
// date and time formatting used in ob_nextCursorRow
// -----------------------------------------------------------------------------
int				getDateFormatType();
void			setDateFormatType(int dateFormat);
int				getTimeFormatType();
void			setTimeFormatType(int timeFormat);

// -----------------------------------------------------------------------------
// encoding conversion
// -----------------------------------------------------------------------------
int convertStringToDatabaseEncoding(OpenBasePtr conn, const char *source, char *target);
int convertStringFromDatabaseEncoding(OpenBasePtr conn, const char *source, char *target);
int convertStringToDatabaseEncodingLength(OpenBasePtr conn, const char *source, char *target, int len);
int convertStringFromDatabaseEncodingLength(OpenBasePtr conn, const char *source, char *target, int len);

// -----------------------------------------------------------------------------

int                   ob_databaseEncoding(OpenBasePtr conn);
int                   ob_clientEncoding(OpenBasePtr conn);
void                  ob_setClientEncoding(OpenBasePtr conn, int encoding);
void			      ob_deallocBinary(const char* blob);
void 			      ob_deallocConnection(OpenBasePtr conn); // invalidate and free the connection
void 			      ob_deallocNetConn(NetConnPtr conn);
void 			      ob_deallocResultData(OpenBaseResultDataPtr resultData);		// ��� LD September 4, 2001 
void 			      ob_deallocResultDataList(OpenBaseResultDataPtr resultData); 	// ��� LD September 4, 2001 
int				      ob_executeCommand(OpenBasePtr conn);
const char 		      *ob_insertedRowid(OpenBasePtr conn);
char* 			      ob_hostName(OpenBasePtr conn);
const char* 	      ob_insertBinary(OpenBasePtr conn, const char* data, int size);
void			      ob_invalidate(OpenBasePtr conn);
int				      ob_isColumnNULL(OpenBasePtr conn, int col);
const char*           ob_loginName(OpenBasePtr conn);
void		      	  ob_makeCommand(OpenBasePtr conn, const char* cmd);
void		      	  ob_makeCommandLength(OpenBasePtr conn, const char* cmd, int length);
void                  ob_makeCommandLengthAndEncode(OpenBasePtr conn, const char *cmd, int length);
void                  ob_makeCommandAndEncode(OpenBasePtr conn, const char *cmd);
int				      ob_markRow(OpenBasePtr conn, const char* anId, const char* tableName);
int				      ob_markRowAlreadyMarkedByUser(OpenBasePtr conn, const char* anId, const char* tableName, char* userName);
NetConnPtr		      ob_newNetConn();				//[jsh] 11/07/2003
int				      ob_nextRow(OpenBasePtr conn); // the old routine
char* 			      ob_password(OpenBasePtr conn);
void			      ob_releaseBuffers(OpenBasePtr conn);	//[jsh] 11/07/2003
int				      ob_removeMarkOnRow(OpenBasePtr conn, const char* anId, const char* tableName);
int				      ob_resultColumnCount(OpenBasePtr conn);
char* 			      ob_resultColumnName(OpenBasePtr conn, int col);
int				      ob_resultColumnType(OpenBasePtr conn, int col);
int				      ob_resultReturned(OpenBasePtr conn);
char* 			      ob_resultTableName(OpenBasePtr conn, int col);
const char* 	      ob_retrieveBinary(OpenBasePtr conn, const char* blobIdentifier, int* returnSize);
int				      ob_rollbackTransaction(OpenBasePtr conn);
int				      ob_rowsAffected(OpenBasePtr conn);
const char* 	      ob_serverMessage(OpenBasePtr conn);
const char* 	      ob_uniqueRowIdForTable(OpenBasePtr conn, const char* tblname);
const char* 	      ob_uniqueRowIdForTableColumn(OpenBasePtr conn, const char* tblname, const char* colname);
int				      _ob_widthForColumn(OpenBasePtr conn, int col);
void			      _ob_estimateColumnWidths(OpenBasePtr conn);
OpenBaseResultDataPtr ob_newResultData();			// ��� LD September 4, 2001 

int			          ob_isCursorColumnNULL(OpenBaseCursorPtr cursor, int col);
OpenBaseCursorPtr	  ob_retrieveCursor(OpenBasePtr conn); // return a result cursor
OpenBaseCursorPtr     ob_newResult();					// ��� LD September 4, 2001 
int 			      ob_nextCursorRow(OpenBaseCursorPtr cursor); // replacement for ob_nextRow
char* 			      ob_cursorColumnName(OpenBaseCursorPtr cursor, int col);
void 			      ob_deallocCursor(OpenBaseCursorPtr cursor);


// -------------------------------------------------------------------------------
char*                 _getEncoding (OpenBase* conn, char* encoding);		

#ifdef __cplusplus
}
#endif

#endif	// __OPENBASECONNECTION_H__
