/* OpenBaseConnection.h created by root on Wed 14-Jan-1998 */

#include <stdio.h>
#include <stdlib.h>

//#define RHAPSODY

#ifndef __OB_Connection
	#define __OB_Connection

//#define CARBON_API

#define READ_BLOCKS 

#define OBTYPE_CHAR		1
#define OBTYPE_INT		2
#define OBTYPE_FLOAT	3
#define OBTYPE_LONG		4
#define OBTYPE_MONEY	5
#define OBTYPE_DATE		6
#define OBTYPE_TIME		7
#define OBTYPE_OBJECT	8
#define OBTYPE_DATETIME	9
#define OBTYPE_LONGLONG	10
#define OBTYPE_BOOLEAN	       11
#define OBTYPE_BINARY	       12
#define OBTYPE_OBJECT_TEXT     13
#define OBTYPE_TIMESTAMP       14


#define ERR_SFTUSRLIM	1
#define ERR_DBSUSRLIM	2
#define ERR_DBSLIM		3
#define ERR_DBSDUP		4
#define ERR_NOSERVER	5
#define ERR_INCORRECT_LOGIN	6
#define ERR_SERVER_RESTARTING	7
#define ERR_WEBOBJECTS_VIOLATION 8
#define ERR_LITE_VIOLATION      9

typedef struct NetConnStruct {
    unsigned char *resultKeys[30];
    unsigned char *resultValues[30];
    int keyBufferSize[30];
    int valueBufferSize[30];
    int resultLength[30];
    int numberOfKeys;
    int didInit;
    int socketConnection;
    int connectionPort;
    unsigned char *dictionaryBuffer;
    int dictionaryBufferSize;
    int dictionaryLength;
    
    // for buffered reading
    int readPosition;

    // for encryption
    int privateConnection;
    unsigned char *privateEncriptionMap;
    unsigned char *privateDecriptionMap;
} NetConn;


typedef struct OpenBaseResultDataStruct {
    struct OpenBaseResultDataStruct *next;
    // result data
    char *resultData;
    int resultDataLength;
    int resultDataNeedsDealloc;
} OpenBaseResultData;

typedef struct OpenBaseCursorStruct {
    struct OpenBaseCursorStruct *pushedResult;
    
    // result data
    //char *resultData;
    //int resultDataLength;
    OpenBaseResultData *resultPage;
    
    // resultInformation
    int maxInitializedTables;
    int maxInitializedColumns;
    char *tableNames[400];
    char *columnNames[400];
    char targetTypes[400];
    unsigned char resultIsNull[400];
    int columnsReturned;
    int rowsAffected;
    
    char *bindVariables[400];
    char bindTargetTypes[400];
    int maxVariablesBound;
    
    // estimated column widths
    int	columnWidths[400];
    
    // state information
    int readMoreResult;
    int readPosition;
    const char *errorMessage;
    int skipConvert;

} OpenBaseCursor;

typedef struct OpenBaseStruct {
    NetConn *connection;
    NetConn *altConnection;
    OpenBaseCursor *resultset;
    
    // login information
    char databaseName[100];
    char databaseHost[100];
    char databaseLogin[100];
    char databasePassword[100];

    char tmp[100];
    // SQLBuffer
    char *sqlBuffer;
    int sqlBufferSize;
    int position;


    // prepared SQL
    char *preparedSQL[400];
    int numberOfPreparedValues;
    int prepareValuePosition;
    
} OpenBase;


OpenBaseCursor *ob_retrieveCursor(OpenBase *conn);
int ob_nextCursorRow(OpenBaseCursor *cursor);


OpenBase *ob_newConnection();
void ob_invalidate(OpenBase *conn);
int ob_beginTransaction(OpenBase *conn);

void ob_bindDouble(OpenBase *conn, double *var);
void ob_bindInt(OpenBase *conn, int *var);
void ob_bindLongLong(OpenBase *conn, int *var);
void ob_bindLong(OpenBase *conn, long *var);
void ob_bindString(OpenBase *conn, char *var);
void ob_bindBinary(OpenBase *conn, char *var);
void ob_bindBoolean(OpenBase *conn, int *var);

int ob_bufferHasCommands(OpenBase *conn);
void ob_clearCommands(OpenBase *conn);
char *ob_commandBuffer(OpenBase *conn);
int ob_commitTransaction(OpenBase *conn);
const char *ob_connectErrorMessage(OpenBase *conn);
int ob_connectToDatabase(OpenBase *conn, const char *dbName, const char *dbHostName, const char *loginName, const char *passwordString, int *returnCode);
char *ob_databaseName(OpenBase *conn);
int ob_abortFetch(OpenBase *conn); // used to abort a fetch
int ob_executeCommand(OpenBase *conn);
char *ob_hostName(OpenBase *conn);
int ob_isColumnNULL(OpenBase *conn, int col);
const char *ob_loginName(OpenBase *conn);
void ob_makeCommand(OpenBase *conn, const char *cmd);
void ob_makeCommandLength(OpenBase *conn, const char *cmd, int length);
int ob_markRow(OpenBase *conn, const char *anId, const char *tableName);
int ob_markRowAlreadyMarkedByUser(OpenBase *conn, const char *anId, const char *tableName, char *userName);
int ob_nextRow(OpenBase *conn);
char *ob_password(OpenBase *conn);
int ob_removeMarkOnRow(OpenBase *conn, const char *anId, const char *tableName);
int ob_resultColumnCount(OpenBase *conn);
char *ob_resultColumnName(OpenBase *conn, int col);
int ob_resultColumnType(OpenBase *conn, int col);
int ob_resultReturned(OpenBase *conn);
char *ob_resultTableName(OpenBase *conn, int col);
int ob_rollbackTransaction(OpenBase *conn);
int ob_rowsAffected(OpenBase *conn);
const char *ob_serverMessage(OpenBase *conn);
const char *ob_uniqueRowIdForTable(OpenBase *conn, const char *tblname);
const char *ob_uniqueRowIdForTableColumn(OpenBase *conn, const char *tblname, const char *colname);

const char *ob_insertBinary(OpenBase *conn, const char *data, int size);
const char *ob_retrieveBinary(OpenBase *conn, const char *blobIdentifier, int *returnSize);

void ob_deallocConnection(OpenBase * conn); // invalidate and free the connection
void ob_deallocCursor(OpenBaseCursor * cursor);


/* OpenBasePrepare.h created by root on Mon 19-Jan-1998 */

int ob_prepareStatement(OpenBase *conn, const char *sqlstring);
int ob_prepareSelectStatement(OpenBase *conn, const char *sqlstring);
void ob_preparedValue(OpenBase *conn, const char *sqlValue);
int ob_prepareValuePosition(OpenBase *conn);
int ob_prepareParamsRequired(OpenBase *conn);
int ob_preparedExecute(OpenBase *conn);

int _ob_widthForColumn(OpenBase *conn, int col);
void _ob_estimateColumnWidths(OpenBase *conn);

// Methods used for converting types
void strip(char * in, char *out);
int moneyToInt(char *money);
long moneyToLong(char *money);
double moneyToDouble(char *money);

#endif
