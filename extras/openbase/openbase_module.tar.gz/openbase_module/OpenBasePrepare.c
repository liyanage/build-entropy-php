/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include "OpenBaseConnection.h"
#include "OpenBasePrepare.h"
#include "OpenBaseSupport.h"

int ob_prepareStatement(OpenBase *conn, const char *sqlstring)
{
    int paramCount = 0;
    int position = 0;
    char *tostring;
    int tosize;
    int isDone = 0;
    int ct;

    for (ct = 0; conn->preparedSQL[ct] != NULL; ct++) {
        free(conn->preparedSQL[ct]);  conn->preparedSQL[ct] = NULL;
    }

    while (1) {
        tostring = (char *)malloc(100);
        tosize = 100;

        position = position + copyToIndex(&tostring, &tosize, position, sqlstring, '?', &isDone) + 1;
        conn->preparedSQL[paramCount] = tostring;
        if (isDone) break;
        paramCount = paramCount + 1;
    }

    conn->preparedSQL[paramCount+1] = NULL;

    conn->numberOfPreparedValues = paramCount;
    conn->prepareValuePosition= 0;

    return paramCount;
}



int ob_prepareSelectStatement(OpenBase *conn, const char *sqlstring)
{
    int paramCount = 0;
    int position = 0;
    char *tostring;
    int tosize;
    int isDone = 0;
    int ct;
    
    ob_makeCommand(conn,"DESCRIBE RESULTS ");
    ob_makeCommand(conn,sqlstring);
    if(!ob_executeCommand(conn)) {
        return -1;
    }

    for (ct = 0; conn->preparedSQL[ct] != NULL; ct++) {
        free(conn->preparedSQL[ct]);  conn->preparedSQL[ct] = NULL;
    }

    while (1) {
        tostring = (char *)malloc(100);
        tosize = 100;

        position = position + copyToIndex(&tostring, &tosize, position, sqlstring, '?', &isDone) + 1;
        conn->preparedSQL[paramCount] = tostring;
        if (isDone) break;
        paramCount = paramCount + 1;
    }

    conn->preparedSQL[paramCount+1] = NULL;
    
    conn->numberOfPreparedValues = paramCount;
    conn->prepareValuePosition= 0;
        
    return paramCount;
}

void ob_preparedValue(OpenBase *conn, const char *sqlValue)
{
    //printf("ob_preparedValue = <%s> <%s>\n", conn->preparedSQL[conn->prepareValuePosition], sqlValue);
    
    ob_makeCommand(conn, conn->preparedSQL[conn->prepareValuePosition]);
    ob_makeCommand(conn, sqlValue);
    conn->prepareValuePosition = conn->prepareValuePosition + 1;
}

int ob_prepareValuePosition(OpenBase *conn)
{
    return conn->prepareValuePosition;
}

int ob_prepareParamsRequired(OpenBase *conn)
{
    return conn->numberOfPreparedValues;
}

int ob_preparedExecute(OpenBase *conn)
{
    if (conn->prepareValuePosition != conn->numberOfPreparedValues) {
        return -1;
    }
    //printf("ob_preparedExecute = <%s> \n", conn->preparedSQL[conn->prepareValuePosition]);
    ob_makeCommand(conn, conn->preparedSQL[conn->prepareValuePosition]);
    if(!ob_executeCommand(conn)) {
        return -1;
    }
    //conn->prepareValuePosition = 0;
    return ob_rowsAffected(conn);
}


