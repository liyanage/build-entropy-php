#include "platform.h"

#ifdef __cplusplus
	using namespace std;
	extern "C" {
#endif

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OMNI_ERRNO() errno

#ifdef i386
#warning Compiling for INTEL....
#define SWAPENDIAN 1
#endif

#if WINNT || LINUX || MACOSX_UNIX

	#include <sys/types.h>
	#include <fcntl.h>
	#include <sys/stat.h>

	#ifdef WINNT
		#import <System/winsock.h>
		#include <io.h>
		//#define RECEIVE_TIMOUTS_ACTIVATED 
	#endif

#endif

#if LINUX || MACOSX_UNIX || RHAPSODY || SOLARIS

	#import <libc.h>
	#import <netdb.h>
	#import <netinet/in_systm.h>
	#import <netinet/in.h>
	#import <netinet/ip.h>
	#import <netinet/ip_icmp.h>
	#import <netinet/tcp.h>
	#include <sys/socket.h>
	#import <errno.h>

	#ifdef RHAPSODY
		#include <unistd.h>
	#endif

	#ifdef MACOSX_UNIX
		#define SEND_TIMOUTS_ACTIVATED
		#define RECEIVE_TIMOUTS_ACTIVATED 
	#endif

	#ifdef LINUX
		#define RECEIVE_TIMOUTS_ACTIVATED 
		#define USE_UNIX_DOMAIN
	#endif
	
	#ifdef SOLARIS
		#define RECEIVE_TIMOUTS_ACTIVATED
		#define USE_UNIX_DOMAIN
	#endif

#endif

#ifdef MACOSX_CARBON 
	#include <OpenTransport.h>
	#include <OpenTptInternet.h>
	#include <size_t.h>
	#include <cctype>
	#include <cstdlib>

	static bool OTinited = false ;
	static OTClientContextPtr gOTClientContextPtr;

#endif

#include "NetClient.h"

#ifndef YES
	#define YES	1
#endif
#ifndef NO
	#define NO	0
#endif

#ifdef DEBUG
	#define DEBUG_CONNECT_ADDRESS 1
	//#define DEBUG_CONNECT
	//#define COMM_PRINT
	#warning *************** DEBUG MODE ***************
#endif

#define KEEPALIVE_CLIENT
#define SEND_TIMEOUT_VALUE	10
#define RECEIVE_TIMEOUT_VALUE	10



// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
int _windowsStartup() ;
void initOT() ;
	
// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
void initOT()
{
#ifdef MACOSX_CARBON 
	InitOpenTransportInContext(kInitOTForExtensionMask, &gOTClientContextPtr);

	OTinited = true ;
#endif
}	

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
int _windowsStartup()
{

#ifdef WINNT
	WSADATA WSAData;
	static int windowsDidStart = 0;
	int status;

	if (!windowsDidStart) {
		status = WSAStartup(MAKEWORD(1,1), &WSAData);
		if (status != 0)
			return NO;
		if (HIBYTE(WSAData.wVersion) != 1 || LOBYTE(WSAData.wVersion) != 1) {
			return NO;
		}
		windowsDidStart = YES;
	}
#endif

	return YES;
}


// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	int netConnect(int port, const char *hostName)
	{
		int ret = NO;
		unsigned int keepa = 1;
		int newsock;

		#ifdef USE_UNIX_DOMAIN
			struct sockaddr sockAddr;
		#else
			struct sockaddr_in sockAddr;
		#endif

		_windowsStartup(); // note this does nothing on non-windows platforms !

		#if DEBUG_CONNECT_ADDRESS
			printf("CONNECT TO NAME <%s>\n", hostName);
		#endif

		memset((struct sockaddr*) &sockAddr, 0, sizeof(sockAddr));
		sockAddr.sin_family = AF_INET;
		sockAddr.sin_port = htons(port);
			sockAddr.sin_addr.s_addr = inet_addr(hostName);
			if (sockAddr.sin_addr.s_addr == INADDR_NONE) {
				struct hostent *hostEntP;

				#if WINNT || SOLARIS
					hostEntP = gethostbyname(hostName);
				#else
					hostEntP = gethostbyname2(hostName, AF_INET);
				#endif
				
				if (!hostEntP) 
				{
					return -1;
				}
				memcpy(&sockAddr.sin_addr, hostEntP->h_addr, hostEntP->h_length);
			}

			newsock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP); //PF_INET
			#ifdef CLOSE_FD_ON_EXEC
				fcntl(newsock, F_SETFD, 1); //test
			#endif    

			if (newsock == -1) 
			{
				return -1;
			}

			ret = connect(newsock, (struct sockaddr*) &sockAddr, sizeof(sockAddr));
			if (ret == -1) 
			{
				OBSocketClose(newsock);
				return -1;
			}

			#ifdef KEEPALIVE_CLIENT
				setsockopt(newsock, SOL_SOCKET, SO_KEEPALIVE, (char *)&keepa, sizeof(keepa));
			#endif
			
		return newsock;

	}
#endif

	// ====================================================================================================================

#if MACOSX_CARBON 

	#ifdef TARGET_API_MAC_CARBON
		EndpointRef netConnect(int inServerPort, const char * inServerName, OTClientContextPtr outClientContext)
	#else
		EndpointRef netConnect(int inServerPort, const char * inServerName, OTClientContextPtr)
	#endif
	{
		EndpointRef theEndpoint;
		OSStatus err;
		TCall    sndCall;
		DNSAddress hostDNSAddress;
		char hostAddress[255];


		if (!OTinited) initOT() ;
		
		#ifdef TARGET_API_MAC_CARBON
			theEndpoint = ::OTOpenEndpointInContext(::OTCreateConfiguration(kTCPName), 0, nil, &err, outClientContext);
		#else
			theEndpoint = ::OTOpenEndpoint(::OTCreateConfiguration(kTCPName), 0, nil, &err);
		#endif

		if(err == noErr)
		{
			::OTSetSynchronous(theEndpoint);
			::OTSetBlocking(theEndpoint);
			::OTUseSyncIdleEvents(theEndpoint, true);
			err = ::OTBind(theEndpoint, nil, nil);
		}
			
		if(err == noErr)
		{
			::OTMemzero(&sndCall, sizeof(TCall));
			sprintf(hostAddress, "%s:%d", inServerName, inServerPort);
			sndCall.addr.buf = (UInt8 *)&hostDNSAddress;
			sndCall.addr.len = ::OTInitDNSAddress(&hostDNSAddress, hostAddress);
		
			err = ::OTConnect(theEndpoint, &sndCall, nil);
		}
		
		if(err != noErr)
		{
			netClose(theEndpoint);
			theEndpoint = kOTInvalidEndpointRef;
		}
		
		return(theEndpoint);
	}
#endif


// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
int copyAndFixString(unsigned char **tostring, int *tosize, int position, const unsigned char *str, int length, unsigned char *codedmap)
{
	char *strdest;
	
	// make sure the string is long enough
	if ((length + position) > (*tosize - 10)) 
	{
		*tosize = *tosize * 2;
		// if doubling size isn't enough
		if ((length + position) > (*tosize - 10)) 
		{
			*tosize = (length + position + 10);
		}
		//*tostring = (unsigned char *)NSZoneRealloc(NSDefaultMallocZone(), *tostring, *tosize);
		*tostring = (unsigned char *)realloc(*tostring, *tosize);
	}
	
	strdest = (char *)(*tostring + position);

	// copy the size of the string to the buffer
	ob_intToBytes((unsigned char *)strdest, length);
	strdest = strdest + sizeof(int);

	// copy the string itself to the buffer
	if (!codedmap) 
	{
		memcpy(strdest, str, length);
	} 
	else 
	{ // encode during copy
		int ct;

		for (ct=0; ct != length; ct++) 
		{
			strdest[ct] = codedmap[(unsigned int)str[ct]];
		}
	}

	strdest[length] = '\0';
	//printf("SEND TOKEN(%d) = %s\n", length, strdest);
	return (length + sizeof(int));
}


// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
void printBuffer(char *string, int len)
{
	int ct;

	for (ct=0; ct < len ;ct++) 
	{
		switch(string[ct]) 
		{
			case '\n':
				printf("\\n\n");
				break;
			case '\r':
				printf("\\r\n");
				break;
			case '\0':
				printf("\\0");
				break;
			default:
				printf("%c",string[ct]);
		}
	}
}

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	void netClose(unsigned int socket)
	{
		OBSocketClose(socket); //close(socket);
	}

#endif

	// ====================================================================================================================

#if MACOSX_CARBON 

	void netClose(EndpointRef inEndpoint)
	{
		if (!OTinited) initOT() ;
	
		if(inEndpoint != kOTInvalidEndpointRef)
		{
			OTUnbind(inEndpoint);
			OTCloseProvider(inEndpoint);
		}
	}
#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	int netSndRaw(unsigned char *rawdata, size_t len, int socket)
	{
		int ret=0;

		if (socket == -1) 
			return 0;
		if (len==0) 
			return 1;
		
		errno = 0;
		
		#ifdef COMM_PRINT
			printf("SOCKET %d SEND ==================\n",socket);
			printBuffer((char *)rawdata,len);
		#endif
		
		// send the data
		ret = OBSocketWrite(socket, rawdata, len);
		//ret = write(socket, rawdata, len);
		if (errno == ETIMEDOUT) 
		{
			//printf("switch(errno) -- socket failed, ret = %d, len = %d, errno = %d\n", (int)ret, (int)len, (int)errno);
			printBuffer((char *)rawdata,len);
			return 0;
		}

	/*	switch(errno) {
			case ENETDOWN:
			case ENETUNREACH:
			case ENETRESET:
			case ECONNABORTED:
			case ECONNRESET:
			case ENOTCONN:
			case ESHUTDOWN:
			case ETIMEDOUT:
			case ECONNREFUSED:
				printf("switch(errno) -- socket failed, ret = %d, len = %d, errno = %d\n", (int)ret, (int)len, (int)errno);
				printBuffer((char *)rawdata,len);
				return 0;
		}*/

		//if (errno!=0) {
		//	printf("(errno!=0) -- socket failed, ret = %d, len = %d, errno = %d\n", (int)ret, (int)len, (int)errno);
		//}

		if ((ret == -1) || (ret != len)) 
		{
			//printf("socket failed, ret = %d, len = %d, errno = %d\n", (int)ret, (int)len, (int)errno);
			return 0;
		}

		return 1;
	}
#endif

	// ====================================================================================================================

#if MACOSX_CARBON 

	int netSndRaw (UInt8 * inRawdata, size_t inLength, EndpointRef inEndpoint)
	{
		int theResult;

		if (!OTinited) initOT() ;
		
		if(inLength == OTSnd(inEndpoint, inRawdata, inLength, 0))
		{
			theResult = 1;
		}
		else
		{
			theResult = 0;
		}
		return theResult;
	}
#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	long netRcvToken(unsigned char **buffer, int *bufsize, int socket, unsigned char *decodemap, int *flag)

	/* Waits for data on the NetConnection's socket. */
	/* Returns an ISAM error code, and if no error the marshall buffer is */
	/* full with the received data */
	{
		int cc;
		int tokenLength = 0;

		if (OBSocketRead(socket, *buffer, sizeof(int), flag) != sizeof(int)) 
		{
			//printf("OBSocketRead FAILED (1)\n");
			return -1L;
		}
		ob_bytesToInt(&tokenLength, *buffer);
		
		if (tokenLength > 150000000) 
		{ // greater than 150 megabytes
			return -1L;
		}

		//memcpy(&tokenLength, *buffer, sizeof(int));
		if (tokenLength == -1) 
		{
			return -2L; // end of token stream
		}
			
		// reallocate buffer if it needs expanding
		if (tokenLength > (*bufsize-10)) 
		{
			*bufsize = *bufsize * 2;
			if (tokenLength > (*bufsize-10)) 
			{
				*bufsize = tokenLength + 10;
			}
			// *buffer = (unsigned char *)NSZoneRealloc(NSDefaultMallocZone(), *buffer, *bufsize);
			*buffer = (unsigned char *)realloc(*buffer, *bufsize);
		}

		// read token block
		if ((cc = OBSocketRead(socket, *buffer, tokenLength, flag)) != tokenLength) 
		{
		   // printf("OBSocketRead FAILED (2) %d but supposed to be %d\n", cc, tokenLength);
			return -1L;
		}
		*(char *)(*buffer + cc) = '\0';

		// decode result
		if (decodemap) 
		{
			for (cc = 0; cc != tokenLength; cc++) 
			{
				*(unsigned char *)(*buffer+cc) = decodemap[*(unsigned char *)(*buffer+cc)];
			}
		}

		//printf("RECEIVE TOKEN = <%s>\n", *buffer);
		return tokenLength;
	}
#endif

	// ====================================================================================================================

#if MACOSX_CARBON 

	long netRcvToken (UInt8 **buffer, int *bufsize, EndpointRef inEndpoint, UInt8 *decodemap, int *flag)
	{
		//	Waits for data on the NetConnection's socket.
		//	Returns an ISAM error code, and if no error the marshall buffer is
		//	full with the received data

		UInt32 tokenLength = 0;
		UInt32 cc;

		if (!OTinited) initOT() ;

		if (sizeof (UInt32) != OBSocketRead (inEndpoint, (void *) &tokenLength, sizeof (UInt32), flag))
		{
			return -1L;
		}

		if (tokenLength == -1)
		{
			return -2L; // end of token stream
		}
		else 
		{
			if (tokenLength < 0)
			{
				return -1L;		// error
			}
		}
			

		// reallocate TOKEN buffer if it needs expanding
		if (tokenLength > (*bufsize-10))
		{
			*bufsize = *bufsize * 2;

			if (tokenLength > (*bufsize-10))
			{
				*bufsize = tokenLength + 10;
			}

			// WAS: *buffer = (UInt8 *) std::realloc (*buffer, *bufsize);
			//	free(*buffer);
			ob_free(*buffer);
			//	*buffer = (UInt8*)malloc(*bufsize);
			*buffer = (UInt8*)ob_malloc(*bufsize);
		}

		// read token block
		if (tokenLength != (cc = OBSocketRead (inEndpoint, *buffer, tokenLength, flag)))
		{
			return -1L;
		}

		*(char *)(*buffer + cc) = '\0';		// EOS


		if (NULL != decodemap)	// decode result ? 
		{
			for (cc = 0; cc != tokenLength; cc++)
			{
				*(UInt8*)(*buffer+cc) = decodemap[*(UInt8*)(*buffer+cc)];
			}
		}

		return(tokenLength);
	}

#endif


// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	/* Creates a server socket on the given port which will be used to wait */
	/* for incoming client connections. */
	/* Returns the socket handle, or INVALID_SOCKET in case of failure. */
	int netSvrCreate(int port)
	{
		int sock;
		int shouldReuse = 1;
		struct sockaddr_in sockAddr;

		_windowsStartup();

		/* make sure no session is open and global mainSock is set to INVALID */
		//netSvrDestroy();

		memset(&sockAddr, 0, sizeof(sockAddr));
		sockAddr.sin_family = AF_INET;
		sockAddr.sin_addr.s_addr = htonl(INADDR_ANY);
		sockAddr.sin_port = htons(port);

		sock = socket(PF_INET, SOCK_STREAM, IPPROTO_IP); // PF_INET

		#ifdef CLOSE_FD_ON_EXEC
			fcntl(sock, F_SETFD, 1); //test
		#endif

		if (sock == -1)
			return -1;


		setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char *)&shouldReuse, sizeof(shouldReuse));

		if (bind(sock, (struct sockaddr *) &sockAddr, sizeof(sockAddr)) == (-1))
			return -1;

		if (listen(sock, 5) == (-1))
			return -1;

		return sock;
	}
#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY
	int netListen(int parentSock)
	
	/* Waits to accept incoming socket connections on the given server socket. */
	/* Returns a new child server-side socket which is attached to the */
	/* incoming client connection. */
	
	{
		struct sockaddr_in clientSockAddr;
		unsigned int sockLen;
		int newSock;

		#ifdef RECEIVE_TIMOUTS_ACTIVATED        
			struct timeval tm;
		#endif
		
		sockLen = sizeof(struct sockaddr_in);

		do 
		{
			newSock = accept(parentSock, (struct sockaddr *) &clientSockAddr, &sockLen);
		#ifdef WINNT
			} while (newSock == -1);
		#else
			} while (newSock == -1 && OMNI_ERRNO() == EINTR);
		#endif

		if (newSock < 0) 
			return -1;
			
		#ifdef RECEIVE_TIMOUTS_ACTIVATED        
			tm.tv_sec = RECEIVE_TIMEOUT_VALUE;
			tm.tv_usec = RECEIVE_TIMEOUT_VALUE;
			setsockopt(newSock, SOL_SOCKET, SO_RCVTIMEO, (char *)&tm, sizeof(tm));
		#endif

		#ifdef CLOSE_FD_ON_EXEC
			fcntl(newSock, F_SETFD, 1); //test
		#endif


		#ifdef DEBUG_CONNECT
			printf("NEW SOCKET = %d\n", newSock);
		#endif

		return newSock;
	}
#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY
	int setupClientHandle(int inSocket)
	{
		int socket;
		unsigned int keepa;
		int param ;
		
		#ifdef WINNT
			struct linger slinger;
			unsigned int nodelay;        
			
			nodelay = TRUE;
			setsockopt(socket, IPPROTO_TCP, TCP_NODELAY, (char *)&nodelay, sizeof(nodelay));
							   
			// TURN ON LINGER                   
			slinger.l_onoff = 0;
			slinger.l_linger = 0;   
			setsockopt(socket, SOL_SOCKET, SO_LINGER, (char *)&slinger, sizeof(slinger));
			
			// TURN ON KEEP ALIVE
			keepa = TRUE;
			setsockopt(socket, SOL_SOCKET, SO_KEEPALIVE, (char *)&keepa, sizeof(keepa));
		#else
			#ifdef SEND_TIMOUTS_ACTIVATED        
				unsigned int len;
				struct timeval sendTimeout;
			#endif
			
			socket = inSocket;
	 
			// SEND TIMEOUT
			getsockopt(socket, SOL_SOCKET, SO_SNDTIMEO, (char *)&sendTimeout, &len);
			sendTimeout.tv_sec = SEND_TIMEOUT_VALUE;
			sendTimeout.tv_usec = SEND_TIMEOUT_VALUE;
			setsockopt(socket, SOL_SOCKET, SO_SNDTIMEO, (char *)&sendTimeout, sizeof(sendTimeout));
		#endif
			
			// TURN ON NOSIGPIPE
		#ifdef MACOSX_UNIX
			#ifndef SO_NOSIGPIPE
				#define SO_NOSIGPIPE   0x1022          /* APPLE: No SIGPIPE on EPIPE */
			#endif

			param = 1;
			setsockopt(socket, SOL_SOCKET, SO_NOSIGPIPE, (char *)&param, sizeof(param));
		#endif
		
		// TURN ON KEEP ALIVE
		keepa = TRUE;
		setsockopt(socket, SOL_SOCKET, SO_KEEPALIVE, (char *)&keepa, sizeof(keepa));
								
	return 1;
	}
#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	int ob_threadNeedsDisconnect()
	{
		// put code here to check a flag to abort a connection.
		return 0;
	}

#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	int ob_socketread(int socketFD, unsigned char *buffer, size_t byteCount, int *flag)
	{
		int ct = 0, ret = 0;
		int err_hold = 0;
		while (ct < byteCount) 
		{
			ret = recv(socketFD, &buffer[ct], (byteCount - ct), MSG_WAITALL);
			err_hold = errno;
			if (ret == 0) 
				break;

			if ((err_hold == EAGAIN) || (err_hold == EDEADLK)) 
			{
				//printf("socket: EAGAIN (%d) ret =%d\n", socketFD, ret);
				if (ret < 0) 
				{
					ret = 0;
					//if (ob_threadNeedsDisconnect()) return 0;
				}
			}
			#ifdef WINNT			
				if (((err_hold == EINTR) || (err_hold == EFAULT) || (err_hold == EPIPE) || (err_hold == EBADF)) || ((ret == -1) && (err_hold == 0))) 
			#endif
			#if MACOSX_UNIX || LINUX || SOLARIS || RHAPSODY
				if (/*(errno == EINTR) ||*/ (errno == EFAULT) || (errno == ENOTSOCK) || (errno == EPIPE) || (errno == EBADF)) 
			#endif
			{
				//printf("(errno == EINTR) -- TERMINATE CONNECTION!!, errno = %d, ret = %d, (ct:%d != byteCount:%d)\n", err_hold, ret, ct, byteCount);
				return 0; 
			}
			if (*flag) 
			{
				//printf("!flag -- TERMINATE CONNECTION!!, errno = %d, ret = %d, (ct:%d != byteCount:%d)\n", err_hold, ret, ct, byteCount);
				return 0;
			}
			if (ret < 0) 
			{
				//printf("SOCKET RETURNED %d, setting to 0, errno=%d\n", ret, err_hold);
				//NSLog([NSString stringWithFormat:@"SOCKET RETURNED %d, setting to 0, errno=%d\n", ret, errno]);
				ret = 0;
			}

			ct = ct + ret;
		}
		//if (ct != byteCount) 
		//{
		//	printf("(ct != byteCount) -- TERMINATE CONNECTION!!, errno = %d, ret = %d, (ct:%d != byteCount:%d)\n", err_hold, ret, ct, byteCount);
		//}

		return ct;
	}
#endif

// ====================================================================================================================
#if MACOSX_CARBON
	int ob_socketread (EndpointRef inEndpoint, void* ioBuffer, size_t recvSize, int *flag)
	{
		#pragma unused (flag)

		OTFlags 	theJunkFlags			= NULL;	// there were not initialized
		int 		theReceivedByteCount 	= NULL;	//[jsh] 11/09/2003 signed type
		void*		thePacket				= (Ptr) ioBuffer;
		UInt32		xferSize				= 0L;
		UInt32		theSize					= recvSize;

		if (!OTinited) initOT() ;

		// WAS: theReceivedByteCount = ::OTRcv(inEndpoint, ioBuffer, inByteCount, &theJunkFlags);
		
		while(recvSize > 0)											// read all expected bytes
		{
			// YieldToAnyThread();									// not needed if called elsewhere
			thePacket = (void*)((UInt32)ioBuffer + xferSize);		// advance ptr into incoming buffer
			theReceivedByteCount = ::OTRcv(inEndpoint, thePacket, theSize, &theJunkFlags);
				//[jsh] 11/09/2003 Negative return value indicates error code.
			if (theReceivedByteCount < 0) return(theReceivedByteCount);
			recvSize  -= theReceivedByteCount;						// reduce amount to read
			xferSize  += theReceivedByteCount;						// advance ptr into incoming buffer
			theSize	   = recvSize;									// ready for next usage
		}			
					
		theReceivedByteCount = xferSize;
		
		return(theReceivedByteCount);
	}

#endif

// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
void ob_intToBytes(unsigned char *buffer, int number)
{
#ifdef SWAPENDIAN
	unsigned char *i;

	i = (unsigned char *)&number;
	buffer[0] = i[3];
	buffer[1] = i[2];
	buffer[2] = i[1];
	buffer[3] = i[0];
#else
	memcpy(buffer, &number, sizeof(int));
#endif
}


// ====================================================================================================================
// ====================================================================================================================
// ====================================================================================================================
void ob_bytesToInt(int *number, unsigned char *buffer)
{
#ifdef SWAPENDIAN
	unsigned char *i;
	i = (unsigned char *)number;
	i[0] = buffer[3];
	i[1] = buffer[2];
	i[2] = buffer[1];
	i[3] = buffer[0];
#else
	memcpy(number, buffer, sizeof(int));
#endif
}


#ifdef __cplusplus
	 }
#endif
