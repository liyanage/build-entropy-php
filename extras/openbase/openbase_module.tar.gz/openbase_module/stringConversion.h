// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------

void initSQLCodeString();

void encodeQUOTEDString(const unsigned char *string, unsigned char *buffer, int len);
void encodeSQLString(const unsigned char *string, unsigned char *buffer, int len);
void encodeSQLStringConvertSlashes(const unsigned char *string, unsigned char *buffer, int len);
void decodeSQLString(const unsigned char *string, unsigned char *buffer, int *len);