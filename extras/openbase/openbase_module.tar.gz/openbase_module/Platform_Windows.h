#define WINNT		1

#include "platform.h"