/*
	OB_Encoding.h
	OpenBase Unified Client
	�1996-2002 OpenBase International, Ltd.
	All rights reserved
	
	Theory of operation:
	
	A client side driver often needs to convert character data from the client's
	preferred encoding to the encoding of the database. The SQL 92 language is
	all ASCII, so the client can safely convert all data. Only string literals
	should be affected.
	
	To do the conversion, these routines will get the database encoding from
	a connection, then use a global map to do the conversion.
	
	Future directions:
		� Complete Windows encodings
		� Have functions that register encodings you need so that the linker
			can toss unused but space consuming encodings
		� Ability to load your own map into the map table (from above) as well

	Disclaimer:
	-----------
	THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF 
	ANY KIND, EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT 
	LIMITATION THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF 
	THIS SOFTWARE. OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY 
	DEFECT IN, THIS SOFTWARE. IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, 
	SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE 
	POSSIBILITY OF SUCH DAMAGE.

	WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE 
	OPENBASE API SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#ifndef _OB_ENCODING_H
#define _OB_ENCODING_H

#ifdef __cplusplus
extern "C" {
#endif

//================================================================================
//	Includes
//================================================================================

	//#ifndef _OB_API_HEADER_H
	//#include "OB_API_Header.h"
	//#endif

	#ifndef _OB_CONNECTION_H
	//#include "OB_Connection.h"
	#endif

//================================================================================
//	Definitions
//================================================================================
/*
#define OB_ENCODING_UNKNOWN 	0
#define OB_ENCODING_ASCII	 	1
#define OB_ENCODING_UTF8 		2
#define OB_ENCODING_UNICODE 	3
#define OB_ENCODING_ISO8859_1 	101
#define OB_ENCODING_ISO8859_2 	102
#define OB_ENCODING_ISO2022JP 	201
#define OB_ENCODING_EUC 		202
#define OB_ENCODING_SHIFTJIS 	203

#define OB_ENCODING_MACOS_ROMAN 1000
#define OB_ENCODING_NEXT		4000
*/

#define OB_ENCODING_LATIN1	 	101
#define OB_ENCODING_LATIN2	 	102

enum
{
	OB_ENCODING_UNKNOWN						= 0,

	//	encodings supported by OpenBase
	OB_ENCODING_ASCII   					= 1,
	OB_ENCODING_UTF8						= 2,
	OB_ENCODING_UNICODE						= 3,

	//	ISO 8859 encodings
	OB_ENCODING_ISO8859_1					= 101,		//	Latin 1 (West European)
	OB_ENCODING_ISO8859_2					= 102,		//	Latin 2 (East European)
	OB_ENCODING_ISO8859_3					= 103,		//	Latin 3	(South European)
	OB_ENCODING_ISO8859_4					= 104,		//	Latin 4 (North European)
	OB_ENCODING_ISO8859_5					= 105,		//	Latin/Cyrillic
	OB_ENCODING_ISO8859_6					= 106,		//	Arabic
	OB_ENCODING_ISO8859_7					= 107,		//	Latin/Greek
	OB_ENCODING_ISO8859_8					= 108,		//	Latin/Hebrew
	OB_ENCODING_ISO8859_9					= 109,		//	Latin 5 (Turkish)
	OB_ENCODING_ISO8859_10					= 110,		//	Latin 6 (Nordic)
	OB_ENCODING_ISO8859_13					= 113,		//	Latin 7 (Baltic Rim)
	OB_ENCODING_ISO8859_14					= 114,		//	Latin 8 (Sami)
	OB_ENCODING_ISO8859_15					= 115,		//	Latin 9 (Much like Latin 1, with rare symbols replaced)
	OB_ENCODING_ISO8859_16					= 116,		//	Latin 10 (yet another Latin)

	//	Japanese Encodings (not implemented!!)
	OB_ENCODING_ISO2022JP					= 201,
	OB_ENCODING_EUC							= 202,
	OB_ENCODING_SHIFTJIS					= 203,
	
	//	Mac OS Encodings
	OB_ENCODING_MACOS_ROMAN					= 1000,		//	"normal" Mac OS encoding
	OB_ENCODING_MACOS_ARABIC				= 1001,
	OB_ENCODING_MACOS_CENTEURO				= 1002,
	OB_ENCODING_MACOS_CORPCHAR				= 1003,
	OB_ENCODING_MACOS_CROATIAN				= 1004,
	OB_ENCODING_MACOS_CYRILLIC				= 1005,
	OB_ENCODING_MACOS_DEVANAGA				= 1006,
	OB_ENCODING_MACOS_DINGBATS				= 1007,
	OB_ENCODING_MACOS_FARSI					= 1008,
	OB_ENCODING_MACOS_GREEK					= 1009,
	OB_ENCODING_MACOS_GUJARATI				= 1010,
	OB_ENCODING_MACOS_GURMUKHI				= 1011,
	OB_ENCODING_MACOS_HEBREW				= 1012,
	OB_ENCODING_MACOS_ICELAND				= 1013,
	OB_ENCODING_MACOS_ROMANIAN				= 1014,
	OB_ENCODING_MACOS_SYMBOL				= 1015,
	OB_ENCODING_MACOS_THAI					= 1016,
	OB_ENCODING_MACOS_TURKISH				= 1017,
	OB_ENCODING_MACOS_UKRAINE				= 1018,
	
	//	DOS Encodings
	OB_ENCODING_DOS_CP437_LATINUS			= 2000,		//	Latin US ("normal" DOS encoding)
	OB_ENCODING_DOS_CP737_GREEK				= 2001,		//	Greek
	OB_ENCODING_DOS_CP775_BALTRIM			= 2002,		//	Baltic Rim
	OB_ENCODING_DOS_CP850_LATIN1			= 2003,		//	Latin1
	OB_ENCODING_DOS_CP852_LATIN2			= 2004,		//	Latin2
	OB_ENCODING_DOS_CP855_CYRILLIC			= 2005,		//	Cyrillic
	OB_ENCODING_DOS_CP857_TURKISH			= 2006,		//	Turkish
	OB_ENCODING_DOS_CP860_PORTUGUESE		= 2007,		//	Portuguese
	OB_ENCODING_DOS_CP861_ICELANDIC			= 2008,		//	Icelandic
	OB_ENCODING_DOS_CP862_HEBREW			= 2009,		//	Hebrew
	OB_ENCODING_DOS_CP863_CANADAF			= 2010,		//	French Canadian
	OB_ENCODING_DOS_CP864_ARABIC			= 2011,		//	Arabic
	OB_ENCODING_DOS_CP865_NORDIC			= 2012,		//	Nordic
	OB_ENCODING_DOS_CP866_CYRILLICRUSSIAN	= 2013,		//	Cyrillic Russian
	OB_ENCODING_DOS_CP869_GREEK2			= 2014,		//	Greek 2
	OB_ENCODING_DOS_CP874_THAI				= 2015,		//	Thai
	
	//	Windows Encodings
	OB_ENCODING_WIN_CP874_THAI				= 3000,		//	Thai
	OB_ENCODING_WIN_CP1250_LATIN2			= 3001,		//	Latin2
	OB_ENCODING_WIN_CP1251_CYRILLIC			= 3002,		//	Cyrillic
	OB_ENCODING_WIN_CP1252_LATIN1			= 3003,		//	Latin1 ("normal" WIndows encoding)
	OB_ENCODING_WIN_CP1253_GREEK			= 3004,		//	Greek
	OB_ENCODING_WIN_CP1254_TURKISH			= 3005,		//	Turkish
	OB_ENCODING_WIN_CP1255_HEBREW			= 3006,		//	Hebrew
	OB_ENCODING_WIN_CP1256_ARABIC			= 3007,		//	Arabic
	OB_ENCODING_WIN_CP1257_BALTRIM			= 3008,		//	Baltic Rim
	OB_ENCODING_WIN_CP1258_VIETNAMESE		= 3009,		//	Vietnamese
	
	//	NeXT Encodings
	OB_ENCODING_NEXT						= 4000
	
};



//================================================================================
//	Structures
//================================================================================

struct OpenBaseUnicodeMapStruct
{
	unsigned short	unicodeCharacter;		//	the lookup character
	unsigned char	encodingCharacter;	//	the encoded character
};

typedef struct OpenBaseUnicodeMapStruct OpenBaseUnicodeMap;

struct OpenBaseCharacterMapStruct
{
	//	mapToUnicode is a simple array lookup to translate a character to 8 byte
	//	Unicode equivalent
	unsigned short		mapToUnicode[256];
	
	//	mapToEncoding is sorted by Unicode character for a binary search lookup
	OpenBaseUnicodeMap	mapToEncoding[256];
	
	//	default character when mapping from Unicode character that has no entry
	unsigned char		defaultCharacter;
};

typedef struct OpenBaseCharacterMapStruct OpenBaseCharacterMap;


//================================================================================
//	Functions
//================================================================================

//	returns the name of the encoding
const char*	ob_getEncodingName(int encoding);

//	if you need to do conversions of your own, this is exposed
//	this will make a copy if from_code == to_code 
//	caller owns result, must free()
//	size is in/out parameter -- in contains size of source, out has size of result

unsigned char* ob_convertCharacters(int from_code, int to_code, const unsigned char* source, int* size);

//	call this on SQL statements before sending to server
//	this will make a copy if client and server have same encoding
//	caller owns result, must free()
//	size is in/out parameter -- in contains size of source, out has size of result

/*
unsigned char* ob_convertSQLStatement(OB_Connection* connection, const unsigned char* source, int* size);

//	call this on character results restured from server
//	this will make a copy if client and server have same encoding
//	caller owns result, must free()
//	size is in/out parameter -- in contains size of source, out has size of result
unsigned char* ob_convertResult(OB_Connection* connection, const unsigned char* source, int* size);
*/


//================================================================================
//	Conversion Tables
//================================================================================

extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_1;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_2;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_3;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_4;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_5;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_6;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_7;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_8;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_9;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_10;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_13;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_14;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_15;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO8859_16;

extern OpenBaseCharacterMap	kOpenBaseCharacterMap_NeXT;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ASCII;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO2022JP;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_EUC;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_SHIFTJIS;

extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Roman;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Arabic;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_CentEuro;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_CorpChar;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Croatian;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Cyrillic;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Devanaga;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Dingbats;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Farsi;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Greek;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Gujarati;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Gurmukhi;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Hebrew;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Iceland;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Romanian;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Symbol;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Thai;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Turkish;
extern OpenBaseCharacterMap kOpenBaseCharacterMap_MacOS_Ukraine;

extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP437_LatinUS;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP737_Greek;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP775_BaltRim;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP850_Latin1;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP852_Latin2;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP855_Cyrillic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP857_Turkish;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP860_Portuguese;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP861_Icelandic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP862_Hebrew;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP863_CanadaF;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP864_Arabic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP865_Nordic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP866_CyrillicRussian;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP869_Greek2;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_DOS_CP874_Thai;

extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP874_Thai;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1250_Latin2;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1251_Cyrillic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1252_Latin1;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1253_Greek;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1254_Turkish;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1255_Hebrew;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1256_Arabic;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1257_BaltRim;
extern OpenBaseCharacterMap	kOpenBaseCharacterMap_Win_CP1258_Vietnamese;

#ifdef __cplusplus
}
#endif

#endif