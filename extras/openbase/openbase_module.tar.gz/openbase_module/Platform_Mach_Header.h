//#include "MSL CocoaHeaders.h"
#define MOSX_UNIX		1

#include "platform.h"