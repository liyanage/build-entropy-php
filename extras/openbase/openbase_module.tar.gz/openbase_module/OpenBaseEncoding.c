/*
	OB_Encoding.c
	OpenBase Unified Client
	�1996-2002 OpenBase International, Ltd.
	All rights reserved
	
	Theory of operation:
	
	A client side driver often needs to convert character data from the client's
	preferred encoding to the encoding of the database. The SQL 92 language is
	all ASCII, so the client can safely convert all data. Only string literals
	should be affected.
	
	To do the conversion, these routines will get the database encoding from
	a connection, then use a global map to do the conversion.
	
	Here is a note about how UTF8 works:
	
		http://lists.w3.org/Archives/Public/ietf-charsets/2002AprJun/att-0010/01-draft-yergeau-utf8-rev2-00.html
	
		The table below summarizes the format of these different octet types. 
		The letter x indicates bits available for encoding bits of the character
		number. 


		Char. number range  |        UTF-8 octet sequence
		   (hexadecimal)    |              (binary)
		--------------------+---------------------------------------------
		0000 0000-0000 007F | 0xxxxxxx
		0000 0080-0000 07FF | 110xxxxx 10xxxxxx
		0000 0800-0000 FFFF | 1110xxxx 10xxxxxx 10xxxxxx
		
		(these would not be legal in the Unicode Standard, but they happen)
		0001 0000-001F FFFF | 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
		0020 0000-03FF FFFF | 111110xx 10xxxxxx 10xxxxxx 10xxxxxx 10xxxxxx
		0400 0000-7FFF FFFF | 1111110x 10xxxxxx ... 10xxxxxx


	Disclaimer:
	-----------
	THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF 
	ANY KIND, EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT 
	LIMITATION THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF 
	THIS SOFTWARE. OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY 
	DEFECT IN, THIS SOFTWARE. IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, 
	SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE 
	POSSIBILITY OF SUCH DAMAGE.

	WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE 
	OPENBASE API SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/
#include "platform.h"

#ifdef __cplusplus
extern "C" {
#endif

//================================================================================
//	Includes
//================================================================================
#include "OpenBaseEncoding.h"

#include <string.h>
#include <stdlib.h>


//================================================================================
//	Functions
//================================================================================

int unicode_strlen(const unsigned short* string);
unsigned char map_from_unicode(unsigned short unicode_char, OpenBaseCharacterMap* map);
unsigned char* ob_encodeUTF8(const unsigned short* unicode, int* size);
unsigned short* ob_decodeUTF8(const unsigned char* utf8, int* size);
OpenBaseCharacterMap* ob_getCharacterMap(int map_code);


inline int unicode_strlen(const unsigned short* string)
{
	int result = 0;
	
	if (string != NULL)
	{
		while (*string != 0x0000)
		{
			string++;
			result++;
		}
	}

	return result;
}

unsigned char map_from_unicode(unsigned short unicode_char, OpenBaseCharacterMap* map)
{
	char result = 0;
	
	if (map != NULL)
	{
		int low = 0;
		int high = 255;
		
		result = map->defaultCharacter;
		
		//	binary search for index that maps to this character
		while (low <= high)
		{
			int mid = (low + high) / 2;
			if (map->mapToEncoding[mid].unicodeCharacter > unicode_char)
			{
				high = mid - 1;
			}
			else if (map->mapToEncoding[mid].unicodeCharacter < unicode_char)
			{
				low = mid + 1;
			}
			else
			{
				low = mid + 1;
				high = mid;
				result = map->mapToEncoding[mid].encodingCharacter;
			}
		}
	}
	
	return result;
}

unsigned char* ob_encodeUTF8(const unsigned short* unicode, int* size)
{
	unsigned char* result = NULL;
	int result_size = 0;
	
	//	strategy: (1) compute size, (2) do the conversion
	
	if ((unicode != NULL) && (size != NULL))
	{
		int i;
		
		//	compute size
		for (i = 0; i < *size; i++)
		{
			unsigned short curr_unicode = unicode[i];
			if ((curr_unicode >= 0x0000) && (curr_unicode <= 0x007F))
			{
				result_size += 1;
			}
			else if ((curr_unicode >= 0x0080) && (curr_unicode <= 0x07FF))
			{
				result_size += 2;
			}
			else if ((curr_unicode >= 0x0800) && (curr_unicode <= 0xFFFF))
			{
				result_size += 3;
			}
		}

		//	allocate space and do the conversion
		result = (unsigned char*) malloc(result_size);
		if (result != NULL)
		{
			unsigned char* result_ptr = result;
			
			for (i = 0; i < *size; i++)
			{
				unsigned short curr_unicode = unicode[i];
				if ((curr_unicode >= 0x0000) && (curr_unicode <= 0x007F))
				{
					result_ptr[0] = curr_unicode;
					result_ptr++;
				}
				else if ((curr_unicode >= 0x0080) && (curr_unicode <= 0x07FF))
				{
					result_ptr[0] = 0xC0 | ((curr_unicode >> 6) & 0x001F);
					result_ptr[1] = 0x80 | (curr_unicode & 0x003F);
					result_ptr += 2;
				}
				else if ((curr_unicode >= 0x0800) && (curr_unicode <= 0xFFFF))
				{
					result_ptr[0] = 0xE0 | ((curr_unicode >> 12) & 0x000F);
					result_ptr[1] = 0x80 | ((curr_unicode >> 6) & 0x003F);
					result_ptr[2] = 0x80 | (curr_unicode & 0x003F);
					result_size += 3;
				}
			}
			
			*size = result_size;
		}
	}
	
	return result;
}

unsigned short* ob_decodeUTF8(const unsigned char* utf8, int* size)
{
	unsigned short* result = NULL;
	int result_size = 0;
	
	//	strategy: (1) compute size, (2) do the conversion
	if ((utf8 != NULL) && (size != NULL))
	{
		int i;
		const unsigned char* utf8_ptr = utf8;
		
		//	compute size
		for (i = 0; i < *size;)
		{
			unsigned char curr_utf8 = ((unsigned char*) utf8)[i];
			
			if ((curr_utf8 & 0x80) == 0)
			{
				result_size += 1;
				i += 1;
			}
			else if ((curr_utf8 & 0xE0) == 0xC0)
			{
				result_size += 1;
				i += 2;
			}
			else if ((curr_utf8 & 0xF0) == 0xE0)
			{
				result_size += 1;
				i += 3;
			}
			else if ((curr_utf8 & 0xF8) == 0xF0)
			{
				result_size += 1;
				i += 4;
			}
			else if ((curr_utf8 & 0xFC) == 0xF8)
			{
				result_size += 1;
				i += 5;
			}
			else if ((curr_utf8 & 0xFE) == 0xFC)
			{
				result_size += 1;
				i += 6;
			}
			else
			{
				//	error condition! eat a character
				result_size += 0;
				i += 1;
			}
		}

		result = (unsigned short*) malloc(2 * result_size);
		if (result != NULL)
		{
			unsigned short* result_ptr = result;
			
			for (i = 0; i < *size;)
			{
				unsigned char curr_utf8 = ((unsigned char*) utf8)[i];
				
				if ((curr_utf8 & 0x80) == 0)
				{
					*result_ptr = curr_utf8;
					result_ptr++;
					i += 1;
				}
				else if ((curr_utf8 & 0xE0) == 0xC0)
				{
					unsigned short curr_utf8_0 = ((unsigned char*) utf8)[i];
					unsigned short curr_utf8_1 = ((unsigned char*) utf8)[i+1];
	
					*result_ptr = ((curr_utf8_0 & 0x001F) << 6) + 
									(curr_utf8_1 & 0x003F);
					result_ptr++;
					i += 2;
				}
				else if ((curr_utf8 & 0xF0) == 0xE0)
				{
					unsigned short curr_utf8_0 = ((unsigned char*) utf8)[i];
					unsigned short curr_utf8_1 = ((unsigned char*) utf8)[i+1];
					unsigned short curr_utf8_2 = ((unsigned char*) utf8)[i+2];

					*result_ptr = ((curr_utf8_0 & 0x001F) << 12) + 
									((curr_utf8_1 & 0x003F) << 6) +
									(curr_utf8_2 & 0x003F);
					result_ptr++;
					i += 3;
				}
				else if ((curr_utf8 & 0xF8) == 0xF0)
				{
					*result_ptr = '?';
					result_ptr++;
					i += 4;
				}
				else if ((curr_utf8 & 0xFC) == 0xF8)
				{
					*result_ptr = '?';
					result_ptr++;
					i += 5;
				}
				else if ((curr_utf8 & 0xFE) == 0xFC)
				{
					*result_ptr = '?';
					result_ptr++;
					i += 6;
				}
				else
				{
					//	error condition!
					i += 1;
				}
			}
			
			*size = result_size * 2;
		}
	}

	return result;
}


//void dodo ();
//extern int xyz;


OpenBaseCharacterMap* ob_getCharacterMap(int map_code)
{
	OpenBaseCharacterMap* result = NULL;
	
	switch (map_code)
	{
		case OB_ENCODING_ASCII:
			//	use latin1 and strip off characters > 127
			result = &kOpenBaseCharacterMap_ISO8859_1;
			//xyz ++;
			//dodo ();
			break;
		
		//	ISO 8859 encodings
		case OB_ENCODING_ISO8859_1:
			result = &kOpenBaseCharacterMap_ISO8859_1;
			break;
		case OB_ENCODING_ISO8859_2:
			result = &kOpenBaseCharacterMap_ISO8859_2;
			break;
		case OB_ENCODING_ISO8859_3:
			result = &kOpenBaseCharacterMap_ISO8859_3;
			break;
		case OB_ENCODING_ISO8859_4:
			result = &kOpenBaseCharacterMap_ISO8859_4;
			break;
		case OB_ENCODING_ISO8859_5:
			result = &kOpenBaseCharacterMap_ISO8859_5;
			break;
		case OB_ENCODING_ISO8859_6:
			result = &kOpenBaseCharacterMap_ISO8859_6;
			break;
		case OB_ENCODING_ISO8859_7:
			result = &kOpenBaseCharacterMap_ISO8859_7;
			break;
		case OB_ENCODING_ISO8859_8:
			result = &kOpenBaseCharacterMap_ISO8859_8;
			break;
		case OB_ENCODING_ISO8859_9:
			result = &kOpenBaseCharacterMap_ISO8859_9;
			break;
		case OB_ENCODING_ISO8859_10:
			result = &kOpenBaseCharacterMap_ISO8859_10;
			break;
		case OB_ENCODING_ISO8859_13:
			result = &kOpenBaseCharacterMap_ISO8859_13;
			break;
		case OB_ENCODING_ISO8859_14:
			result = &kOpenBaseCharacterMap_ISO8859_14;
			break;
		case OB_ENCODING_ISO8859_15:
			result = &kOpenBaseCharacterMap_ISO8859_15;
			break;
		case OB_ENCODING_ISO8859_16:
			result = &kOpenBaseCharacterMap_ISO8859_16;
			break;
		
		//	Japanese encodings
		case OB_ENCODING_ISO2022JP:
			result = NULL;
			break;
		case OB_ENCODING_EUC:
			result = NULL;
			break;
		case OB_ENCODING_SHIFTJIS:
			result = NULL;
			break;
	
		//	Mac OS Encodings
		case OB_ENCODING_MACOS_ROMAN:
			result = &kOpenBaseCharacterMap_MacOS_Roman;
			break;
		case OB_ENCODING_MACOS_ARABIC:
			result = &kOpenBaseCharacterMap_MacOS_Arabic;
			break;
		case OB_ENCODING_MACOS_CENTEURO:
			result = &kOpenBaseCharacterMap_MacOS_CentEuro;
			break;
		case OB_ENCODING_MACOS_CORPCHAR:
			result = &kOpenBaseCharacterMap_MacOS_CorpChar;
			break;
		case OB_ENCODING_MACOS_CROATIAN:
			result = &kOpenBaseCharacterMap_MacOS_Croatian;
			break;
		case OB_ENCODING_MACOS_CYRILLIC:
			result = &kOpenBaseCharacterMap_MacOS_Cyrillic;
			break;
		case OB_ENCODING_MACOS_DEVANAGA:
			result = &kOpenBaseCharacterMap_MacOS_Devanaga;
			break;
		case OB_ENCODING_MACOS_DINGBATS:
			result = &kOpenBaseCharacterMap_MacOS_Dingbats;
			break;
		case OB_ENCODING_MACOS_FARSI:
			result = &kOpenBaseCharacterMap_MacOS_Farsi;
			break;
		case OB_ENCODING_MACOS_GREEK:
			result = &kOpenBaseCharacterMap_MacOS_Greek;
			break;
		case OB_ENCODING_MACOS_GUJARATI:
			result = &kOpenBaseCharacterMap_MacOS_Gujarati;
			break;
		case OB_ENCODING_MACOS_GURMUKHI:
			result = &kOpenBaseCharacterMap_MacOS_Gurmukhi;
			break;
		case OB_ENCODING_MACOS_HEBREW:
			result = &kOpenBaseCharacterMap_MacOS_Hebrew;
			break;
		case OB_ENCODING_MACOS_ICELAND:
			result = &kOpenBaseCharacterMap_MacOS_Iceland;
			break;
		case OB_ENCODING_MACOS_ROMANIAN:
			result = &kOpenBaseCharacterMap_MacOS_Romanian;
			break;
		case OB_ENCODING_MACOS_SYMBOL:
			result = &kOpenBaseCharacterMap_MacOS_Symbol;
			break;
		case OB_ENCODING_MACOS_THAI:
			result = &kOpenBaseCharacterMap_MacOS_Thai;
			break;
		case OB_ENCODING_MACOS_TURKISH:
			result = &kOpenBaseCharacterMap_MacOS_Turkish;
			break;
		case OB_ENCODING_MACOS_UKRAINE:
			result = &kOpenBaseCharacterMap_MacOS_Ukraine;
			break;
			
		//	DOS encodings
		case OB_ENCODING_DOS_CP437_LATINUS:
			result = &kOpenBaseCharacterMap_DOS_CP437_LatinUS;
			break;
		case OB_ENCODING_DOS_CP737_GREEK:
			result = &kOpenBaseCharacterMap_DOS_CP737_Greek;
			break;
		case OB_ENCODING_DOS_CP775_BALTRIM:
			result = &kOpenBaseCharacterMap_DOS_CP775_BaltRim;
			break;
		case OB_ENCODING_DOS_CP850_LATIN1:
			result = &kOpenBaseCharacterMap_DOS_CP850_Latin1;
			break;
		case OB_ENCODING_DOS_CP852_LATIN2:
			result = &kOpenBaseCharacterMap_DOS_CP852_Latin2;
			break;
		case OB_ENCODING_DOS_CP855_CYRILLIC:
			result = &kOpenBaseCharacterMap_DOS_CP855_Cyrillic;
			break;
		case OB_ENCODING_DOS_CP857_TURKISH:
			result = &kOpenBaseCharacterMap_DOS_CP857_Turkish;
			break;
		case OB_ENCODING_DOS_CP860_PORTUGUESE:
			result = &kOpenBaseCharacterMap_DOS_CP860_Portuguese;
			break;
		case OB_ENCODING_DOS_CP861_ICELANDIC:
			result = &kOpenBaseCharacterMap_DOS_CP861_Icelandic;
			break;
		case OB_ENCODING_DOS_CP862_HEBREW:
			result = &kOpenBaseCharacterMap_DOS_CP862_Hebrew;
			break;
		case OB_ENCODING_DOS_CP863_CANADAF:
			result = &kOpenBaseCharacterMap_DOS_CP863_CanadaF;
			break;
		case OB_ENCODING_DOS_CP864_ARABIC:
			result = &kOpenBaseCharacterMap_DOS_CP864_Arabic;
			break;
		case OB_ENCODING_DOS_CP865_NORDIC:
			result = &kOpenBaseCharacterMap_DOS_CP865_Nordic;
			break;
		case OB_ENCODING_DOS_CP866_CYRILLICRUSSIAN:
			result = &kOpenBaseCharacterMap_DOS_CP866_CyrillicRussian;
			break;
		case OB_ENCODING_DOS_CP869_GREEK2:
			result = &kOpenBaseCharacterMap_DOS_CP869_Greek2;
			break;
		case OB_ENCODING_DOS_CP874_THAI:
			result = &kOpenBaseCharacterMap_DOS_CP874_Thai;
			break;

		//	Windows encodings
		case OB_ENCODING_WIN_CP874_THAI:
			result = &kOpenBaseCharacterMap_Win_CP874_Thai;
			break;

		case OB_ENCODING_WIN_CP1250_LATIN2:
			result = &kOpenBaseCharacterMap_Win_CP1250_Latin2;
			break;

		case OB_ENCODING_WIN_CP1251_CYRILLIC:
			result = &kOpenBaseCharacterMap_Win_CP1251_Cyrillic;
			break;

		case OB_ENCODING_WIN_CP1252_LATIN1:
			result = &kOpenBaseCharacterMap_Win_CP1252_Latin1;
			break;

		case OB_ENCODING_WIN_CP1253_GREEK:
			result = &kOpenBaseCharacterMap_Win_CP1253_Greek;
			break;

		case OB_ENCODING_WIN_CP1254_TURKISH:
			result = &kOpenBaseCharacterMap_Win_CP1254_Turkish;
			break;

		case OB_ENCODING_WIN_CP1255_HEBREW:
			result = &kOpenBaseCharacterMap_Win_CP1255_Hebrew;
			break;

		case OB_ENCODING_WIN_CP1256_ARABIC:
			result = &kOpenBaseCharacterMap_Win_CP1256_Arabic;
			break;

		case OB_ENCODING_WIN_CP1257_BALTRIM:
			result = &kOpenBaseCharacterMap_Win_CP1257_BaltRim;
			break;

		case OB_ENCODING_WIN_CP1258_VIETNAMESE:
			result = &kOpenBaseCharacterMap_Win_CP1258_Vietnamese;
			break;


		//	NeXT encodings
		case OB_ENCODING_NEXT:
			result = &kOpenBaseCharacterMap_NeXT;
			break;
	
	}
	
	return result;
}

const char*	ob_getEncodingName(int encoding)
{
	const char* result = NULL;
	
	switch (encoding)
	{
		case OB_ENCODING_ASCII:				result = "ASCII";								break;
		case OB_ENCODING_UTF8:				result = "UTF8";								break;
		case OB_ENCODING_UNICODE:			result = "Unicode (2 byte)";					break;
		
		case OB_ENCODING_ISO8859_1:			result = "ISO 8859-1 (Latin 1)";				break;
		case OB_ENCODING_ISO8859_2:			result = "ISO 8859-2 (Latin 2)";				break;
		case OB_ENCODING_ISO8859_3:			result = "ISO 8859-3 (Latin 3)";				break;
		case OB_ENCODING_ISO8859_4:			result = "ISO 8859-4 (Latin 4)";				break;
		case OB_ENCODING_ISO8859_5:			result = "ISO 8859-5 (Latin/Cyrillic)";			break;
		case OB_ENCODING_ISO8859_6:			result = "ISO 8859-6 (Arabic)";					break;
		case OB_ENCODING_ISO8859_7:			result = "ISO 8859-7 (Latin/Greek)";			break;
		case OB_ENCODING_ISO8859_8:			result = "ISO 8859-8 (Latin/Hebrew)";			break;
		case OB_ENCODING_ISO8859_9:			result = "ISO 8859-9 (Latin 5 - Turkish)";		break;
		case OB_ENCODING_ISO8859_10:		result = "ISO 8859-10 (Latin 6 - Nordic)";		break;
		case OB_ENCODING_ISO8859_13:		result = "ISO 8859-13 (Latin 7 - Baltic Rim)";	break;
		case OB_ENCODING_ISO8859_14:		result = "ISO 8859-14 (Latin 8 - Sami)";		break;
		case OB_ENCODING_ISO8859_15:		result = "ISO 8859-15 (Latin 9)";				break;
		case OB_ENCODING_ISO8859_16:		result = "ISO 8859-16 (Latin 10)";				break;
	
		case OB_ENCODING_ISO2022JP:			result = "ISO2022JP";							break;
		case OB_ENCODING_EUC:				result = "EUC";									break;
		case OB_ENCODING_SHIFTJIS:			result = "SHIFTJIS";							break;

		case OB_ENCODING_MACOS_ROMAN:		result = "Mac OS Roman";						break;
		case OB_ENCODING_MACOS_ARABIC:		result = "Mac OS Arabic";						break;
		case OB_ENCODING_MACOS_CENTEURO:	result = "Mac OS CentEuro";						break;
		case OB_ENCODING_MACOS_CORPCHAR:	result = "Mac OS CorpChar";						break;
		case OB_ENCODING_MACOS_CROATIAN:	result = "Mac OS Croatian";						break;
		case OB_ENCODING_MACOS_CYRILLIC:	result = "Mac OS Cyrillic";						break;
		case OB_ENCODING_MACOS_DEVANAGA:	result = "Mac OS Devanaga";						break;
		case OB_ENCODING_MACOS_DINGBATS:	result = "Mac OS Dingbats";						break;
		case OB_ENCODING_MACOS_FARSI:		result = "Mac OS Farsi";						break;
		case OB_ENCODING_MACOS_GREEK:		result = "Mac OS Greek";						break;
		case OB_ENCODING_MACOS_GUJARATI:	result = "Mac OS Gujarati";						break;
		case OB_ENCODING_MACOS_GURMUKHI:	result = "Mac OS Gurmukhi";						break;
		case OB_ENCODING_MACOS_HEBREW:		result = "Mac OS Hebrew";						break;
		case OB_ENCODING_MACOS_ICELAND:		result = "Mac OS Iceland";						break;
		case OB_ENCODING_MACOS_ROMANIAN:	result = "Mac OS Romanian";						break;
		case OB_ENCODING_MACOS_SYMBOL:		result = "Mac OS Symbol";						break;
		case OB_ENCODING_MACOS_THAI:		result = "Mac OS Thai";							break;
		case OB_ENCODING_MACOS_TURKISH:		result = "Mac OS Turkish";						break;
		case OB_ENCODING_MACOS_UKRAINE:		result = "Mac OS Ukraine";						break;
		
		
		case OB_ENCODING_DOS_CP437_LATINUS:			result = "DOS Latin US";				break;
		case OB_ENCODING_DOS_CP737_GREEK:			result = "DOS Greek";					break;
		case OB_ENCODING_DOS_CP775_BALTRIM:			result = "DOS Baltic Rim";				break;
		case OB_ENCODING_DOS_CP850_LATIN1:			result = "DOS Latin 2";					break;
		case OB_ENCODING_DOS_CP852_LATIN2:			result = "DOS Latin 1";					break;
		case OB_ENCODING_DOS_CP855_CYRILLIC:		result = "DOS Cyrillic";				break;
		case OB_ENCODING_DOS_CP857_TURKISH:			result = "DOS Turkish";					break;
		case OB_ENCODING_DOS_CP860_PORTUGUESE:		result = "DOS Portuguese";				break;
		case OB_ENCODING_DOS_CP861_ICELANDIC:		result = "DOS Icelandic";				break;
		case OB_ENCODING_DOS_CP862_HEBREW:			result = "DOS Hebrew";					break;
		case OB_ENCODING_DOS_CP863_CANADAF:			result = "DOS French Canadian";			break;
		case OB_ENCODING_DOS_CP864_ARABIC:			result = "DOS Arabic";					break;
		case OB_ENCODING_DOS_CP865_NORDIC:			result = "DOS Nordic";					break;
		case OB_ENCODING_DOS_CP866_CYRILLICRUSSIAN:	result = "DOS Cyrillic Russian";		break;
		case OB_ENCODING_DOS_CP869_GREEK2:			result = "DOS Greek 2";					break;
		case OB_ENCODING_DOS_CP874_THAI:			result = "DOS Thai";					break;

		case OB_ENCODING_NEXT:				result = "NeXT";								break;
		
		default:							result = "Unknown";								break;
	}

	return result;
}


#define DEBUG
#ifdef DEBUG
#include <stdio.h>
extern void out ( const char* label, const char* msg );
#endif



//	if you need to do conversions of your own, this is exposed
//	caller owns result, must free()
unsigned char* ob_convertCharacters(int from_code, int to_code, const unsigned char* source, int* size)
{
	unsigned char* result = NULL;
	unsigned short* unicode = NULL;
	int source_size;
	int unicode_size = 0;
	int result_size = 0;

#ifdef DEBUG
	char s[1000];
	sprintf ( s, "ob_convertCharacters from encoding %d to %d size %d", from_code, to_code, *size );
	//out ( "", s );
#endif

	// out ( "convert", "1" );

	if (from_code == to_code || from_code == OB_ENCODING_UNKNOWN || to_code == OB_ENCODING_UNKNOWN )
	{
		// out ( "convert", "2" );
		//	make a copy of the indicated number of bytes
		if (source != NULL)
		{
			if (size != NULL)
			{
				source_size = *size;
				result_size = source_size;
			}
			else
			{
				if (from_code == OB_ENCODING_UNICODE)
				{
					source_size = unicode_strlen((const unsigned short*) source) + 1;
					result_size = 2 * source_size;
				}
				else
				{
					source_size = strlen((const char*) source) + 1;
					result_size = source_size;
				}
			}
			
			result = (unsigned char*) malloc(result_size);
			if (result != NULL)
			{
                            memcpy(result, source, result_size);
			}
		}
	}
	else
	{
		// out ( "convert", "3" );

		//	first convert to unicode
		if (source != NULL)
		{
			if (size != NULL)
			{
				source_size = *size;
			}
			else
			{
				if (from_code == OB_ENCODING_UNICODE)
				{
					source_size = unicode_strlen((const unsigned short*) source) + 1;
				}
				else
				{
					source_size = strlen((const char*) source) + 1;
				}
			}

			// out ( "convert", "4" );
		
			if (from_code == OB_ENCODING_UNICODE)
			{
				//	do nothing
				unicode_size = 2 * source_size;
				unicode = (unsigned short*) source;
			}
			else if (from_code == OB_ENCODING_UTF8)
			{
				// out ( "convert", "5" );
				unicode_size = source_size;
				unicode = ob_decodeUTF8(source, &unicode_size);
			}
			else
			{
				// out ( "convert", "6" );
				OpenBaseCharacterMap* map = ob_getCharacterMap(from_code);
				if (map != NULL)
				{
					unicode_size = 2 * source_size;
					unicode = (unsigned short*) malloc(unicode_size);
					if (unicode != NULL)
					{
						int i = 0;
						while (i < source_size)
						{
							// out ( "convert", "7" );
							unicode[i] = map->mapToUnicode[source[i]];
							i++;
						}
					}
				}
			}
		}
		// out ( "convert", "8" );

		//	now convert to to_code
		if (unicode != NULL)
		{
			if (to_code == OB_ENCODING_UNICODE)
			{
				result_size = unicode_size;
				result = (unsigned char*) unicode;
			}
			else if (to_code == OB_ENCODING_UTF8)
			{
				//	compress UTF8
				// out ( "convert", "9" );
				result_size = unicode_size / 2;
				result = ob_encodeUTF8(unicode, &result_size);
				free(unicode);
			}
			else
			{
				// out ( "convert", "10" );
				OpenBaseCharacterMap* map = ob_getCharacterMap(to_code);
				// out ( "convert", "11" );
				if (map != NULL)
				{

					// out ( "convert", "12" );

					char z[100];
					sprintf ( z, "%d", unicode_size );
					// out ( "unicode_size", z );

					result_size = unicode_size / 2;
					result = (unsigned char*) malloc(result_size);
					// out ( "convert", "12.1" );
					if (result != NULL)
					{
						// out ( "convert", "13" );
						int i = 0;
						while (i < result_size)
						{
							// out ( "convert", "13.1" );
							//	binary search the map for the character
							result[i] = map_from_unicode(unicode[i], map);
							i++;
						}
						// out ( "convert", "14" );

						//	ASCII should be restricted to characters 0-127
						//	Do this by hand since a mapping doesn't make complete sense
						//	and it can use the Latin1 mapping to get halfway there.
						if (to_code == OB_ENCODING_ASCII)
						{
							// out ( "convert", "14.1" );
							for (i = 0; i < result_size; i++)
							{
								if (((unsigned char) result[i]) > 127)
								{
									result[i] = '?';
								}
							}
						}
					}
					else { 
					//out ("","malloc failure");
					}
				}
				// out ( "convert", "15" );
				free(unicode);
				// out ( "convert", "15.1" );
			}
		}

		// out ( "convert", "16" );
		if (size != NULL)
		{
			// out ( "convert", "17" );
			*size = (result != NULL) ? result_size : 0;
		}
	}
	// out ( "convert", "18" );

	return result;
}

//	call this on SQL statements before sending to server
//	caller owns result, must free()
/*
unsigned char* ob_convertSQLStatement(OB_Connection* connection, const unsigned char* source, int* size)
{
	unsigned char* result = NULL;
	int database_encoding = -1;
	int client_encoding = -1;
	
	if (connection != NULL)
	{
		database_encoding = ob_databaseEncoding(connection);
		client_encoding = ob_clientEncoding(connection);
		result = ob_convertCharacters(client_encoding, database_encoding, source, size);
	}
	
	return result;
}

//	call this on character results restured from server
//	caller owns result, must free()
unsigned char* ob_convertResult(OB_Connection* connection, const unsigned char* source, int* size)
{
	unsigned char* result = NULL;
	int database_encoding = -1;
	int client_encoding = -1;
	
	if (connection != NULL)
	{
		database_encoding = ob_databaseEncoding(connection);
		client_encoding = ob_clientEncoding(connection);
		result = ob_convertCharacters(database_encoding, client_encoding, source, size);
	}

	return result;
}

*/

//================================================================================
//	Character Maps
//================================================================================

#pragma mark -


OpenBaseCharacterMap	kOpenBaseCharacterMap_ISO2022JP;
OpenBaseCharacterMap	kOpenBaseCharacterMap_EUC;
OpenBaseCharacterMap	kOpenBaseCharacterMap_SHIFTJIS;

#pragma mark kOpenBaseCharacterMap_NeXT
OpenBaseCharacterMap kOpenBaseCharacterMap_NeXT = 
{
	//      _fMapToUnicode
	{
		0x0000, 0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007,
		0x0008, 0x0009, 0x000A, 0x000B, 0x000C, 0x000D, 0x000E, 0x000F,
		0x0010, 0x0011, 0x0012, 0x0013, 0x0014, 0x0015, 0x0016, 0x0017,
		0x0018, 0x0019, 0x001A, 0x001B, 0x001C, 0x001D, 0x001E, 0x001F,
		0x0020, 0x0021, 0x0022, 0x0023, 0x0024, 0x0025, 0x0026, 0x0027,
		0x0028, 0x0029, 0x002A, 0x002B, 0x002C, 0x002D, 0x002E, 0x002F,
		0x0030, 0x0031, 0x0032, 0x0033, 0x0034, 0x0035, 0x0036, 0x0037,
		0x0038, 0x0039, 0x003A, 0x003B, 0x003C, 0x003D, 0x003E, 0x003F,
		0x0040, 0x0041, 0x0042, 0x0043, 0x0044, 0x0045, 0x0046, 0x0047,
		0x0048, 0x0049, 0x004A, 0x004B, 0x004C, 0x004D, 0x004E, 0x004F,
		0x0050, 0x0051, 0x0052, 0x0053, 0x0054, 0x0055, 0x0056, 0x0057,
		0x0058, 0x0059, 0x005A, 0x005B, 0x005C, 0x005D, 0x005E, 0x005F,
		0x0060, 0x0061, 0x0062, 0x0063, 0x0064, 0x0065, 0x0066, 0x0067,
		0x0068, 0x0069, 0x006A, 0x006B, 0x006C, 0x006D, 0x006E, 0x006F,
		0x0070, 0x0071, 0x0072, 0x0073, 0x0074, 0x0075, 0x0076, 0x0077,
		0x0078, 0x0079, 0x007A, 0x007B, 0x007C, 0x007D, 0x007E, 0x007F,
		0x00A0, 0x00C0, 0x00C1, 0x00C2, 0x00C3, 0x00C4, 0x00C5, 0x00C7,
		0x00C8, 0x00C9, 0x00CA, 0x00CB, 0x00CC, 0x00CD, 0x00CE, 0x00CF,
		0x00D0, 0x00D1, 0x00D2, 0x00D3, 0x00D4, 0x00D5, 0x00D6, 0x00D9,
		0x00DA, 0x00DB, 0x00DC, 0x00DD, 0x00DE, 0x00B5, 0x00D7, 0x00F7,
		0x00A9, 0x00A1, 0x00A2, 0x00A3, 0x2044, 0x00A5, 0x0192, 0x00A7,
		0x00A4, 0x2019, 0x201C, 0x00AB, 0x2039, 0x203A, 0xFB01, 0xFB02,
		0x00AE, 0x2013, 0x2020, 0x2021, 0x00B7, 0x00A6, 0x00B6, 0x2022,
		0x201A, 0x201E, 0x201D, 0x00BB, 0x2026, 0x2030, 0x00AC, 0x00BF,
		0x00B9, 0x02CB, 0x00B4, 0x02C6, 0x02DC, 0x00AF, 0x02D8, 0x02D9,
		0x00A8, 0x00B2, 0x02DA, 0x00B8, 0x00B3, 0x02DD, 0x02DB, 0x02C7,
		0x2014, 0x00B1, 0x00BC, 0x00BD, 0x00BE, 0x00E0, 0x00E1, 0x00E2,
		0x00E3, 0x00E4, 0x00E5, 0x00E7, 0x00E8, 0x00E9, 0x00EA, 0x00EB,
		0x00EC, 0x00C6, 0x00ED, 0x00AA, 0x00EE, 0x00EF, 0x00F0, 0x00F1,
		0x0141, 0x00D8, 0x0152, 0x00BA, 0x00F2, 0x00F3, 0x00F4, 0x00F5,
		0x00F6, 0x00E6, 0x00F9, 0x00FA, 0x00FB, 0x0131, 0x00FC, 0x00FD,
		0x0142, 0x00F8, 0x0153, 0x00DF, 0x00FE, 0x00FF, 0xFFFD, 0xFFFD
	},

	//      mapFromUnicode
	{
		{ 0x0000, 0x0000 }, { 0x0001, 0x0001 }, { 0x0002, 0x0002 }, { 0x0003, 0x0003 },
		{ 0x0004, 0x0004 }, { 0x0005, 0x0005 }, { 0x0006, 0x0006 }, { 0x0007, 0x0007 },
		{ 0x0008, 0x0008 }, { 0x0009, 0x0009 }, { 0x000A, 0x000A }, { 0x000B, 0x000B },
		{ 0x000C, 0x000C }, { 0x000D, 0x000D }, { 0x000E, 0x000E }, { 0x000F, 0x000F },
		{ 0x0010, 0x0010 }, { 0x0011, 0x0011 }, { 0x0012, 0x0012 }, { 0x0013, 0x0013 },
		{ 0x0014, 0x0014 }, { 0x0015, 0x0015 }, { 0x0016, 0x0016 }, { 0x0017, 0x0017 },
		{ 0x0018, 0x0018 }, { 0x0019, 0x0019 }, { 0x001A, 0x001A }, { 0x001B, 0x001B },
		{ 0x001C, 0x001C }, { 0x001D, 0x001D }, { 0x001E, 0x001E }, { 0x001F, 0x001F },
		{ 0x0020, 0x0020 }, { 0x0021, 0x0021 }, { 0x0022, 0x0022 }, { 0x0023, 0x0023 },
		{ 0x0024, 0x0024 }, { 0x0025, 0x0025 }, { 0x0026, 0x0026 }, { 0x0027, 0x0027 },
		{ 0x0028, 0x0028 }, { 0x0029, 0x0029 }, { 0x002A, 0x002A }, { 0x002B, 0x002B },
		{ 0x002C, 0x002C }, { 0x002D, 0x002D }, { 0x002E, 0x002E }, { 0x002F, 0x002F },
		{ 0x0030, 0x0030 }, { 0x0031, 0x0031 }, { 0x0032, 0x0032 }, { 0x0033, 0x0033 },
		{ 0x0034, 0x0034 }, { 0x0035, 0x0035 }, { 0x0036, 0x0036 }, { 0x0037, 0x0037 },
		{ 0x0038, 0x0038 }, { 0x0039, 0x0039 }, { 0x003A, 0x003A }, { 0x003B, 0x003B },
		{ 0x003C, 0x003C }, { 0x003D, 0x003D }, { 0x003E, 0x003E }, { 0x003F, 0x003F },
		{ 0x0040, 0x0040 }, { 0x0041, 0x0041 }, { 0x0042, 0x0042 }, { 0x0043, 0x0043 },
		{ 0x0044, 0x0044 }, { 0x0045, 0x0045 }, { 0x0046, 0x0046 }, { 0x0047, 0x0047 },
		{ 0x0048, 0x0048 }, { 0x0049, 0x0049 }, { 0x004A, 0x004A }, { 0x004B, 0x004B },
		{ 0x004C, 0x004C }, { 0x004D, 0x004D }, { 0x004E, 0x004E }, { 0x004F, 0x004F },
		{ 0x0050, 0x0050 }, { 0x0051, 0x0051 }, { 0x0052, 0x0052 }, { 0x0053, 0x0053 },
		{ 0x0054, 0x0054 }, { 0x0055, 0x0055 }, { 0x0056, 0x0056 }, { 0x0057, 0x0057 },
		{ 0x0058, 0x0058 }, { 0x0059, 0x0059 }, { 0x005A, 0x005A }, { 0x005B, 0x005B },
		{ 0x005C, 0x005C }, { 0x005D, 0x005D }, { 0x005E, 0x005E }, { 0x005F, 0x005F },
		{ 0x0060, 0x0060 }, { 0x0061, 0x0061 }, { 0x0062, 0x0062 }, { 0x0063, 0x0063 },
		{ 0x0064, 0x0064 }, { 0x0065, 0x0065 }, { 0x0066, 0x0066 }, { 0x0067, 0x0067 },
		{ 0x0068, 0x0068 }, { 0x0069, 0x0069 }, { 0x006A, 0x006A }, { 0x006B, 0x006B },
		{ 0x006C, 0x006C }, { 0x006D, 0x006D }, { 0x006E, 0x006E }, { 0x006F, 0x006F },
		{ 0x0070, 0x0070 }, { 0x0071, 0x0071 }, { 0x0072, 0x0072 }, { 0x0073, 0x0073 },
		{ 0x0074, 0x0074 }, { 0x0075, 0x0075 }, { 0x0076, 0x0076 }, { 0x0077, 0x0077 },
		{ 0x0078, 0x0078 }, { 0x0079, 0x0079 }, { 0x007A, 0x007A }, { 0x007B, 0x007B },
		{ 0x007C, 0x007C }, { 0x007D, 0x007D }, { 0x007E, 0x007E }, { 0x007F, 0x007F },
		{ 0x00A0, 0x0080 }, { 0x00A1, 0x00A1 }, { 0x00A2, 0x00A2 }, { 0x00A3, 0x00A3 },
		{ 0x00A4, 0x00A8 }, { 0x00A5, 0x00A5 }, { 0x00A6, 0x00B5 }, { 0x00A7, 0x00A7 },
		{ 0x00A8, 0x00C8 }, { 0x00A9, 0x00A0 }, { 0x00AA, 0x00E3 }, { 0x00AB, 0x00AB },
		{ 0x00AC, 0x00BE }, { 0x00AE, 0x00B0 }, { 0x00AF, 0x00C5 }, { 0x00B1, 0x00D1 },
		{ 0x00B2, 0x00C9 }, { 0x00B3, 0x00CC }, { 0x00B4, 0x00C2 }, { 0x00B5, 0x009D },
		{ 0x00B6, 0x00B6 }, { 0x00B7, 0x00B4 }, { 0x00B8, 0x00CB }, { 0x00B9, 0x00C0 },
		{ 0x00BA, 0x00EB }, { 0x00BB, 0x00BB }, { 0x00BC, 0x00D2 }, { 0x00BD, 0x00D3 },
		{ 0x00BE, 0x00D4 }, { 0x00BF, 0x00BF }, { 0x00C0, 0x0081 }, { 0x00C1, 0x0082 },
		{ 0x00C2, 0x0083 }, { 0x00C3, 0x0084 }, { 0x00C4, 0x0085 }, { 0x00C5, 0x0086 },
		{ 0x00C6, 0x00E1 }, { 0x00C7, 0x0087 }, { 0x00C8, 0x0088 }, { 0x00C9, 0x0089 },
		{ 0x00CA, 0x008A }, { 0x00CB, 0x008B }, { 0x00CC, 0x008C }, { 0x00CD, 0x008D },
		{ 0x00CE, 0x008E }, { 0x00CF, 0x008F }, { 0x00D0, 0x0090 }, { 0x00D1, 0x0091 },
		{ 0x00D2, 0x0092 }, { 0x00D3, 0x0093 }, { 0x00D4, 0x0094 }, { 0x00D5, 0x0095 },
		{ 0x00D6, 0x0096 }, { 0x00D7, 0x009E }, { 0x00D8, 0x00E9 }, { 0x00D9, 0x0097 },
		{ 0x00DA, 0x0098 }, { 0x00DB, 0x0099 }, { 0x00DC, 0x009A }, { 0x00DD, 0x009B },
		{ 0x00DE, 0x009C }, { 0x00DF, 0x00FB }, { 0x00E0, 0x00D5 }, { 0x00E1, 0x00D6 },
		{ 0x00E2, 0x00D7 }, { 0x00E3, 0x00D8 }, { 0x00E4, 0x00D9 }, { 0x00E5, 0x00DA },
		{ 0x00E6, 0x00F1 }, { 0x00E7, 0x00DB }, { 0x00E8, 0x00DC }, { 0x00E9, 0x00DD },
		{ 0x00EA, 0x00DE }, { 0x00EB, 0x00DF }, { 0x00EC, 0x00E0 }, { 0x00ED, 0x00E2 },
		{ 0x00EE, 0x00E4 }, { 0x00EF, 0x00E5 }, { 0x00F0, 0x00E6 }, { 0x00F1, 0x00E7 },
		{ 0x00F2, 0x00EC }, { 0x00F3, 0x00ED }, { 0x00F4, 0x00EE }, { 0x00F5, 0x00EF },
		{ 0x00F6, 0x00F0 }, { 0x00F7, 0x009F }, { 0x00F8, 0x00F9 }, { 0x00F9, 0x00F2 },
		{ 0x00FA, 0x00F3 }, { 0x00FB, 0x00F4 }, { 0x00FC, 0x00F6 }, { 0x00FD, 0x00F7 },
		{ 0x00FE, 0x00FC }, { 0x00FF, 0x00FD }, { 0x0131, 0x00F5 }, { 0x0141, 0x00E8 },
		{ 0x0142, 0x00F8 }, { 0x0152, 0x00EA }, { 0x0153, 0x00FA }, { 0x0192, 0x00A6 },
		{ 0x02C6, 0x00C3 }, { 0x02C7, 0x00CF }, { 0x02CB, 0x00C1 }, { 0x02D8, 0x00C6 },
		{ 0x02D9, 0x00C7 }, { 0x02DA, 0x00CA }, { 0x02DB, 0x00CE }, { 0x02DC, 0x00C4 },
		{ 0x02DD, 0x00CD }, { 0x2013, 0x00B1 }, { 0x2014, 0x00D0 }, { 0x2019, 0x00A9 },
		{ 0x201A, 0x00B8 }, { 0x201C, 0x00AA }, { 0x201D, 0x00BA }, { 0x201E, 0x00B9 },
		{ 0x2020, 0x00B2 }, { 0x2021, 0x00B3 }, { 0x2022, 0x00B7 }, { 0x2026, 0x00BC },
		{ 0x2030, 0x00BD }, { 0x2039, 0x00AC }, { 0x203A, 0x00AD }, { 0x2044, 0x00A4 },
		{ 0xFB01, 0x00AE }, { 0xFB02, 0x00AF }, { 0xFFFD, 0x00FE }, { 0xFFFD, 0x00FF }
	},

	//      defaultCharacter
	'?'
} ;


#ifdef __cplusplus
}
#endif

