/* conversion.h created by root on Wed 28-Jan-1998 */

void convert_convertToMoney(long long value, char *string, const char *prefix, const char *postfix);
char *convert_convertFromTime(char *str, int formatType);
char *convert_convertFromDate(char *str, int formatType);
void convert_movePointToLeft(char *str);
void strip(char * in, char *out);
int moneyToInt(char *money);
long moneyToLong(char *money);
double moneyToDouble(char *money);

