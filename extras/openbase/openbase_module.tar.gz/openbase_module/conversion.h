// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
// History
//
// [jsh]	John Heaney, Solid Object Software
//			heaney@SolidObject.com
//
// [jsh] 11/07/2003 
//		Removed unnecessary include directive.
//		Added constant symbols for date and time formatting.
//
// ----------------------------------------------------------------------------------------

#ifndef __CONVERSION_H__
#define __CONVERSION_H__

#ifdef __cplusplus
	extern "C" {
#endif

//--------------------------------------------------------------------------------
//	OB_DateTime
//--------------------------------------------------------------------------------

typedef struct OB_DateTimeStruct
{
	int		year;				//	date portion
	int		month;
	int		day;
	
	int		hour;				//	time portion
	int		minute;

	int		second;				//	datetime portion
	int		timezone_offset;

	int		date_valid;			//	1 if date portion is valid
	int		time_valid;			//	1 if time portion is valid
	int		datetime_valid;		//	1 if datetime portion is valid
	
	long long	platform_seconds;	//	seconds since platform epoch

} OB_DateTime;

#define dateFormat_Mon_sp_D_comma_sp_Y 0
#define dateFormat_D_sp_Mon_sp_Y 1
#define dateFormat_0M_dash_0D_dash_YYYY 2
#define dateFormat_0M_div_0D_div_YYYY 3
#define dateFormat_D_dot_M_dot_YYYY 4

#define timeFormat_H_colon_0M_sp_ampm 0
#define timeFormat_0H_colon_0M '1'


void 	convert_convertToMoney( long long value, char *string, const char *prefix, const char *postfix);
								
char *	convert_convertFromTime(char *str, int formatType);

char *	convert_convertFromDate(char *str, int formatType);

void 	convert_movePointToLeft(char *str);

void 	strip(char * in, char *out);

int 	moneyToInt(char *money);

long 	moneyToLong(char *money);

double 	moneyToDouble(char *money);

void	ob_NSDateTimeToOB_DateTime(long long ns_date_time, OB_DateTime* ob_date_time, int local);

//	void	ob_NSDateTimeToPlatformDatetime(long long* ioDateTime);

//	reads in long long value from ns_date_time_ll_string
//	writes out formatted time to date_time_string
//	applies local timezone if local != 0
void	ob_NSDateTimeToDatetimeString(const char* ns_date_time_ll_string, char* date_time_string, int local);

//	returns number of seconds client timezone is offset from utc.							
long	ob_timezoneOffset();

#ifdef __cplusplus
	}
#endif

#endif // __CONVERSION_H__

// ----------------------------------------------------------------------------------------
