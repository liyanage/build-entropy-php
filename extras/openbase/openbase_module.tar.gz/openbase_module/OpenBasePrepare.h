/* OpenBasePrepare.h created by root on Mon 19-Jan-1998 */

int ob_prepareStatement(OpenBase *conn, const char *sqlstring);
int ob_prepareSelectStatement(OpenBase *conn, const char *sqlstring);
void ob_preparedValue(OpenBase *conn, const char *sqlValue);
int ob_preparedExecute(OpenBase *conn);
