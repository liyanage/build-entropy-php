// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
#include "platform.h"

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
	
#ifdef WINNT
	#include <windows.h>
	#include <time.h>
#endif

#if MACOSX_CARBON 
		#include <time.h>
		#include <DateTimeUtils.h>
		#include <UTCUtils.h>
#endif

#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY 
	#include <sys/time.h>
#endif

#include "datetime.h"

/*
// Not used, but interesting nonetheless
#ifdef WINNT
#define NSTimeIntervalSince1601 12622780800.0

int gettimeofday (struct timeval *tvp, struct timezone *tzp)
{
        if (tzp) {
                TIME_ZONE_INFORMATION tzinfo;
                DWORD tzresult = GetTimeZoneInformation(&tzinfo);
                if (0xFFFFFFFF == tzresult)
                        return -1;
                tzp->tz_minuteswest = tzinfo.Bias;
                if (0 != tzinfo.StandardDate.wMonth)
                        tzp->tz_minuteswest += tzinfo.StandardBias;
                tzp->tz_dsttime = (tzresult == TIME_ZONE_ID_DAYLIGHT);
        }
        if (tvp) {
                FILETIME ft;
                double ti;
                GetSystemTimeAsFileTime(&ft);
                ti = (double)ft.dwHighDateTime * 4294967296.0 +
(double)ft.dwLowDateTime;
                ti -= 116444736000000000.0;	// 100-nanosecond units
//between 1601 and 1970
                tvp->tv_sec = (long)(ti / 10000000.0);
                tvp->tv_usec = (long)((ti - (tvp->tv_sec * 10000000.0)) / 10.0);
        }
        return 0;
}
#endif
*/

// local prototypes
static void initGMTOffset() ;
static short isDSTInEffectOnDate(int year, int mon, int day, int hour, int minute, int seconds) ;
static double yearToseconds(long y) ;
static int isLeapYear(long year) ;
static double monthToSeconds(int m, int isLeapYear) ;
static double daysToSeconds(long d) ;
static double hoursToSeconds(long h) ;
static double minutesToSeconds(long m) ;
static long secondsToMin(double *s) ;
static long secondsToHours(double *s) ;
static long secondsToDays(double *s) ;
static long secondsToMonth(double *s, int isLeapYear) ;
static long secondsToYear(double *s) ;

static char  gmtstring[30];
static char  gmtstring_DST[30];
static long  gmtoffset = 0 ; 
static long  gmtoffset_DST = 0 ; 
static short gmtinitFlag = 0 ;

// ------------------------------------------------------------------------------------------
static void initGMTOffset() 
{

	long currentGMTOffset;
	long newGMTOffset ;

#ifdef __MWERKS__

	#if MACOS_CLASSIC
		#warning COMPILING FOR CLASSIC !!!!!
		return 0
		
	#elif MACOSX_CARBON

		// start from Jan 1 , 2000 and get the two offsets for DST and not
		// if GMToffset < 0 then they are WEST of GMT (and therefore behind hours, so DST should be > GMT)
		// if GMToffset > 0 then they are EAST of GMT (and therefore ahead  hours, so DST should be < GMT)

		unsigned long secs ;
		unsigned long UTCsecs ;
		short ahead = 0 ;
			
		GetDateTime(&secs) ; // the offset for today is .....
		ConvertLocalTimeToUTC(secs, &UTCsecs ) ;

		currentGMTOffset = secs - UTCsecs ; // note that this will tell us whether we are ahead or behind UTC
		
		gmtoffset = currentGMTOffset ;
		gmtoffset_DST = currentGMTOffset ;
		
		// now find a day in the next year where the offset varies
		for ( int j = 0 ; j < 365 ; j++ )
		{
			ConvertLocalTimeToUTC(secs, &UTCsecs ) ;
			newGMTOffset = secs - UTCsecs ; // note this is in SECONDS !
			if ( newGMTOffset == currentGMTOffset )
				secs = secs + 86400 ;		
			else
			{
				gmtoffset = currentGMTOffset ;
				if ( newGMTOffset < gmtoffset ) gmtoffset = newGMTOffset ;

				gmtoffset_DST = currentGMTOffset ;
				if ( newGMTOffset > gmtoffset_DST ) gmtoffset_DST = newGMTOffset ;
				
				break ;
			}
		}
	#endif
	
#else

	struct timeval tp;
	struct timezone tz;
	time_t todaySeconds ;
	struct tm *local_tm ;
	int j ;
	
	gettimeofday(&tp, &tz); /// get todays gmt offset

	currentGMTOffset = (tz.tz_minuteswest * -1) * 60L ; // offset in secs 

	// set the normal and DST version of the offset to the same value
	gmtoffset = currentGMTOffset ;
	gmtoffset_DST = currentGMTOffset ;

	todaySeconds = tp.tv_sec ;
	
	// now find a day in the next year where the offset varies if there is one to
	// figure out hte DST offset (if it exists) .... it may not
	for ( j = 0 ; j < 365 ; j++ )
	{
		local_tm = localtime(&todaySeconds) ;
		newGMTOffset = local_tm->tm_gmtoff ;

		// if the nw offset is different than the one we found at the outset it's either the
		// first one is DST and this is the non-DST version
		// or the first one is the non-DST version and this is the DST version
		// so decide which and set accordingly
		if ( newGMTOffset == currentGMTOffset )
			todaySeconds = todaySeconds + 86400 ;		
		else
		{
			if (local_tm->tm_isdst) 
				gmtoffset_DST = newGMTOffset ;
			else
				gmtoffset = newGMTOffset ;
			
			break ;
		}
	}

#endif

	long gmthours = gmtoffset / 3600L ;
	long gmtminutes = (gmtoffset / 60L) - (gmthours * 60L);
	
	// CREATE GMT OFFSET
	if (gmtoffset >= 0) 
	{
		if ( gmthours >= 10 )
			sprintf(gmtstring,"+%02d%02d", gmthours, gmtminutes) ;
		else
			sprintf(gmtstring,"+%01d%02d", gmthours, gmtminutes);			
	} 
	else 
	{
		if ( abs(gmthours) >= 10 )
			sprintf(gmtstring,"-%02d%02d", abs(gmthours), abs(gmtminutes)) ;
		else
			sprintf(gmtstring,"-%01d%02d", abs(gmthours), abs(gmtminutes));
	}

	
	// CREATE GMT OFFSET for DST
	gmthours = gmtoffset_DST / 3600L ;
	gmtminutes = (gmtoffset_DST / 60L) - (gmthours * 60L);

	if (gmtoffset_DST >= 0) 
	{
		if ( gmthours >= 10 )
			sprintf(gmtstring_DST,"+%02d%02d", gmthours, gmtminutes) ;
		else
			sprintf(gmtstring_DST,"+%01d%02d", gmthours, gmtminutes);			
	} 
	else 
	{
		if ( abs(gmthours) >= 10 )
			sprintf(gmtstring_DST,"-%02d%02d", abs(gmthours), abs(gmtminutes)) ;
		else
			sprintf(gmtstring_DST,"-%01d%02d", abs(gmthours), abs(gmtminutes));
	}


}

// ------------------------------------------------------------------------------------------
void initDateTime()
{

	if (!gmtinitFlag) 
	{
		
		initGMTOffset() ;
		
		gmtinitFlag = 1;
		return;
	}
}

// ------------------------------------------------------------------------------------------
static short isDSTInEffectOnDate(int year, int mon, int day, int hour, int minute, int seconds)
{
	// time given is UTC TIME !!!!!
#ifdef __MWERKS__
	#if TARGET_API_MAC_OS8
		#pragma unused (  year, mon, day, hour, minute, seconds)

		#warning COMPILING FOR CLASSIC !!!!!

		return 0 ;
		
	#elif TARGET_API_MAC_CARBON

		DateTimeRec d ;
		unsigned long secs ;	
		unsigned long UTCsecs ;	

		long GMTOffset;

		d.year   = year ;
		d.month  = mon ;
		d.day    = day ;
		d.hour   = hour ;
		d.minute = minute ;
		d.second = seconds ;

		DateToSeconds (&d, &UTCsecs) ; //treats the date as UTC
		ConvertUTCToLocalTime(UTCsecs, &secs ) ; // convert to local time
		SecondsToDate(secs, &d) ;
		
		GMTOffset = secs - UTCsecs ; // note that this will tell us whether we are ahead or behind UTC

		// if the offset leads us to believe this IS a dst date 
		if (GMTOffset == gmtoffset_DST)
		{
			// we need to check and see if this place observes daylight time
			// if normal and dst are the same this place does NOT observe daylight time
			if ( gmtoffset == gmtoffset_DST ) 
				return 0 ;
			else
				return 1 ;
		}
		else 
			return 0 ;
	#else // WIN32 in CodeWarrior !!!!!
		#pragma unused (  year, mon, day, hour, minute, seconds)
		
		return 0 ;
	#endif
	
#else

	// we're given UTC and need to deal with it as such
	struct tm time_str;
	time_t gmtsecs ;
	time_t localsecs ;
	struct tm *localtime_str ;
	
	time_str.tm_year = (year - 1900);
	time_str.tm_mon = (mon - 1);
	time_str.tm_mday = day;
	time_str.tm_hour = hour;
	time_str.tm_min = minute;
	time_str.tm_sec = seconds;
	time_str.tm_isdst = -1;

	gmtsecs = timegm(&time_str) ;	// make the UTC representation of the time
	localtime_str = localtime(&gmtsecs) ; // convert that to local time
	localsecs = mktime(localtime_str) ; // and get the broken down version so we can see if DST is enabled
	
	if (localtime_str->tm_isdst > 0 ) 
		return 1 ;
	else
		return 0 ;
		
#endif
}

// ------------------------------------------------------------------------------------------
static double yearToseconds(long y)
{
	double seconds;
	
	double leapdays = 0.0;	
	double leapcenturies = 0.0;	
	double centuries = 0.0;	
	double yearoffset = 0.0;
	
	
	if (y < 2001) {
		yearoffset = y - 2000;
	} else {
		yearoffset = y - 2001;
	}
	
	// first calculate centuries
	// extra day every 400 years
	if ((yearoffset >= 100.0) || (yearoffset <= -100.0)) {
		centuries = yearoffset / 100.0;
		modf(centuries,&centuries);
		
		// calculate the leap years for the centuries
		leapcenturies = centuries / 4.0;
		modf(leapcenturies,&leapcenturies);
		
		centuries = centuries - leapcenturies;
				
		yearoffset = yearoffset - ((centuries + leapcenturies) * 100);
	}
	
	if (yearoffset != 0.0) {
		leapdays = yearoffset / 4.0;
		modf(leapdays,&leapdays);
	}  
	
	leapdays = leapdays + (centuries * 24) + (leapcenturies * 25);

	if (y < 2001) {
		leapdays = leapdays - 1.0;
	}
		
	yearoffset = y - 2001;
		
	seconds = (double)((yearoffset * 365.0) + (double)leapdays) * 24.0 * 60.0 * 60.0;
	
	return seconds;
}

// ------------------------------------------------------------------------------------------
static int isLeapYear(long year) 
{
	long hold;
	long yearoffset;
	
	yearoffset = year - 2000;

	if (yearoffset == 0)
		return 1;


	// find century leap year
	hold = yearoffset / 100;
	hold = hold * 100;
	if (hold == yearoffset) 
	{
		hold = yearoffset / 400;
		hold = hold * 400;
		if (hold == yearoffset) 
		{
			return 1;
		} 
		return 0;
	}
	
	// if the year is not a century boundary
		
	hold = yearoffset / 4;
	hold = hold * 4;
	if (hold == yearoffset) 
	{
		return 1;
	}
	return 0;
}

// ------------------------------------------------------------------------------------------
static double monthToSeconds(int m, int isLeapYear)
{
	switch(m) {
		case 1:
			return 0;
		case 2:
			return 31 * 24 * 60 * 60;
		case 3:
			return (59 + isLeapYear) * 24 * 60 * 60;
		case 4:
			return (90 + isLeapYear) * 24 * 60 * 60;
		case 5:
			return (120 + isLeapYear) * 24 * 60 * 60;
		case 6:
			return (151 + isLeapYear) * 24 * 60 * 60;
		case 7:
			return (181 + isLeapYear) * 24 * 60 * 60;
		case 8:
			return (212 + isLeapYear) * 24 * 60 * 60;
		case 9:
			return (243 + isLeapYear) * 24 * 60 * 60;
		case 10:
			return (273 + isLeapYear) * 24 * 60 * 60;
		case 11:
			return (304 + isLeapYear) * 24 * 60 * 60;
		case 12:
			return (334 + isLeapYear) * 24 * 60 * 60;
	}
	return 0;
}


// ------------------------------------------------------------------------------------------
static double daysToSeconds(long d)
{
	return (double)(d - 1) * 24.0 * 60.0 * 60.0;
}


// ------------------------------------------------------------------------------------------
static double hoursToSeconds(long h)
{
	return (double)h * 60.0 * 60.0;
}

// ------------------------------------------------------------------------------------------
static double minutesToSeconds(long m)
{
	return (double)m * 60;
}

// ------------------------------------------------------------------------------------------
static long secondsToMin(double *s)
{
	double hold;
	
	hold = *s / 60.0;
	modf(hold,&hold);
	
	*s = *s - (hold * 60);
	return (int)hold;
}

// ------------------------------------------------------------------------------------------
static long secondsToHours(double *s)
{
	double hold;
	
	hold = *s / (60.0 * 60.0);
	modf(hold,&hold);
	
	*s = *s - (hold * (60.0 * 60.0));
	return (int)hold;
}

// ------------------------------------------------------------------------------------------
static long secondsToDays(double *s)
{
	double hold;
	
	hold = *s / (24.0 * 60.0 * 60.0);
	modf(hold,&hold);
	
	*s = *s - (hold * (24.0 * 60.0 * 60.0));
	hold = hold + 1;
	return (int)hold;
}

// ------------------------------------------------------------------------------------------
static long secondsToMonth(double *s, int isLeapYear)
{
	long hold = 0;
	double holddouble;
	
	holddouble = *s / (24.0 * 60.0 * 60.0);
	modf(holddouble,&holddouble);
	
	hold = (int)holddouble;
	
	// Jan
	if (hold < 31.0) 
	{
		return 1;
	}
	
	// Feb
	if (hold < (59 + isLeapYear)) 
	{
		*s = *s - (31.0  * (24.0 * 60.0 * 60.0));
		return 2;
	}
	
	// Mar
	if (hold < (90 + isLeapYear)) 
	{
		*s = *s - ((59.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 3;
	}
	// Apr
	if (hold < (120 + isLeapYear)) 
	{
		*s = *s - ((90.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 4;
	}
	// May
	if (hold < (151 + isLeapYear)) 
	{
		*s = *s - ((120.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 5;
	}
	// June
	if (hold < (181 + isLeapYear)) 
	{
		*s = *s - ((151.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 6;
	}
	// July
	if (hold < (212 + isLeapYear)) 
	{
		*s = *s - ((181.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 7;
	}
	
	// Aug
	if (hold < (243 + isLeapYear)) 
	{
		*s = *s - ((212.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 8;
	}
	
	// Sept
	if (hold < (273 + isLeapYear)) 
	{
		*s = *s - ((243.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 9;
	}
	
	// Oct
	if (hold < (304 + isLeapYear)) 
	{
		*s = *s - ((273.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 10;
	}
	
	// Nov
	if (hold < (334 + isLeapYear)) 
	{
		*s = *s - ((304.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 11;
	}
	
	// Dec
	if (hold < (365 + isLeapYear)) 
	{
		*s = *s - ((334.0 + isLeapYear) * (24.0 * 60.0 * 60.0));
		return 12;
	}
	
	return 0;
}

// ------------------------------------------------------------------------------------------
static long secondsToYear(double *s)
{
	long year;
	double days;
	
	double leapcenturies = 0.0;
	double centuries = 0.0;
	double leapyears = 0.0;
	double years = 0.0;
	double leapdays = 0.0;
	
	days = *s / (24.0 * 60.0 * 60.0);
	modf(days,&days);
	
	// (days + (leapdays * 366))

	if (*s < 0.0) 
	{
		leapdays = -1.0;
		days = days + 1;
		
		if (days != 0.0) 
		{
			leapcenturies = days / ((((100 * 365) + 24) * 4) + 1);
			modf(leapcenturies,&leapcenturies);
			days = days - leapcenturies * ((((100 * 365) + 24) * 4) + 1);
		}
		
		if (days != 0.0) 
		{
			centuries = days / ((100 * 365) + 24);
			modf(centuries,&centuries);
			days = days - centuries * ((100 * 365) + 24);
		}
		
		if (days != 0.0) 
		{
			leapyears = days / ((4 * 365) + 1);
			modf(leapyears,&leapyears);
			days = days - leapyears * ((4 * 365) + 1);
		}
		
		if (days != 0.0) 
		{
			years = days / 365.0;
			modf(years,&years);
			days = days - (years * 365.0);
		}
		years = years - 1;
		
		year = 2001 + (leapcenturies * 400) + (centuries * 100) + (leapyears * 4) + years;

	} 
	else 
	{
		if (days != 0.0) 
		{
			leapcenturies = days / ((((100 * 365) + 24) * 4) + 1);
			modf(leapcenturies,&leapcenturies);
			days = days - leapcenturies * ((((100 * 365) + 24) * 4) + 1);
		}
		
		if (days != 0.0) 
		{
			centuries = days / ((100 * 365) + 24);
			modf(centuries,&centuries);
			days = days - centuries * ((100 * 365) + 24);
		}
		
		if (days != 0.0) 
		{
			leapyears = days / ((4 * 365) + 1);
			modf(leapyears,&leapyears);
			days = days - leapyears * ((4 * 365) + 1);
		}
		
		if (days != 0.0) 
		{
			years = days / 365.0;
			modf(years,&years);
			days = days - (years * 365.0);
		}

		year = 2001 + (leapcenturies * 400) + (centuries * 100) + (leapyears * 4) + years;
		
		if ((year != 2001) && isLeapYear(year - 1) && days == 0.0) 
		{
			if (years == 4)
				year = year - 1;
			if (centuries == 4)
				year = year - 1;
		}
	}
		
	
	//if (year > 2001 && (isLeapYear(year -1))) {
	//	year = year - 1;
	//}
	
	*s = *s - yearToseconds(year);
	
	return year;
}


// ------------------------------------------------------------------------------------------
char *OB_formatDate(double datevalue, char *buffer)
{
// the date time value given is GMT based ...
	double localdatevalue = datevalue ; 
	long year;
	long month;
	long day;
	long hour;
	long minutes;
	long second;
	long daylight_savings_flag = 0;

	year = secondsToYear(&localdatevalue);
	month = secondsToMonth(&localdatevalue, isLeapYear(year));
	day = secondsToDays(&localdatevalue);
	hour = secondsToHours(&localdatevalue);
	minutes = secondsToMin(&localdatevalue);
	second = localdatevalue;

	// split the date up into it's components (STILL GMT relative)
	// and see if the time zone we are in was in DST for this time
	daylight_savings_flag = isDSTInEffectOnDate( year, month, day, hour, minutes, second ) ;

	// if so we adjust the time by the appropriate gmt offset (which we calculated before)
	if (daylight_savings_flag)
	{
		localdatevalue = datevalue + gmtoffset_DST ;
	}
	else
	{
		localdatevalue = datevalue + gmtoffset;
	}

	// and split the time up to be timezone relative	
	year = secondsToYear(&localdatevalue);
	month = secondsToMonth(&localdatevalue, isLeapYear(year));
	day = secondsToDays(&localdatevalue);
	hour = secondsToHours(&localdatevalue);
	minutes = secondsToMin(&localdatevalue);
	second = localdatevalue;

	// and format it appropriately
	if (daylight_savings_flag)
	{
		sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d %s", year, month, day, hour, minutes, second, gmtstring_DST);
	} 
	else 
	{
		sprintf(buffer, "%04d-%02d-%02d %02d:%02d:%02d %s", year, month, day, hour, minutes, second, gmtstring);
	}

	return buffer;
}

// ------------------------------------------------------------------------------------------
double dateToFloat(char *buffer)
{
	long year = 2001;
	long month = 1;
	long day = 1;
	long hour = 12;
	long minutes = 0;
	long second = 0;
	long gmtadjust = gmtoffset;
	long len;
	
	len = strlen(buffer);
	
	year = atoi(buffer);
	if (len > 5) 
	{
		month = atoi(&buffer[5]);
	}
	if (len > 8) 
	{
		day = atoi(&buffer[8]);
	}
	if (len > 11) 
	{
		hour = atoi(&buffer[11]);
	}
	if (len > 14) 
	{
		minutes = atoi(&buffer[14]);
	}
	if (len > 17) 
	{
		second = atoi(&buffer[17]);
	}
	if (len > 20) 
	{
		long gmt_hours;
		long gmt_minutes;
		
		gmtadjust = atoi(&buffer[20]);
		
		gmt_hours = gmtadjust / 100;
		gmt_minutes = gmtadjust - (gmt_hours * 100);
		
		gmtadjust = (gmt_hours * 3600) + (gmt_minutes * 60);
	} 
	else 
	{
		// find out what the GMT is for this time and set it.
		struct tm time_str;
		
		time_str.tm_year = (year - 1900);
		time_str.tm_mon = (month - 1);
		time_str.tm_mday = day;
		time_str.tm_hour = hour;
		time_str.tm_min = minutes;
		time_str.tm_sec = second;
		time_str.tm_isdst = -1;
		mktime(&time_str);
		if ((time_str.tm_isdst == 1) && (hour > 0)) {
			gmtadjust = (gmtoffset_DST * 60);
		} else {
			gmtadjust = (gmtoffset * 60);
		}
	}
	
	return (yearToseconds(year) + monthToSeconds(month, isLeapYear(year)) +
		daysToSeconds(day) + hoursToSeconds(hour) + minutesToSeconds(minutes) +
		second - gmtadjust);
}

