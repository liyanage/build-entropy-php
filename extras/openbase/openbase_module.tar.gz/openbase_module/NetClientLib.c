/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include "CommAPI.h"
#include "NetClientLib.h"

#include "API_Header.h"

#ifdef RHAPSODY
#include <libc.h>
#include <netdb.h>
#include <netinet/in_systm.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
//#include <netinet/tcp.h>
#include <sys/socket.h>
#endif

#ifdef macintosh
#include "GUSI.h"
#include "TFileSpec.h"
#include "TFileGlob.h"
#include <netdb.h>
#include <netinet/in.h>
#include <sys/socket.h>
#endif

#ifdef WINNT
#include <System/winsock.h>
#include <io.h>
#endif

#ifdef RHAPSODY
#include <unistd.h>
#endif

#define _UNIX_ 1


int netConnect(int port, const char *hostName)
{
        int    ret;
        //struct hostent *hostEntP;
        struct sockaddr_in sockAddr;
        //unsigned long ulAddr;
        int newsock;
#ifndef _UNIX_
        struct linger slinger;
        unsigned int keepa;
        unsigned int nodelay;
        int status;
        //WSADATA WSAData;
#endif
#ifdef _USE_UNIX_DOMAIN_
        struct sockaddr sockAddr;
#endif


#ifdef macintosh
	GUSISetup(GUSIwithInternetSockets);
#endif

#ifndef _UNIX_
        status = WSAStartup(MAKEWORD(1,1), &WSAData);
        if (status != 0)
            return -1;
        if (HIBYTE(WSAData.wVersion) != 1 || LOBYTE(WSAData.wVersion) != 1) {
            return -1;
        }
#ifndef WIN32
        //WSASetBlockingHook(BlockFunc);
#endif
#endif

/*
#ifdef macintosh
        ulAddr = inet_addr((char*)hostName).s_addr;
#else
        ulAddr = inet_addr((char*)hostName);
#endif
        if (ulAddr != ((unsigned long)-1)) {
            hostEntP = gethostbyaddr((char*)&ulAddr, 4, AF_INET);
        } else {
            hostEntP = gethostbyname((char*)hostName);
            //printf("IPADDRESS = %s\n",hostEntP->h_name);
            //printf("ALIASES = %s\n",*(hostEntP->h_aliases));
            //printf("ADDR_LIST = %s\n",inet_ntoa(*(hostEntP->h_addr_list)));
        }
        if (!hostEntP) {
                //WSACleanup();
                return -1;
        }
*/

        memset((struct sockaddr*) &sockAddr, 0, sizeof(sockAddr));
        sockAddr.sin_family = AF_INET;
        sockAddr.sin_port = htons(port);
        sockAddr.sin_addr.s_addr = inet_addr(hostName);
        if (sockAddr.sin_addr.s_addr == INADDR_NONE) {
            struct hostent *hostEntP;
#if defined(WINNT) | defined(SUNOS)
            hostEntP = gethostbyname(hostName);
#else
            hostEntP = gethostbyname2(hostName, AF_INET);
#endif
            if (!hostEntP) {
				return -1;
            }
            memcpy(&sockAddr.sin_addr, hostEntP->h_addr, hostEntP->h_length);
        }

		newsock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
#ifdef CLOSE_FD_ON_EXEC
        fcntl(newsock, F_SETFD, 1); //test
#endif    
        if (newsock == -1) {
                //WSACleanup();
                return -1;
        }


        ret = connect(newsock, (struct sockaddr*) &sockAddr, sizeof(sockAddr));
        if (ret == -1) {
            OBSocketClose(newsock);
                //close(newsock);
                //WSACleanup();
                return -1;
        }

        /* Set socket options */
#ifndef _UNIX_
/*        nodelay = TRUE;
        setsockopt(newsock, IPPROTO_TCP, TCP_NODELAY, (char*)&nodelay, sizeof(nodelay));
        keepa = TRUE;
        setsockopt(newsock, SOL_SOCKET, SO_KEEPALIVE, (char*)&keepa, sizeof(keepa));
        slinger.l_onoff = 0;
        slinger.l_linger = 0;   
        setsockopt(newsock, SOL_SOCKET, SO_LINGER, (char*)&slinger, sizeof(slinger));*/
#endif

        return newsock;
}

/***************************************************************************/
int copyAndFixString(unsigned char **tostring, int *tosize, int position, const unsigned char *str, int length, unsigned char *codedmap)
{
    char *strdest;

    // make sure the string is long enough
    if ((length + position) > (*tosize - 10)) {
        *tosize = *tosize * 2;
        // if doubling size isn't enough
        if ((length + position) > (*tosize - 10)) {
            *tosize = (length + position + 10);
        }
        *tostring = (unsigned char *)realloc(*tostring, *tosize);
    }

    strdest = (char *)*tostring + position;

    // copy the size of the string to the buffer
    ob_intToBytes((unsigned char *)strdest, length);
    strdest = strdest + sizeof(int);

    // copy the string itself to the buffer
    if (!codedmap) {
        memcpy(strdest, str, length);
    } else { // encode during copy
        int ct;

        for (ct=0; ct != length; ct++) {
            strdest[ct] = codedmap[(unsigned int)str[ct]];
        }
    }
    strdest[length] = '\0';
    //printf("SEND TOKEN(%d) = %s\n", length, strdest);
    return (length + sizeof(int));
}

void netClose(unsigned int socket)
{
    OBSocketClose(socket); //close(socket);
}


int netSndRaw(unsigned char *rawdata, size_t len, int socket)

/* Sends out the NetConnection's filled marshall buffer through the */
/* NetConnection's socket.   Returns an ISAM error code. */

{
    int ret;

#ifdef COMM_PRINT
    printf("SOCKET %d SEND ==================\n",socket);
    printBuffer((char *)rawdata,len);
#endif
    // send the data
    ret = OBSocketWrite(socket, rawdata, len);
    //ret = write(socket, rawdata, len);
    if ((ret == -1) || (ret != len))
            return 0;

    return 1;
}



/***************************************************************************/

long netRcvToken(unsigned char **buffer, int *bufsize, int socket, unsigned char *decodemap)

/* Waits for data on the NetConnection's socket. */
/* Returns an ISAM error code, and if no error the marshall buffer is */
/* full with the received data */
{
    int cc;
    int tokenLength = 0;

    if (OBSocketRead(socket, *buffer, sizeof(int)) != sizeof(int)) {
        printf("OBSocketRead FAILED (1)\n");
        return -1L;
    }

    ob_bytesToInt(&tokenLength, *buffer);

    //memcpy(&tokenLength, *buffer, sizeof(int));
    if (tokenLength == -1) {
        return -2L; // end of token stream
    }

    // reallocate buffer if it needs expanding
    if (tokenLength > (*bufsize-10)) {
        *bufsize = *bufsize * 2;
        if (tokenLength > (*bufsize-10)) {
            *bufsize = tokenLength + 10;
        }
        *buffer = (unsigned char *)realloc(*buffer, *bufsize);
    }

    // read token block
    if ((cc = OBSocketRead(socket, *buffer, tokenLength)) != tokenLength) {
        printf("OBSocketRead FAILED (2) %d but supposed to be %d\n", cc, tokenLength);
        return -1L;
    }
    *(char *)(*buffer + cc) = '\0';

    // decode result
    if (decodemap) {
        for (cc = 0; cc != tokenLength; cc++) {
            *(unsigned char *)(*buffer+cc) = decodemap[*(unsigned char *)(*buffer+cc)];
        }
        //printf("RECEIVED = %s\n", *buffer);
    }

    return tokenLength;
}


int ob_socketread(int socketFD, unsigned char *buffer, size_t byteCount)
{
    int ct = 0, ret = 0;;
    while (ct < byteCount) {
        ret = recv(socketFD, &buffer[ct], (byteCount - ct), 0);
        if (ret <= 0) {
            break;
        }
        ct = ct + ret;
    }
    return ct;
}

void ob_intToBytes(unsigned char *buffer, int number)
{
#ifdef SWAPINDIAN
    unsigned char *i;

    i = (unsigned char *)&number;
    buffer[0] = i[3];
    buffer[1] = i[2];
    buffer[2] = i[1];
    buffer[3] = i[0];
#else
    memcpy(buffer, &number, sizeof(int));
#endif
}


void ob_bytesToInt(int *number, unsigned char *buffer)
{
#ifdef SWAPINDIAN
    unsigned char *i;
    i = (unsigned char *)number;
    i[0] = buffer[3];
    i[1] = buffer[2];
    i[2] = buffer[1];
    i[3] = buffer[0];
#else
    memcpy(number, buffer, sizeof(int));
#endif
    //if (DEBUG_PRINT) printf("%d received\n", *number);
}

