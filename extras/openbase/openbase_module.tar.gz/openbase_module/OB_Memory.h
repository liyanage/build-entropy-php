// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
#include "platform.h"

#ifndef _OB_MEMORY_H
#define	_OB_MEMORY_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef MACOSX_UNIX
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef MACOSX_CARBON 
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef MACOSX_CLASSIC
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef WINNT

	#if 0
		#define ob_malloc(x)		HeapAlloc(GetProcessHeap(), 0, x)
		#define ob_calloc(s, x)		HeapAlloc(GetProcessHeap(), 0, s * x)
		#define ob_realloc(m, x)	HeapReAlloc(GetProcessHeap(), 0, m, x)
		#define ob_free(x)			HeapFree(GetProcessHeap(), 0, x)
	#elif 0
		#define ob_malloc(x)		GlobalAlloc(0, x)
		#define ob_calloc(s, x)		GlobalAlloc(0, s * x)
		#define ob_realloc(m, x)	GlobalReAlloc(m, x, 0)
		#define ob_free(x)			GlobalFree(x)
	#else
		#define ob_malloc(x)		malloc(x)
		#define ob_calloc(s, x)		calloc(s, x)
		#define ob_realloc(m, x)	realloc(m, x)
		#define ob_free(x)			free(x)
	#endif
	
#endif

#ifdef LINUX
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef SOLARIS
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef RHAPSODY
	#define	ob_malloc(x)		malloc(x)
	#define	ob_calloc(s, x)		calloc(s, x)
	#define	ob_realloc(m, x)	realloc(m, x)
	#define	ob_free(x)			free(x)
#endif

#ifdef __cplusplus
}
#endif

#endif