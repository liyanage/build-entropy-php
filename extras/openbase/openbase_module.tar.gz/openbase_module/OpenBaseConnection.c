// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
//
// [jsh] 11/07/2003 
//		Added missing prototypes.
// 		Factored ob_newNetConn function out of ob_newConnection.
//		Moved ob_releaseBuffers and releasConnBuffers here from OT_NetClient.cpp,
//			replacing redundant code in ob_newConnection.
//		Added const keyword to bind functions.
//		Replaced pointer typedefs.
//		Other miscellaneous changes.
//		Limited the number of attempts at autoreconnection.
//		Added date and time formatting preferences.
//
// ----------------------------------------------------------------------------
#include "platform.h"

#include "OpenBaseConnection.h"
#include "OpenBaseEncoding.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef MACOS_CARBON
#include <Processes.h>
#include <Threads.h>
#include "MacCarbon_NetClient.h"
#endif

#ifdef WINNT
#include "AllOthers_NetClient.h"
#endif
#ifdef LINUX
#include "AllOthers_NetClient.h"
#endif


#ifndef _OB_MEMORY_H
#include "OB_Memory.h"
#endif

#include "longlong.h"
#include "OpenBaseSupport.h"
#include "OpenBasePrepare.h"

#include "CommAPI.h"
#include "conversion.h"

// ----------------------------------------------------------------------------

#define YIELD_THREAD 	/*YieldToAnyThread()*/
#define OB_DEALLOC(ptr)    if (ptr) { free(ptr); ptr = NULL; }

//[jsh] 11/07/2003 New. Replaced some magic numbers.
#define DICTIONARY_BUFFER_SIZE 500
#define SQL_BUFFER_SIZE 500

void _setErrorMessage(OpenBasePtr conn, int errorCode);			// ��dmr
void _initEncoding(OpenBasePtr conn);
int _ob_connectToDatabase(OpenBasePtr conn, char *databaseName, char *databaseHost, int *returnCode, int secondaryConnectionFlag);	//[jsh] 11/07/2003
int _ob_executeCommand(OpenBasePtr conn);	//[jsh] 11/07/2003
static void releasConnBuffers(NetConnPtr conn);	//[jsh] 11/07/2003

// -----------------------------------------------------------------------------
// date and time formatting used in ob_nextCursorRow
// -----------------------------------------------------------------------------

static int dateFormatType = dateFormat_D_dot_M_dot_YYYY;
static int timeFormatType = timeFormat_0H_colon_0M;

int getDateFormatType()
{
    return dateFormatType;
}

void setDateFormatType(int dateFormat)
{
    dateFormatType = dateFormat;
}

int getTimeFormatType()
{
    return timeFormatType;
}

void setTimeFormatType(int timeFormat)
{
    timeFormatType = timeFormat;
}


// -----------------------------------------------------------------------------
// encoding conversion
// -----------------------------------------------------------------------------
int convertStringToDatabaseEncoding(OpenBasePtr conn, const char *source, char *target)
{
    unsigned char *result = NULL;
    int len = strlen(source);
    
    if (conn->clientEncoding == 0) {
        strcpy(target, source);
        return strlen(target);
    }
    
    result = (unsigned char *)ob_convertCharacters(conn->clientEncoding, conn->databaseEncoding, (const unsigned char *)source, &len);
    strncpy(target, (char *)result, len);
    free(result);
    target[len] = '\0';
    return len;
}

int convertStringFromDatabaseEncoding(OpenBasePtr conn, const char *source, char *target)
{
    unsigned char *result = NULL;
    int len = strlen(source);
    
    if (conn->clientEncoding == 0) {
        strcpy(target, source);
        return strlen(target);
    } 
    result = (unsigned char *)ob_convertCharacters(conn->databaseEncoding, conn->clientEncoding, (const unsigned char *)source, &len);
    strncpy(target, (char *)result, len);
    free(result);
    target[len] = '\0';
    return len;
}

int convertStringToDatabaseEncodingLength(OpenBasePtr conn, const char *source, char *target, int len)
{
    unsigned char *result = NULL;

    if (conn->clientEncoding == 0) {
        strncpy(target, source, len);
        target[len] = '\0';
        return len;
    }
    
    result = (unsigned char *)ob_convertCharacters(conn->clientEncoding, conn->databaseEncoding, (const unsigned char *)source, &len);
    strcpy(target, (char *)result);
    free(result);
    return len;
}


int convertStringFromDatabaseEncodingLength(OpenBasePtr conn, const char *source, char *target, int len)
{
    unsigned char *result = NULL;

    if (conn->clientEncoding == 0) {
        strncpy(target, source, len);
        target[len] = '\0';
        return len;
    }
    
    result = (unsigned char *)ob_convertCharacters(conn->databaseEncoding, conn->clientEncoding, (const unsigned char *)source, &len);
    strncpy(target, (char *)result, len);
    free(result);
    target[len] = '\0';
    return len;
}

int ob_databaseEncoding(OpenBasePtr conn)
{
    return conn->databaseEncoding;
}

int ob_clientEncoding(OpenBasePtr conn)
{
    return conn->clientEncoding;
}

void ob_setClientEncoding(OpenBasePtr conn, int encoding)
{
    conn->clientEncoding = encoding;
}


void _initEncoding(OpenBasePtr conn)
{
	int len;
	char* result;

	conn->databaseEncoding = OB_ENCODING_ASCII;

    prepareDictionary (conn->connection);
    addDictionaryPair (conn->connection, "action", "call_getencoding");
	if (sendBuffer (conn->connection) == 0)
	{
		return;
	}
	YIELD_THREAD;
	if (readResult (conn->connection) == 0)
	{
		return;
	}

    result = resultValueForKey (conn->connection, "encoding", &len);

	if (result != NULL)
	{
		if (strcmp(result,"NSISOLatin1StringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_LATIN1;
		} else if (strcmp(result,"NSISOLatin2StringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_LATIN2;
		} else if (strcmp(result,"NSNEXTSTEPStringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_ASCII;
		} else if (strcmp(result,"NSISO2022JPStringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_ISO2022JP;
		} else if (strcmp(result,"NSJapaneseEUCStringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_EUC;
		} else if (strcmp(result,"NSShiftJISStringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_SHIFTJIS;
		} else if (strcmp(result,"NSUTF8StringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_UTF8;
		} else if (strcmp(result,"NSNonLossyASCIIStringEncoding") == 0) {
			conn->databaseEncoding = OB_ENCODING_UNICODE;
		}
	}

    return;
}

//Allocates memory for a page of result data for an OpenBaseCursor. The page does
//not initially contain any data, which is ultimately stored in resultData.
//resultData may be filled with a data block that is owned by the cursor, in which case
//the resultDataNeedsDealloc flag is set to 1. Or a data block owned by the parent
//OpenBase connection may be held in resultData. In particular, resultData will
//normally hold an element of the resultKeys array. In this case, resultDataNeedsDealloc
//remains 0.
//OpenBaseResultData is implemented as a linked list, as indicated by the next attribute.
//Because of these features, it is necessary to call ob_deallocResultDataList to dispose
//of an OpenBaseResultData allocation. This is all taken care of by higher level functions.
OpenBaseResultDataPtr ob_newResultData()
{
    OpenBaseResultDataPtr resultData;
    
    resultData = (OpenBaseResultDataPtr)ob_malloc(sizeof(OpenBaseResultData));
    resultData->resultData = NULL;
    resultData->resultDataLength = 0;
    resultData->next = NULL;
    resultData->resultDataNeedsDealloc = 0;
    return resultData;
}

//Allocates memory for an OpenBaseCursor. It includes one empty result page by default. 
//Normally, a cursor does not own the data fetched from the server and disposing of the 
//cursor will be taken care of by ob_deallocConnection. However, a call to 
//ob_retrieveCursor will pull all result pages into memory owned by the cursor. At that 
//point, the cursor can still be used to step through the result rows, even after the 
//connection is disposed of. The application must take responsiblity for disposing of 
//the cursor by calling ob_deallocCursor. Note that in either case, you may only step 
//forward through a cursor and only once.
OpenBaseCursorPtr ob_newResult()
{
    OpenBaseCursorPtr resultset;
    
    resultset = (OpenBaseCursorPtr)ob_malloc(sizeof(OpenBaseCursor));
    
    resultset->readMoreResult = 0;
    resultset->readPosition = 0;
    resultset->columnsReturned = 0;
    resultset->maxVariablesBound = 0;
    resultset->maxInitializedTables = 0;
    resultset->maxInitializedColumns = 0;
    /*for (ct=0; ct < 400 ;ct++) {
        resultset->tableNames[ct] = NULL;
        resultset->columnNames[ct] = NULL;
    }*/
    resultset->skipConvert = 0;
    resultset->resultPage = ob_newResultData();
    resultset->pushedResult = NULL;
    return resultset;
}


//[jsh] 11/07/2003. Factored out of ob_newConnection().
//This is more or less a private method for ob_newConnection, which requires the 
//construction of two NetConn data blocks. There is no corresponding disposal method.
//That is taken care of by ob_deallocConnection.
NetConnPtr ob_newNetConn()
{
    NetConnPtr netConnection;
    
    netConnection = (NetConnPtr)ob_malloc(sizeof(NetConn));
	//[jsh] 11/07/2003. Redundant; see dmr below
    //conn->connection->socketConnection = (TEndpoint*)(-1);
    netConnection->didInit = 0;
    netConnection->dictionaryBuffer = (unsigned char*)ob_malloc(DICTIONARY_BUFFER_SIZE);
    netConnection->dictionaryBufferSize = DICTIONARY_BUFFER_SIZE;
    netConnection->readPosition = 0;
    netConnection->socketConnection = 0;		// ��dmr
    netConnection->privateEncriptionMap = NULL;
    netConnection->privateDecriptionMap = NULL;
    netConnection->clientAddress[0] = 0;
    netConnection->serverAddress[0] = 0;
    return netConnection;
}

void ob_deallocNetConn(NetConnPtr conn)
{
	if (conn->dictionaryBuffer) ob_free(conn->dictionaryBuffer);
	if (conn->privateEncriptionMap) ob_free(conn->privateEncriptionMap);
	if (conn->privateDecriptionMap) ob_free(conn->privateDecriptionMap);
	ob_free(conn);
}


// ----------------------------------------------------------------------------
//Allocates memory for an OpenBase connection. The connection is not actually 
//made. (See ob_connectToDatabase) Rather, the OpenBase data block is initialized 
//in preparation for a connection. This memory must be released by the application 
//with a call to ob_deallocConnection.
#ifdef MACOS_CARBON
	#ifdef TARGET_API_MAC_CARBON
		OpenBasePtr ob_newConnection(OTClientContextPtr newClientContext)
	#else
		OpenBasePtr ob_newConnection(void)
	#endif	
#else
	OpenBasePtr ob_newConnection(void) 
#endif
{
    OpenBasePtr conn = NULL;

	#ifdef MACOS_CARBON
	    static bool initialized = false;
	#endif

    int ct = 0;
    
    conn = (OpenBasePtr)ob_malloc(sizeof(OpenBase));
    
    conn->connection = ob_newNetConn();		//[jsh] 11/07/2003
    conn->altConnection = ob_newNetConn();	//[jsh] 11/07/2003

    conn->invalidate = 0;
    conn->autoReconnectFlag = 1;
    conn->transactionInProgress = 0;

	#ifdef MACOS_CARBON
		#ifdef TARGET_API_MAC_CARBON
			conn->outClientContext = newClientContext;
		    conn->connection->outClientContext = conn->outClientContext;
		    conn->altConnection->outClientContext = conn->outClientContext;
		#else
		    if(!initialized)
		    {
			    initialized = true;
				InitOpenTransport();
			}
		#endif
	#endif

    conn->sqlBuffer = (char*)ob_malloc(SQL_BUFFER_SIZE);	//[jsh] 11/07/2003
    conn->sqlBufferSize = SQL_BUFFER_SIZE;	//[jsh] 11/07/2003

	conn->databaseEncoding = OB_ENCODING_ASCII;
	conn->clientEncoding = OB_ENCODING_MACOS_ROMAN;
	
    conn->position = 0;
    
    for (ct=0; ct < OB_MAX_COLUMNS ;ct++) {
        conn->preparedSQL[ct] = NULL;
    }

	//[jsh] 11/07/2003. Redundant. Initialized in the loop above.
    //conn->preparedSQL[0] = NULL;
    
    conn->resultset = ob_newResult();
        
    conn->resultset->errorMessage = NULL;		// ��dmr	��� LD 9/4/2001 - Add 'resultSet'
    
    conn->secondaryHost[0] = '\0';
    conn->secondaryDatabase[0] = '\0';
    strcpy(conn->softwareId,"C-API");
    strcpy(conn->clientName,"C-API");

    clearComm(conn->connection);	// ��dmr
    clearComm(conn->altConnection);	// ��dmr

    return conn;
}


extern int out ( const char* );


// ----------------------------------------------------------------------------
//This function is the high level mechanism for properly disposing of an 
//OpenBase connection. It will ensure that the connection is closed and then 
//dispose of all memory associated with it, including the current cursor.
void ob_deallocConnection(OpenBasePtr conn)
{
	if(conn)
	{
		/*
		char s[100];
		sprintf ( s, "ob_deallocConnection 0x%x", conn );
		out ( s );
		*/
		
		ob_invalidate(conn);
		ob_releaseBuffers(conn); //[jsh] 11/07/2003

    	ob_deallocCursor(conn->resultset);
    	conn->resultset = NULL;
		ob_free(conn);
	}
}

// ----------------------------------------------------------------------------
// [jsh] 11/07/2003
//		Moved this method and releasConnBuffers here from OT_NetClient.cpp
//		Made use of the DEALLOC macro.
//This function disposes of the non-cursor memory allocations associated with 
//an OpenBase connection, not including the OpenBase connection itself. It is 
//called by ob_deallocConnection.
void ob_releaseBuffers (OpenBasePtr conn) 
{	
	int ct = 0;
	
	if (conn->connection != NULL)
	{
		releasConnBuffers (conn->connection);

		ob_free (conn->connection);
		conn->connection = NULL;
	}

	if (conn->altConnection != NULL)
	{
		releasConnBuffers (conn->altConnection);

		ob_free (conn->altConnection);
		conn->altConnection = NULL;
	}

    OB_DEALLOC(conn->sqlBuffer);

    for (ct = 0; ct < OB_MAX_COLUMNS; ct++) {
    	OB_DEALLOC(conn->preparedSQL[ct]) ;
    }
	conn->numberOfPreparedValues = 0;
}


//Called by ob_releaseBuffers.
static void releasConnBuffers (NetConnPtr conn)
{
    int ct;
    for (ct=0; ct < OB_MAX_KEYS; ct++)
    {
    	OB_DEALLOC(conn->resultKeys[ct]) ;
    	OB_DEALLOC(conn->resultValues[ct]) ;
    }
    OB_DEALLOC(conn->dictionaryBuffer) ;
}

// ----------------------------------------------------------------------------
//Called by ob_deallocResultDataList.
void ob_deallocResultData(OpenBaseResultDataPtr resultData)
{
    
    if (!resultData) return;
    
    if (resultData->resultDataNeedsDealloc) {
        OB_DEALLOC(resultData->resultData);
    }
    ob_free(resultData);	//[jsh] 11/07/2003
}

// ----------------------------------------------------------------------------
//Disposes of the linked list result pages in a cursor.
void ob_deallocResultDataList(OpenBaseResultDataPtr resultData)
{
    
    if (!resultData) return;
    ob_deallocResultDataList(resultData->next);
    ob_deallocResultData(resultData);
}

// ----------------------------------------------------------------------------
//This function disposes of an OpenBaseCursor. It is normally called by various 
//functions that manage cursors, including ob_deallocConnection. It must be 
//called by the application to dispose of cursors returned via ob_retrieveCursor.
void ob_deallocCursor(OpenBaseCursorPtr cursor){
    int ct;
    
    if (!cursor) return;
    
    for (ct=0; ct < cursor->maxInitializedColumns ;ct++) {
        OB_DEALLOC(cursor->columnNames[ct]);
    }
    for (ct=0; ct < cursor->maxInitializedTables ;ct++) {
        OB_DEALLOC(cursor->tableNames[ct]);
    }
    ob_deallocResultDataList(cursor->resultPage);
    ob_free(cursor);	//[jsh] 11/07/2003
}


// ----------------------------------------------------------------------------
//This function closes the connection to the server. The OpenBase connection 
//remains in a state that allows the connection to be reopened via a call to 
//ob_connectToDatabase.
void ob_invalidate(OpenBasePtr conn)
{
	if(!conn->invalidate) {
		conn->invalidate = 1;
	    // SEND EXIT SIGNAL TO NOTIFY SERVER THAT CONNECTION IS CLOSING
	    sendExitSignal(conn->connection);
	    sendExitSignal(conn->altConnection);

	    // CLOSE THE CONNECTION TO THE SERVER
		if (conn->connection->socketConnection != 0)			// ��dmr
	    	netClose(conn->connection->socketConnection);

		if (conn->altConnection->socketConnection != 0)			// ��dmr
	    	netClose(conn->altConnection->socketConnection);

	    conn->connection->socketConnection = 0;
	    conn->altConnection->socketConnection = 0;

	    OB_DEALLOC(conn->connection->privateEncriptionMap);
	    OB_DEALLOC(conn->connection->privateDecriptionMap);
	    OB_DEALLOC(conn->altConnection->privateEncriptionMap);
	    OB_DEALLOC(conn->altConnection->privateDecriptionMap);
	}
}

// ----------------------------------------------------------------------------

int ob_beginTransaction(OpenBasePtr conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"START TRANSACTION");
    if (ob_executeCommand(conn)) {
    	conn->transactionInProgress = 1;
    	return 1;
    }
    return 0;
}

// ----------------------------------------------------------------------------

int ob_beginPassiveTransaction(OpenBasePtr conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"START PASSIVE TRANSACTION");
    if (ob_executeCommand(conn)) {
    	conn->transactionInProgress = 1;
    	return 1;
    }
    return 0;
}

// ----------------------------------------------------------------------------

int ob_isTransactionInProgress(OpenBasePtr conn)
{
    return conn->transactionInProgress;
}


// ----------------------------------------------------------------------------


// [jsh] 11/07/2003 Added const keyword to bind functions.
void ob_bindDouble(OpenBasePtr conn, const double *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='F';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;

}

// ----------------------------------------------------------------------------


void ob_bindInt(OpenBasePtr conn, const int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='I';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

// ----------------------------------------------------------------------------


void ob_bindLongLong(OpenBasePtr conn, const int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='Q';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

// ----------------------------------------------------------------------------


void ob_bindLong(OpenBasePtr conn, const long *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='L';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

// ----------------------------------------------------------------------------


void ob_bindString(OpenBasePtr conn, const char *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='C';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

// ----------------------------------------------------------------------------


void ob_bindBinary(OpenBasePtr conn, const char *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='B';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}
// ----------------------------------------------------------------------------

void ob_bindBoolean(OpenBasePtr conn, const int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='b';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

// ----------------------------------------------------------------------------



int ob_bufferHasCommands(OpenBasePtr conn)
{
    if (conn->position) return 1;
    return 0;
}

// ----------------------------------------------------------------------------


void ob_clearCommands(OpenBasePtr conn)
{
    conn->position = 0;
    return;
}

// ----------------------------------------------------------------------------


char *ob_commandBuffer(OpenBasePtr conn)
{
    return conn->sqlBuffer;
}

// ----------------------------------------------------------------------------


int ob_commitTransaction(OpenBasePtr conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"COMMIT");
    conn->transactionInProgress = 0;
    return ob_executeCommand(conn);
}

// ----------------------------------------------------------------------------


const char *ob_connectErrorMessage(OpenBasePtr conn )
{
    return conn->resultset->errorMessage;
}

// [jsh] 11/07/2003 Use default.
void _setErrorMessage(OpenBasePtr conn, int errorCode)
{
	switch(errorCode) {
	    case ERR_DBSUSRLIM: conn->resultset->errorMessage = "The user limit has been exceeded.  You may need to purchase additional licenses in order to connect to OpenBase. Your action has been aborted. "; break;
	    case ERR_NOSERVER: conn->resultset->errorMessage = "The database specified has not been started or can not be found. Your action has been aborted. "; break;
	    case ERR_INCORRECT_LOGIN: conn->resultset->errorMessage = "Your login and password are not valid for the specified database.  If no passwords have been set in the database you can use the 'root' user with no password."; break;
	    case ERR_WEBOBJECTS_VIOLATION: conn->resultset->errorMessage = "You need to purchase an internet license to use OpenBase with WebObjects.  Please contact OpenBase International at 603-547-8404 for more information. "; break;
	    case ERR_LITE_VIOLATION: conn->resultset->errorMessage = "OpenBase Lite is for single-user deployment only. It is not to be used with software development tools or WebObjects.  Please contact OpenBase at 603-547-8404 to purchase the appropriate license to work with these products.  Thank you."; break;
	    default: conn->resultset->errorMessage = "";
    }
}

// ----------------------------------------------------------------------------



int _ob_connectToDatabase(OpenBasePtr conn, char *databaseName, char *databaseHost, int *returnCode, int secondaryConnectionFlag )
{
    int len;
    char *values;
    char processIdString[50];
    static int counter = 0;
    #ifdef MACOS_CARBON
    	char buffer[128] ;
	#endif
	    
    if (databaseName[0] != '#') {
        
        if (!connectToPort(conn->connection, 20222, databaseHost)) 
        {
            _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
            //printf("\ntrying to connect to openexec failed\n"); //��dmr
            return 0;
        } 
        // setup block send
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "findPort", databaseName);
	    #ifdef MACOS_CARBON
	        addDictionaryPair(conn->connection, "portHost",  MapNameToAddress (databaseHost, buffer, conn->outClientContext));
	    #else
	        addDictionaryPair(conn->connection, "portHost",  databaseHost);
	    #endif    
        sendBuffer(conn->connection);
        YIELD_THREAD;
        if (!readResult(conn->connection)) {
            //printf("no result returned from nameserver\n");
            _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
            return 0;
        }
        if (!resultValueForKey(conn->connection, "portNumber", &len)) {
            //printf("could not find database\n");
            _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
            return 0;
        }
        // primary connection
    
        // FOR MAC SYSTEMS NAME RESOLUTION DOESN'T WORK
        //strcpy(conn->databaseHost, resultValueForKey(	conn->connection, 
                                                                                                    // "portHostAddress", &len));
        
        netClose(conn->connection->socketConnection);
        conn->connection->socketConnection = 0; // ��dmr
        
        conn->connection->connectionPort = 
            atoi(resultValueForKey(conn->connection, "portNumber", &len)); //��dmr
    } else {
        conn->connection->connectionPort = atoi(&databaseName[1]);
    }    
    if (!connectToPort(	conn->connection, 
    					conn->connection->connectionPort, 
    					databaseHost)) {
        printf("could not find database\n"); // ��dmr
        return 0;
    }


    // secondary connection (for blob transport)
    conn->altConnection->connectionPort = conn->connection->connectionPort;
    netClose(conn->altConnection->socketConnection);
    conn->altConnection->socketConnection = 0; // ��dmr

    if (!connectToPort(	conn->altConnection, conn->altConnection->connectionPort, databaseHost)) {
        //printf("could not find database\n"); ��dmr
        return 0;
    }

    // check to see if we can log on.
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_checkcanconnect");
    if (!sendBuffer(conn->connection)) {
        _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    
    YIELD_THREAD;

    if (!readResult(conn->connection)) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }

    if ((values = resultValueForKey(conn->connection, "result", &len)) != NULL) {
    	if (strcmp(values,"no") == 0) {
    		// reconnect to failover server
	        if ((conn->secondaryHost[0] == '\0') || (conn->secondaryDatabase[0] == '\0')) {
	            if ((values = resultValueForKey(conn->connection, "secondaryHost", &len)) != NULL) {
	                strcpy(conn->secondaryHost, values);
	                if ((values = resultValueForKey(conn->connection, "secondaryDatabase", &len)) != NULL) {
	                    strcpy(conn->secondaryDatabase, values);
	                }
	            }
	        }
	        
	        // now connect to the secondary server
			return _ob_connectToDatabase(conn, conn->secondaryDatabase, conn->secondaryHost, returnCode, 1);    	
		}
    }
        
    // setup encryption
    startPrivateTransmission(conn->connection);
    startPrivateTransmission(conn->altConnection);

    sprintf(processIdString,"%s_%d", conn->databaseLogin, counter++);
    
    
    // log into database
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_register");
    addDictionaryPair(conn->connection, "usersAllowed", "1000");
    addDictionaryPair(conn->connection, "dblogin", conn->databaseLogin);
    addDictionaryPair(conn->connection, "dbpassword", conn->databasePassword);
    addDictionaryPair(conn->connection, "userlogin", conn->databaseLogin);
    addDictionaryPair(conn->connection, "hostName", conn->databaseHost);
    addDictionaryPair(conn->connection, "databaseName", conn->databaseName);
    addDictionaryPair(conn->connection, "softwareId", conn->softwareId);
    addDictionaryPair(conn->connection, "processId", processIdString);
    if (!sendBuffer(conn->connection)) {
        _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    
    YIELD_THREAD;

    if (!readResult(conn->connection)) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }

    if ((values = resultValueForKey(conn->connection, "result", &len)) == NULL) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    if (strcmp(values,"succeed") != 0) {
	    if ((values = resultValueForKey(conn->connection, "error", &len)) != NULL) {
	    	_setErrorMessage(conn, atoi(values)); *returnCode = atoi(values);
    	} else {
    	    _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
    	}
        return 0;
    }
    
    if (secondaryConnectionFlag) {
        // tell the server that this is a secondary connection
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "call_alternateConnection");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
            return 0;
        }
        YIELD_THREAD;
        
        if (!readResult(conn->connection)) {
            _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
            return 0;
        }
        
    } else {
        // get the secondaryHost and secondaryDatabase
        if ((conn->secondaryHost[0] == '\0') || (conn->secondaryDatabase[0] == '\0')) {
            if ((values = resultValueForKey(conn->connection, "secondaryHost", &len)) != NULL) {
                strcpy(conn->secondaryHost, values);
                if ((values = resultValueForKey(conn->connection, "secondaryDatabase", &len)) != NULL) {
                    strcpy(conn->secondaryDatabase, values);
                }
            }
        }
    }
    
    // setup max buffer size
    // ��� WAS COMMENTED OUT !!!
#ifdef MACOS_CARBON    
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "setMaxBufferSize");
    addDictionaryPair(conn->connection, "size", "20000");
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    // ��� END OF WAS COMMENTED OUT SECTION

    YIELD_THREAD;
    
    if (!readResult(conn->connection)) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
#endif    

    conn->tmp[0] = 0;							// ��dmr
    (void)_initEncoding(conn);		// ��dmr

    *returnCode = 0;	//[jsh] 11/07/2003
    return 1;
}

int ob_checkConnectionToDatabase(OpenBasePtr conn, const char *dbHostName){
    strcpy(conn->databaseHost, dbHostName);
    if (!connectToPort(conn->connection, 20222, conn->databaseHost)){
        return 0;
    }
    return 1;
}

//Open a connection to the server. softwareId and clientName are identifiers that 
//appear in various server side log files.
int ob_connectToDatabase(OpenBasePtr conn, const char *dbName, const char *dbHostName, 
						 const char *loginName, const char *passwordString, 
						 const char* softwareId, const char* clientName, int *returnCode )
{
    // copy in login information
    strcpy(conn->databaseName, dbName);
    strcpy(conn->databaseHost, dbHostName);
    strcpy(conn->databaseLogin, loginName);
    strcpy(conn->databasePassword, passwordString);
    strcpy(conn->softwareId, softwareId);
    strcpy(conn->clientName, clientName);
    
    return _ob_connectToDatabase(conn, conn->databaseName, conn->databaseHost, returnCode, 0);
}

// ----------------------------------------------------------------------------

char *ob_databaseName(OpenBasePtr conn)
{
    return conn->databaseName;
}

// ----------------------------------------------------------------------------

int ob_abortFetch(OpenBasePtr conn)
{
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "abort");
    
    // send the command to the server
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }
    YIELD_THREAD;
    if (readResult(conn->connection) == 0) return 0; // failure
    
    return 1;
}


//This function sends SQL to the server for execution, setting the resultSet as warranted. There are three possible return values.
//	 1 success
//	-1 server connection failure
//	 0 other errors returned by the server, stored in errorMessage
int _ob_executeCommand(OpenBasePtr conn)
{
    int len;
    char *values;
    int ct;
    	
    if (conn->connection == NULL) {
        return 0;
    }

    // check to see if we need to abort the fetch
    if (conn->resultset->readMoreResult) {
        // send abort
        ob_abortFetch(conn);
        conn->resultset->readMoreResult = 0;
    }
    
    conn->insertedRowidValue[0] = '\0';
    conn->position = 0; // restart sql buffer
    conn->resultset->columnsReturned = 0; 
    conn->resultset->rowsAffected = 0;
    conn->resultset->maxVariablesBound = 0;
    conn->resultset->readPosition = 0;

    //printf("ob_executeCommand SQL BUFFER <%s>\n", conn->sqlBuffer);
    
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_executeSQL");
    addDictionaryPair(conn->connection, "SQLCommand", conn->sqlBuffer);

    // send the command to the server
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return -1;
    }
    YIELD_THREAD;

    if (!conn->connection || (readResult(conn->connection) <= 0)) return -1; // failure

    conn->resultset->errorMessage = resultValueForKey(conn->connection, "error", &len);
    if (conn->resultset->errorMessage) {
        // there was an error
        return 0;
    }
    
    //[jsh] 11/07/2003 Once upon a time, there was an OpenBase bug that caused the number of table
    //names to sometimes be less than the number of column names, so I changed this code to set
    //columnsReturned based on the number of columns (titles), rather than the number of tables.
    //This change is probably no longer necessary, but...
    if ((values = resultValueForKey(conn->connection, "titles", &len)) != NULL) 
    	{
        conn->resultset->columnsReturned = copyIntoArray(conn->resultset->columnNames, values, &(conn->resultset->maxInitializedColumns));
        
        values = resultValueForKey(conn->connection, "tables", &len);
        copyIntoArray(	conn->resultset->tableNames, 
        				values, 
        				&(conn->resultset->maxInitializedTables));
        				
        values = resultValueForKey(conn->connection, "columnTypes", &len);
        strcpy(conn->resultset->targetTypes,values);
        //printf("TYPES = %s\n", conn->resultset->targetTypes);

        if ((values = resultValueForKey(conn->connection, "count", &len)) != NULL) {
            conn->resultset->rowsAffected = atoi(values);
        }

        // clear old bound variable pointers
        for (ct=0; ct < conn->resultset->columnsReturned; ct++){
            conn->resultset->bindVariables[ct] = NULL;
        }

        //get first data block
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            return 0;
        }
    	YIELD_THREAD;
        if (readResult(conn->connection) <= 0) return -1; // failure

        // get result data
        conn->resultset->resultPage->resultData = resultValueForKey(conn->connection, "data", &(conn->resultset->resultPage->resultDataLength));
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            conn->resultset->readMoreResult = 1;
        } else {
            conn->resultset->readMoreResult = 0;
        }
    } else {
        values = resultValueForKey(conn->connection, "parameter", &len);
        conn->resultset->rowsAffected = 0;
        if (values) {
            conn->resultset->rowsAffected = atoi(values);
        }
        
        values = resultValueForKey(conn->connection, "_rowid", &len);
        if (values) {
            strcpy(conn->insertedRowidValue,values);
        }
        
    }
    //printf("rows affected = %d\n",conn->rowsAffected);
    return 1;
}


//This function sends SQL to the server for execution, setting the resultSet as
//warranted. If there is a connection failure then this function will try to 
//re-establish the connection. If a connection cannot be established to the 
//primary server then the secondary (mirrored) server will be tried, if one has 
//been installed.
//There are two possible return values.
//1 success
//0 other errors returned by the server, stored in errorMessage
//[jsh] 11/07/2003 modified to give up on connecting after a few tries.
int ob_executeCommand(OpenBasePtr conn)
{
    int ret = 0;
    int returnCode = 0;
    int tries = 3;
    
    ob_makeCommand(conn, " ");
	
    if (conn->connection == NULL) {
        return 0;
    }
    
    while (1) {
        ret = _ob_executeCommand(conn);
        if (ret == -1) {
            if (!conn->autoReconnectFlag) {
                return 0;
            }
            while (tries) {
                // first reconnect to the original server
                ret = _ob_connectToDatabase(conn, conn->databaseName, 
                    conn->databaseHost,  
                    &returnCode, 0);
                
                if ((ret != 1) && conn->secondaryHost[0] != '\0' && conn->secondaryDatabase[0] != '\0') {
                    // if reconnect fails then connect to the secondary server
                    ret = _ob_connectToDatabase(conn, conn->secondaryDatabase, 
                        conn->secondaryHost,  
                        &returnCode, 1);
                }
            	if (1 == ret) break;
            	if (!--tries) return 0;
            }
        } else {
            break;
        }
    }

    return ret;
}

const char *ob_insertedRowid(OpenBasePtr conn)
{
    return conn->insertedRowidValue;
}



// ----------------------------------------------------------------------------

char *ob_hostName(OpenBasePtr conn)
{
    return conn->databaseHost;
}

// ----------------------------------------------------------------------------

int ob_isColumnNULL(OpenBasePtr conn, int col)
{
    return (int)conn->resultset->resultIsNull[col];
}

// ----------------------------------------------------------------------------

int ob_isCursorColumnNULL(OpenBaseCursorPtr cursor, int col)
{
    return (int)cursor->resultIsNull[col];
}

// ----------------------------------------------------------------------------

const char *ob_loginName(OpenBasePtr conn)
{
    return conn->databaseLogin;
}

// ----------------------------------------------------------------------------

void ob_makeCommandLength(OpenBasePtr conn, const char *cmd, int length)
{
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, cmd, length);
    return;
}

// ----------------------------------------------------------------------------

void ob_makeCommand(OpenBasePtr conn, const char *cmd)
{
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, cmd, strlen(cmd));
    return;
}

// ----------------------------------------------------------------------------


void ob_makeCommandLengthAndEncode(OpenBasePtr conn, const char *cmd, int length)
{
    unsigned char* result = (unsigned char *)ob_convertCharacters(conn->clientEncoding, conn->databaseEncoding, (const unsigned char *)cmd, &length);
    
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, (const char *)result, length);
    free(result);
    return;
}

// ----------------------------------------------------------------------------

void ob_makeCommandAndEncode(OpenBasePtr conn, const char *cmd)
{
    unsigned char* result = NULL;
    int len = strlen(cmd);
    
    result = (unsigned char*)ob_convertCharacters(conn->clientEncoding, conn->databaseEncoding, (const unsigned char *)cmd, &len);
    
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, (const char *)result, len);
    free(result);
}


// ----------------------------------------------------------------------------

int ob_markRow(OpenBasePtr conn, const char *anId, const char *tableName)
{
    char line[150];

    sprintf(line,"lock record %s %s", anId, tableName);		//��dmr sans ''

    ob_makeCommand(conn,line);
    if (!ob_executeCommand(conn)) {
        return 0;
    }

    return 1;
}

// ----------------------------------------------------------------------------

int ob_markRowAlreadyMarkedByUser(OpenBasePtr conn, const char *anId, const char *tableName, char *userName)
{
    char buff[256];

    if(ob_markRow(conn, anId, tableName)) {
        if (userName) {
                userName[0] = '\0';
        }
        return 1;
    }
    // get the userName
    strcpy(buff,ob_serverMessage(conn));
    if (strncmp(buff,"Record already locked by ",25)==0) {
            strcpy(userName, &buff[25]);
    }
    return 0;	//��dmr 1 not 0 // sk, no actually 0 not 1
}

// ----------------------------------------------------------------------------

void _ob_estimateColumnWidths(OpenBasePtr conn)
{
	int readPosition = 0;
	int ct, i;

    for (ct=0; ct < (conn->resultset->columnsReturned+1); ct++) {
    	conn->resultset->columnWidths[ct] = 0;
    }
	while ((readPosition < conn->resultset->resultPage->resultDataLength) && 
			(conn->resultset->resultPage->resultData != NULL)) {
	    for (ct=0; ct < conn->resultset->columnsReturned; ct++) {
	        i = strlen(&(conn->resultset->resultPage->resultData[readPosition]));
	        if (conn->resultset->columnWidths[ct] < i) {
	        	conn->resultset->columnWidths[ct] = i;
	    	}
	    	readPosition = readPosition + strlen(&(conn->resultset->resultPage->resultData[readPosition]))+1;
	    }
    }
    for (ct=0; ct < conn->resultset->columnsReturned; ct++) {
    	if ( conn->resultset->columnWidths[ct] < strlen(conn->resultset->columnNames[ct]) )
    		conn->resultset->columnWidths[ct] = strlen(conn->resultset->columnNames[ct]);
    }

}

// ----------------------------------------------------------------------------

int _ob_widthForColumn(OpenBasePtr conn, int col) 
{
	return conn->resultset->columnWidths[col];
}

// ----------------------------------------------------------------------------
//Each call to this function returns the next available row in the cursor. The 
//values of the row are copied to the bound variables in the bindVariables array 
//using the appropriate data conversions as determined by the bindTargetTypes 
//array. The cursor may only be stepped forward through the result rows. It may 
//not be reset or accessed randomly or stepped backward. Normal operation would 
//be to execute a search using the ob_executeCommand and then step through the 
//result rows via the ob_nextRow function, which calls this one as needed. 
//However, ob_retrieveCursor can be used to return the complete contents of a 
//result that will persist beyond the life of an OpenBase connection. In that 
//case, this function must be used to step through the result rows. Call 
//ob_deallocCursor to dispose of the cursor afterwards.
//There are two possible return values.
//1 next row is returned
//0 no rows left to return
int ob_nextCursorRow(OpenBaseCursorPtr cursor)
{
    int ct, len;
    
    int *bInt;
    double *bfloat;
    long *bL;
    long long *bLL;

    if (!cursor->resultPage->resultData) return 0;
    
    if (cursor->readPosition >= cursor->resultPage->resultDataLength){
        OpenBaseResultDataPtr hold = cursor->resultPage;
        
        cursor->readPosition = 0;
        if (!cursor->resultPage->next) {
            return 0;
        }
        cursor->resultPage = cursor->resultPage->next;
        ob_deallocResultData(hold);
        // now make sure the new data object actually has records
        if (cursor->readPosition >= cursor->resultPage->resultDataLength){
           return 0;
        }
    }

    for (ct=0; ct < cursor->columnsReturned; ct++) {
        cursor->resultIsNull[ct] = 0;
        len = 0;
        if (cursor->bindVariables[ct] != NULL) {
            len = strlen(&(cursor->resultPage->resultData[cursor->readPosition]));
            switch(cursor->bindTargetTypes[ct]) {
                    case 'I':
                        bInt = (int *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bInt = 0;
                        } else {
                            *bInt = atoi(&(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                            //printf("INT VALUE(%d) = %d\n", ct, *bInt);
                        break;
                    case 'Q': // LONG LONG
                        bLL = (long long *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bLL = 0LL;
                        } else {
							//	this is the same either way.
                        	if ((cursor->targetTypes[ct]=='!') || (cursor->targetTypes[ct]=='S'))	// OBTYPE_DATETIME
                        	{
                     	       		*bLL = (long long) (double) atof (&(cursor->resultPage->resultData[cursor->readPosition]));
                     	       		//	keep it as seconds since the NeXT epoch!
                        	} else
                        	{
                            		*bLL = ob_atoll(&(cursor->resultPage->resultData[cursor->readPosition]));
                        	}

                        }
                        break;
                    case 'L':
                        bL = (long *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bL = 0L;
                        } else {
                            *bL = atol(&(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                            //printf("LONG VALUE(%d) = %d\n", ct, *bL);
                        break;
                    case 'F':
                    case '!':
                    case 'S':
                        bfloat = (double *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bfloat = 0.0;
                        } else {
                            *bfloat = atof(&(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->targetTypes[ct]=='M'){
                                *bfloat = *bfloat / 100;
                            }
                        }
                        break;
                    case 'B':
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            strcpy(cursor->bindVariables[ct],"");
                        } else {
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                        break;
                    case 'b':
                        bInt = (int *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bInt = 0;
                        } else {
                            if (atoi(&(cursor->resultPage->resultData[cursor->readPosition])) != 0) {
                                *bInt = 1;
                            } else {
                                *bInt = 0;
                            }
                        }
                        break;
                    case 'C':
                    case 'D':
                    case 'T':
                    default:
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            strcpy(cursor->bindVariables[ct],"");
                        } 
//#if defined(TARGET_OS_MAC)
			else if ((cursor->targetTypes[ct]=='!') || (cursor->targetTypes[ct]=='S'))	// OBTYPE_DATETIME
                    	{
                 	       ob_NSDateTimeToDatetimeString(&(cursor->resultPage->resultData[cursor->readPosition]), cursor->bindVariables[ct], 1);
                    	}
//#endif
			else if (cursor->targetTypes[ct]=='D')
                        {
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->skipConvert == 0)
                            {
                            	//convert_convertFromDate(cursor->bindVariables[ct], 0);
								convert_convertFromDate(cursor->bindVariables[ct], dateFormatType);	//[jsh] 11/07/2003
                            }
                        } else if (cursor->targetTypes[ct]=='T'){
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->skipConvert == 0)
                            {
                            	//convert_convertFromTime(cursor->bindVariables[ct], 0);
								convert_convertFromTime(cursor->bindVariables[ct], timeFormatType);	//[jsh] 11/07/2003
                            }
                        } else if (cursor->targetTypes[ct]=='M'){
                        	if (cursor->skipConvert == 0)
                            {
                            	convert_convertToMoney(ob_atoll(&cursor->resultPage->resultData[cursor->readPosition]), cursor->bindVariables[ct],"$","");
                            }
                            else
                            {
                            	strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            	convert_movePointToLeft(cursor->bindVariables[ct]);
                            }
                        } else {
                            strcpy(cursor->bindVariables[ct],
                                   &(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                        //printf("CHAR VALUE(%d) = %s\n", ct, conn->bindVariables[ct]);
                        break;
    
            }
        } else {
            //printf("BIND VALUE (%d) = NULL\n", ct);
            len = strlen(&(cursor->resultPage->resultData[cursor->readPosition]));
        }
        cursor->readPosition = cursor->readPosition + len + 1; //strlen(&(conn->resultData[conn->readPosition]))+1;
   }
    return 1;
}

// ----------------------------------------------------------------------------
//Use this function to return the complete contents of a result that can persist 
//beyond the life of an OpenBase connection or beyond the context of a particular 
//command execution. Use ob_nextCursorRow to step through the result rows. Call 
//ob_deallocCursor to dispose of the cursor afterwards.
OpenBaseCursorPtr ob_retrieveCursor(OpenBasePtr conn)
{
    char *values;
    int len;
    OpenBaseCursorPtr cursor = conn->resultset;
    //OpenBaseResultData *startData = NULL; //[jsh] 11/07/2003 not used
    OpenBaseResultDataPtr currentData = NULL;
    char *holdData;
    
    cursor->readPosition = 0;

    // reallocate data for datapage
    holdData = (char *)ob_malloc(cursor->resultPage->resultDataLength);
    copyBytes(holdData, cursor->resultPage->resultData, cursor->resultPage->resultDataLength);
    
    // now set the resultData to the copied location
    cursor->resultPage->resultData = holdData;
    cursor->resultPage->resultDataNeedsDealloc = 1;
    
    // before we forget, replace the result set for the main connection;
    conn->resultset = ob_newResult();
    
    // now loop through all of the result pages and retrieve the data
    //startData = cursor->resultPage; //[jsh] 11/07/2003 not used
    currentData = cursor->resultPage;
    while (cursor->readMoreResult) {
        currentData->next = ob_newResultData();
        currentData = currentData->next;
        
        // get next block of data
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            ob_deallocCursor(cursor);
            return NULL;
        }
	    YIELD_THREAD;
        if (readResult(conn->connection) == 0) {
            ob_deallocCursor(cursor);
            return NULL; // failure
        }

        // get result data
        currentData->resultData = resultValueForKey(conn->connection, "data", &(currentData->resultDataLength));
        
        // reallocate data for datapage
        holdData = (char *)ob_malloc(currentData->resultDataLength);
        copyBytes(holdData, currentData->resultData, currentData->resultDataLength);
        
        // now set the resultData to the copied location
        currentData->resultData = holdData;
        currentData->resultDataNeedsDealloc = 1;

        // now see if there is more in the result
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            cursor->readMoreResult = 1;
        } else {
            cursor->readMoreResult = 0;
        }
    }
    
    return cursor;
}

// ----------------------------------------------------------------------------
//Use this function to step through the rows of a result after a call to 
//ob_executeCommand. There is no way to access the result rows except by stepping 
//through them once, one row at a time from the beginning. Use this function only 
//on open connections. If you want to step though a result set after tearing down 
//the connection that fetched it then call ob_retrieveCursor, which will pull the 
//entire result into a cursor in memory; even after disposing of the OpenBase 
//connection. In that case, do not use this function to step through the rows. 
//Instead, use ob_nextCursorRow.
//There are two possible return values.
//1 next row is returned
//0 no rows left to return
int ob_nextRow(OpenBasePtr conn)
{
    char *values;
    int len;
    

    if (!conn->resultset->resultPage->resultData) return 0;
    
    if (!ob_nextCursorRow(conn->resultset)) {
        if (!conn->resultset->readMoreResult) {
            conn->resultset->readPosition = 0;
            return 0;
        }
        
                // get next block of data
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            return 0;
        }
    	YIELD_THREAD;
        if (readResult(conn->connection) == 0) {
            return 0; // failure
        }

        // get result data
        conn->resultset->resultPage->resultData = resultValueForKey(conn->connection, "data", &(conn->resultset->resultPage->resultDataLength));
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            conn->resultset->readMoreResult = 1;
        } else {
            conn->resultset->readMoreResult = 0;
        }
        conn->resultset->readPosition = 0;
        if (!ob_nextCursorRow(conn->resultset)) {
            return 0;
        }
    }
    
    return 1;
}

// ----------------------------------------------------------------------------


char *ob_password(OpenBasePtr conn)
{
    return conn->databasePassword;
}

// ----------------------------------------------------------------------------

int ob_removeMarkOnRow(OpenBasePtr conn, const char *anId, const char *tableName)
{
    char line[150];

    sprintf(line,"unlock record '%s' %s", anId, tableName);

    ob_makeCommand(conn, line);
    if (!ob_executeCommand(conn)) {
        return 0;
    }

    return 1;
}

// ----------------------------------------------------------------------------

int ob_resultColumnCount(OpenBasePtr conn)
{
    return conn->resultset->columnsReturned;
}

// ----------------------------------------------------------------------------

char *ob_resultColumnName(OpenBasePtr conn, int col)
{
    if (col < 0) return NULL;
    if (col >= conn->resultset->columnsReturned) {
        return NULL;
    }
    return conn->resultset->columnNames[col];
}

char *ob_cursorColumnName(OpenBaseCursorPtr cursor, int col)
{
    if (col < 0) return NULL;
    if (col >= cursor->columnsReturned) {
        return NULL;
    }
    return cursor->columnNames[col];
}

// ----------------------------------------------------------------------------

int ob_resultColumnType(OpenBasePtr conn, int col)
{
    if ((col<0) || (col >= conn->resultset->columnsReturned))
            return -1;
    switch(conn->resultset->targetTypes[col]){
	case 'C': return OBTYPE_CHAR;
	case 'I': return OBTYPE_INT;
	case 'F': return OBTYPE_FLOAT;
	case 'L': return OBTYPE_LONG;
	case 'M': return OBTYPE_MONEY;
	case 'D': return OBTYPE_DATE;
	case 'T': return OBTYPE_TIME;
	case 'O': return OBTYPE_OBJECT;
	case '!': return OBTYPE_DATETIME;
	case 'Q': return OBTYPE_LONGLONG;
    case 'b': return OBTYPE_BOOLEAN;	//[jsh] 11/07/2003
    case 'B': return OBTYPE_BINARY;		//[jsh] 11/07/2003
    case 'X': return OBTYPE_OBJECT_TEXT;
    case 'S': return OBTYPE_TIMESTAMP;
    }
    return 0;
}

// ----------------------------------------------------------------------------

int ob_resultReturned(OpenBasePtr conn)
{
    if (conn->resultset->columnsReturned && (conn->resultset->rowsAffected > 0)) {
        return 1;
    }
    return 0;
}

// ----------------------------------------------------------------------------

char *ob_resultTableName(OpenBasePtr conn, int col)
{
    if (col < 0) return NULL;
    if (col >= conn->resultset->columnsReturned) {
        return NULL;
    }
    return conn->resultset->tableNames[col];
}

// ----------------------------------------------------------------------------

int ob_rollbackTransaction(OpenBasePtr conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"ROLLBACK");
    conn->transactionInProgress = 0;

    return ob_executeCommand(conn);
}

// ----------------------------------------------------------------------------

int ob_rowsAffected(OpenBasePtr conn)
{
    return conn->resultset->rowsAffected;
}

// ----------------------------------------------------------------------------

const char *ob_serverMessage(OpenBasePtr conn)
{
    char *values;
    int length;

    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_message");
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }
    YIELD_THREAD;
    if (readResult(conn->connection) == 0) return NULL; // failure

    // get result data
    values = resultValueForKey(conn->connection, "result", &length);
    if (values) {
        return values;
    }
    return "";
}

// ----------------------------------------------------------------------------

const char *ob_uniqueRowIdForTable(OpenBasePtr conn, const char *tblname)
{
    char line[100];

    strcpy(conn->tmp,"");

    sprintf(line,"newid for %s ", tblname);
    ob_clearCommands(conn);
    ob_makeCommand(conn, line);
    if (ob_executeCommand(conn)) {
        ob_bindString(conn,conn->tmp);
        if (ob_nextRow(conn))  {
            return conn->tmp;
        }	
    }
    return "";
}

// ----------------------------------------------------------------------------

const char *ob_uniqueRowIdForTableColumn(	OpenBasePtr conn, 
											const char *tblname, 
											const char *colname)
{
    char line[100];

    strcpy(conn->tmp,"");

    sprintf(line,"newid for %s %s ", tblname, colname);
    ob_clearCommands(conn);
    ob_makeCommand(conn, line);
    if (ob_executeCommand(conn)) {
        ob_bindString(conn,conn->tmp);
        if (ob_nextRow(conn))  {
            return conn->tmp;
        }	
    }
    return NULL; //��dmr
}

const char *ob_insertBLOB(OpenBasePtr conn, const char *data, int size)
{
	return ob_insertBinary(conn, data, size);
}

const char *ob_insertCLOB(OpenBasePtr conn, const char *data, int size)
{
	return ob_insertBinary(conn, data, size);
}
// ----------------------------------------------------------------------------
//Calling this function stores the blob value in the database associated with 
//the open connection. A blob identifier is returned. This identifier is then 
//stored in the object type column in place of the actual blob value. This, of 
//course, necessitates storing the blob first and then inserting or updating 
//the appropriate row. The identifier is a string value owned by the open
//connection. The application must not dispose of it, nor should it attempt to
//use it after disposing of the connection.
const char *ob_insertBinary(OpenBasePtr conn, const char *data, int size)
{
    const char *resultValue;
    int length;

//out ( "1" );
    prepareData(conn->connection, data, size, "", "call_insertFile");
// out ( "2" );
    if (!sendBuffer(conn->connection)){
// out ( "3" );
        _setErrorMessage(conn, ERR_NOSERVER);
        return "";
    }
// out ( "4" );
    YIELD_THREAD;
// out ( "5" );
    if (readResult(conn->connection) == 0) return ""; // failure
// out ( "6" );

    // get result data
    resultValue = resultValueForKey(conn->connection, "result", &length);
// out ( "7" );

    if (!resultValue) return "";
// out ( "8" );
    return resultValue;
}
const char *ob_retrieveBLOB(	OpenBasePtr conn, 
								const char *blobIdentifier, 
								int *returnSize)
{
	return ob_retrieveBinary(conn, blobIdentifier, returnSize);
}

const char *ob_retrieveCLOB(	OpenBasePtr conn, 
								const char *blobIdentifier, 
								int *returnSize)
{
	return ob_retrieveBinary(conn, blobIdentifier, returnSize);
}
// ----------------------------------------------------------------------------
//This function retrieves a blob value from the database associated with the 
//open connection. A blob identifier is required to identify the blob value to 
//retrieve. Normally, the blob identifier is fetched as a value from an object 
//column of a row. returnSize points to a memory location to receive the size of
//the blob value retrieved.
const char *ob_retrieveBinary(	OpenBasePtr conn, 
								const char *blobIdentifier, 
								int *returnSize)
{
    const char *resultValue;

    prepareDictionary(conn->altConnection);
    addDictionaryPair(conn->altConnection, "action", "call_getFile");
    addDictionaryPair(conn->altConnection, "fileKey", blobIdentifier);
    if (!sendBuffer(conn->altConnection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }
    YIELD_THREAD;

    if (readResult(conn->altConnection) == 0) {
        *returnSize = 0;
        return NULL; // failure
    }

    resultValue = resultValueForKey(conn->altConnection, "data", returnSize);
    if (!resultValue) {
        *returnSize = 0;
        return NULL; // failure
    }
    return resultValue;
}

// ----------------------------------------------------------------------------
//This function may be used to dispose of a blob value. Note that this is an
//actual blob value, not a blob identifier.
void ob_deallocBinary(const char * blob)
{
	if(blob)
	{
		ob_free((void *)blob);
	}
}

// ----------------------------------------------------------------------------

