/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "conversion.h"
#include "longlong.h"
#include "OpenBaseSupport.h"
#include "OpenBaseConnection.h"
#include "NetClientLib.h"
#include "CommAPI.h"
#include "API_Header.h"
#include <unistd.h>

#define ERR_SFTUSRLIM	1
#define ERR_DBSUSRLIM	2
#define ERR_DBSLIM		3
#define ERR_DBSDUP		4
#define ERR_NOSERVER	5
#define ERR_INCORRECT_LOGIN	6
#define ERR_SERVER_RESTARTING	7
#define ERR_WEBOBJECTS_VIOLATION 8
#define ERR_LITE_VIOLATION      9

void _setErrorMessage(OpenBase *conn, int errorCode);


OpenBaseResultData *ob_newResultData()
{
    OpenBaseResultData *resultData;
    
    resultData = (OpenBaseResultData *)malloc(sizeof(OpenBaseResultData));
    resultData->resultData = NULL;
    resultData->resultDataLength = 0;
    resultData->next = NULL;
    resultData->resultDataNeedsDealloc = 0;
    return resultData;
}

OpenBaseCursor *ob_newResult()
{
    OpenBaseCursor *resultset;
    
    resultset = (OpenBaseCursor *)malloc(sizeof(OpenBaseCursor));
    
    resultset->readMoreResult = 0;
    resultset->readPosition = 0;
    resultset->columnsReturned = 0;
    resultset->maxVariablesBound = 0;
    resultset->maxInitializedTables = 0;
    resultset->maxInitializedColumns = 0;
    /*for (ct=0; ct < 400 ;ct++) {
        resultset->tableNames[ct] = NULL;
        resultset->columnNames[ct] = NULL;
    }*/
    resultset->skipConvert = 0;
    resultset->resultPage = ob_newResultData();
    resultset->pushedResult = NULL;
    return resultset;
}


OpenBase *ob_newConnection()
{
    OpenBase *conn;
    int ct;
    
    conn = (OpenBase *)malloc(sizeof(OpenBase));
    conn->connection = (NetConn *)malloc(sizeof(NetConn));
	conn->connection->socketConnection = -1;
    conn->connection->didInit = 0;
    conn->connection->dictionaryBuffer = (unsigned char*)malloc(500);
    conn->connection->dictionaryBufferSize = 500;
    conn->connection->readPosition = 0;
    conn->connection->privateEncriptionMap = NULL;
    conn->connection->privateDecriptionMap = NULL;
    
    conn->altConnection = (NetConn *)malloc(sizeof(NetConn));
	conn->altConnection->socketConnection = -1;
    conn->altConnection->didInit = 0;
    conn->altConnection->dictionaryBuffer = (unsigned char*)malloc(500);
    conn->altConnection->dictionaryBufferSize = 500;
    conn->altConnection->readPosition = 0;
    conn->altConnection->privateEncriptionMap = NULL;
    conn->altConnection->privateDecriptionMap = NULL;

    conn->sqlBuffer = (char*)malloc(500);
    conn->sqlBufferSize = 500;

    conn->position = 0;
    
    for (ct=0; ct < 400 ;ct++) {
        conn->preparedSQL[ct] = NULL;
    }

    conn->preparedSQL[0] = NULL;
    conn->resultset = ob_newResult();
    
    return conn;
}

#define DEALLOC(ptr)    if (ptr) { free(ptr); ptr = NULL; }

void ob_invalidate(OpenBase *conn)
{
    if(conn->connection->socketConnection != -1) {
        // SEND EXIT SIGNAL TO NOTIFY SERVER THAT CONNECTION IS CLOSING
        sendExitSignal(conn->connection);
        // CLOSE THE CONNECTION TO THE SERVER
        netClose(conn->connection->socketConnection);
        conn->connection->socketConnection = -1;
    }
    
    if(conn->altConnection->socketConnection != -1) {
        // SEND EXIT SIGNAL TO NOTIFY SERVER THAT CONNECTION IS CLOSING
        sendExitSignal(conn->altConnection);
        // CLOSE THE CONNECTION TO THE SERVER
        netClose(conn->altConnection->socketConnection);
        conn->altConnection->socketConnection = -1;
    }

    DEALLOC(conn->connection->privateEncriptionMap);
    DEALLOC(conn->connection->privateDecriptionMap);
    DEALLOC(conn->altConnection->privateEncriptionMap);
    DEALLOC(conn->altConnection->privateDecriptionMap);
}


void ob_deallocResultData(OpenBaseResultData * resultData){
    
    if (!resultData) return;
    
    if (resultData->resultDataNeedsDealloc) {
        DEALLOC(resultData->resultData);
    }
    DEALLOC(resultData);
}

void ob_deallocResultDataList(OpenBaseResultData * resultData){
    
    if (!resultData) return;
    ob_deallocResultDataList(resultData->next);
    ob_deallocResultData(resultData);
}

void ob_deallocCursor(OpenBaseCursor * cursor){
    int ct;
    
    if (!cursor) return;
    
    for (ct=0; ct < cursor->maxInitializedColumns ;ct++) {
        DEALLOC(cursor->columnNames[ct]);
    }
    for (ct=0; ct < cursor->maxInitializedTables ;ct++) {
        DEALLOC(cursor->tableNames[ct]);
    }
    ob_deallocResultDataList(cursor->resultPage);
    
}

void ob_deallocConnection(OpenBase * conn) {
    if(conn) {
        int ct;
		
        ob_invalidate(conn);
        for (ct=0; ct < 400 ;ct++) {
            DEALLOC(conn->preparedSQL[ct]);
        }
        DEALLOC(conn->connection->dictionaryBuffer);
        DEALLOC(conn->altConnection->dictionaryBuffer);
        DEALLOC(conn->connection);
        DEALLOC(conn->altConnection);
        DEALLOC(conn->sqlBuffer);
        ob_deallocCursor(conn->resultset);
        conn->resultset = NULL;
        free(conn);
    }
}

int ob_beginTransaction(OpenBase *conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"START TRANSACTION");
    return ob_executeCommand(conn);
}

void ob_bindDouble(OpenBase *conn, double *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='F';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;

}

void ob_bindInt(OpenBase *conn, int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='I';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

void ob_bindLongLong(OpenBase *conn, int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='Q';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

void ob_bindLong(OpenBase *conn, long *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='L';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

void ob_bindString(OpenBase *conn, char *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='C';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

void ob_bindBinary(OpenBase *conn, char *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='B';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}

void ob_bindBoolean(OpenBase *conn, int *var)
{
    conn->resultset->bindTargetTypes[conn->resultset->maxVariablesBound]='b';
    conn->resultset->bindVariables[conn->resultset->maxVariablesBound] = (char *)var;
    conn->resultset->maxVariablesBound = conn->resultset->maxVariablesBound + 1;
}


int ob_bufferHasCommands(OpenBase *conn)
{
    if (conn->position) return 1;
    return 0;
}

void ob_clearCommands(OpenBase *conn)
{
    conn->position = 0;
    return;
}

char *ob_commandBuffer(OpenBase *conn)
{
    return conn->sqlBuffer;
}

int ob_commitTransaction(OpenBase *conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"COMMIT");
    return ob_executeCommand(conn);
}

const char *ob_connectErrorMessage(OpenBase *conn )
{
    return conn->resultset->errorMessage;
}

void _setErrorMessage(OpenBase *conn, int errorCode)
{
    conn->resultset->errorMessage = "";
	switch(errorCode) {
	    case ERR_DBSUSRLIM: conn->resultset->errorMessage = "The user limit has been exceeded.  You may need to purchase additional licenses in order to connect to OpenBase. Your action has been aborted. "; break;
	    case ERR_NOSERVER: conn->resultset->errorMessage = "The database specified has not been started or can not be found. Your action has been aborted. "; break;
	    case ERR_INCORRECT_LOGIN: conn->resultset->errorMessage = "Your login and password are not valid for the specified database.  If no passwords have been set in the database you can use the 'root' user with no password."; break;
	    case ERR_WEBOBJECTS_VIOLATION: conn->resultset->errorMessage = "You need to purchase an internet license to use OpenBase with WebObjects.  Please contact OpenBase International at 603-547-8404 for more information. "; break;
	    case ERR_LITE_VIOLATION: conn->resultset->errorMessage = "OpenBase Lite is for single-user deployment only. It is not to be used with software development tools or WebObjects.  Please contact OpenBase at 603-547-8404 to purchase the appropriate license to work with these products.  Thank you."; break;
    }
}

int ob_connectToDatabase(OpenBase *conn, const char *dbName, const char *dbHostName, const char *loginName, const char *passwordString, int *returnCode )
{
    int len;
    char *values;
    char processIdString[50];
    //char hostname[50];
    static int counter = 0;
#ifdef macintosh
#warning compiled for MAC OS 9
    char	*buffer = (char *)malloc (256);
#endif
    // copy in login information
    strcpy(conn->databaseName, dbName);
    strcpy(conn->databaseHost, dbHostName);
    strcpy(conn->databaseLogin, loginName);
    strcpy(conn->databasePassword, passwordString);

    if (strcmp(conn->databaseHost,"") == 0) {
        gethostname(conn->databaseHost, 100);
    }
    
    if (!connectToPort(conn->connection, 20222, conn->databaseHost)) {
		_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
		return 0;
    } 

    // setup block send
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "findPort", conn->databaseName);
//#ifdef macintosh
//	addDictionaryPair(conn->connection, "portHost", MapNameToAddress (conn->databaseHost, buffer));
//#else
	addDictionaryPair(conn->connection, "portHost", conn->databaseHost);
//#endif
	addDictionaryPair(conn->connection, "portType", "none");
    sendBuffer(conn->connection);
    if (!readResult(conn->connection)) {
        //printf("no result returned from nameserver\n");
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    if (!resultValueForKey(conn->connection, "portNumber", &len)) {
        //printf("could not find database\n");
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    // primary connection

    // FOR MAC SYSTEMS NAME RESOLUTION DOESN'T WORK
    //strcpy(conn->databaseHost, resultValueForKey(conn->connection, "portHostAddress", &len));
    
    conn->connection->connectionPort = atoi(resultValueForKey(conn->connection, "portNumber", &len));
    netClose(conn->connection->socketConnection);

    if (!connectToPort(conn->connection, conn->connection->connectionPort, conn->databaseHost)) {
        printf("could not find database\n");
        return 0;
    }
    // secondary connection (for blob transport)
    conn->altConnection->connectionPort = conn->connection->connectionPort;
    if(conn->altConnection->socketConnection != -1) {
	    netClose(conn->altConnection->socketConnection);
	}

    if (!connectToPort(conn->altConnection, conn->altConnection->connectionPort, conn->databaseHost)) {
        printf("could not find database\n");
        return 0;
    }
    
    // setup encryption
    startPrivateTransmission(conn->connection);
    startPrivateTransmission(conn->altConnection);

    sprintf(processIdString,"%s_%d", conn->databaseLogin, counter++);
        
    // log into database
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_register");
    addDictionaryPair(conn->connection, "usersAllowed", "1000");
    addDictionaryPair(conn->connection, "dblogin", conn->databaseLogin);
    addDictionaryPair(conn->connection, "dbpassword", conn->databasePassword);
    addDictionaryPair(conn->connection, "userlogin", conn->databaseLogin);
    addDictionaryPair(conn->connection, "hostName", conn->databaseHost);
    addDictionaryPair(conn->connection, "databaseName", conn->databaseName);
    addDictionaryPair(conn->connection, "softwareId", "php");
    addDictionaryPair(conn->connection, "processId", processIdString);
    if (!sendBuffer(conn->connection)) {
        _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    if (!readResult(conn->connection)) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }

    if ((values = resultValueForKey(conn->connection, "result", &len)) == NULL) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    if (strcmp(values,"succeed") != 0) {
	    if ((values = resultValueForKey(conn->connection, "error", &len)) != NULL) {
	    	_setErrorMessage(conn, atoi(values)); *returnCode = atoi(values);
    	} else {
    	    _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
    	}
        return 0;
    }
    
    // setup max buffer size
#ifdef CARBON_API 
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "setMaxBufferSize");
    addDictionaryPair(conn->connection, "size", "60000");
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
    
    if (!readResult(conn->connection)) {
    	_setErrorMessage(conn, ERR_NOSERVER); *returnCode = ERR_NOSERVER;
        return 0;
    }
#endif
    return 1;
}

char *ob_databaseName(OpenBase *conn)
{
    return conn->databaseName;
}

int ob_abortFetch(OpenBase *conn)
{
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "abort");
    
    // send the command to the server
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }
    if (readResult(conn->connection) == 0) return 0; // failure
    
    return 1;
}



int ob_executeCommand(OpenBase *conn)
{
    int len;
    char *values;
    int ct;
// Fix a problem with the end of the sql query....
	ob_makeCommand(conn, " ");
	
    if (conn->connection == NULL) {
        return 0;
    }

    // check to see if we need to abort the fetch
    if (conn->resultset->readMoreResult) {
        // send abort
        ob_abortFetch(conn);
        conn->resultset->readMoreResult = 0;
    }
    
    conn->position = 0; // restart sql buffer
    conn->resultset->columnsReturned = 0; 
    conn->resultset->rowsAffected = 0;
    conn->resultset->maxVariablesBound = 0;
    conn->resultset->readPosition = 0;

    //printf("ob_executeCommand SQL BUFFER <%s>\n", conn->sqlBuffer);
    
    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_executeSQL");
    addDictionaryPair(conn->connection, "SQLCommand", conn->sqlBuffer);

    // send the command to the server
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }

    if (!conn->connection || (readResult(conn->connection) == 0)) return 0; // failure

    conn->resultset->errorMessage = resultValueForKey(conn->connection, "error", &len);
    if (conn->resultset->errorMessage) {
        // there was an error
        return 0;
    }
    if ((values = resultValueForKey(conn->connection, "tables", &len)) != NULL) {
        conn->resultset->columnsReturned = copyIntoArray(conn->resultset->tableNames,values, &(conn->resultset->maxInitializedTables));
        
        values = resultValueForKey(conn->connection, "titles", &len);
        copyIntoArray(conn->resultset->columnNames,values, &(conn->resultset->maxInitializedColumns));
        
        values = resultValueForKey(conn->connection, "columnTypes", &len);
        strcpy(conn->resultset->targetTypes,values);

        if ((values = resultValueForKey(conn->connection, "count", &len)) != NULL) {
            conn->resultset->rowsAffected = atoi(values);
        }

        // clear old bound variable pointers
        for (ct=0; ct < conn->resultset->columnsReturned; ct++){
            conn->resultset->bindVariables[ct] = NULL;
        }

        //get first data block
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            return 0;
        }
        if (readResult(conn->connection) == 0) return 0; // failure

        // get result data
        conn->resultset->resultPage->resultData = resultValueForKey(conn->connection, "data", &(conn->resultset->resultPage->resultDataLength));
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            conn->resultset->readMoreResult = 1;
        } else {
            conn->resultset->readMoreResult = 0;
        }
    } else {
        values = resultValueForKey(conn->connection, "parameter", &len);
        conn->resultset->rowsAffected = 0;
        if (values) {
            conn->resultset->rowsAffected = atoi(values);
        }
    }
    //printf("rows affected = %d\n",conn->rowsAffected);
    return 1;
}



char *ob_hostName(OpenBase *conn)
{
    return conn->databaseHost;
}

int ob_isColumnNULL(OpenBase *conn, int col)
{
    return (int)conn->resultset->resultIsNull[col];
}

const char *ob_loginName(OpenBase *conn)
{
    return conn->databaseLogin;
}

void ob_makeCommandLength(OpenBase *conn, const char *cmd, int length)
{
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, cmd, length);
    return;
}

void ob_makeCommand(OpenBase *conn, const char *cmd)
{
    conn->position = conn->position +  copyString((unsigned char **)&(conn->sqlBuffer),
                                                  &(conn->sqlBufferSize),
                                                  conn->position, cmd, strlen(cmd));
    return;
}

int ob_markRow(OpenBase *conn, const char *anId, const char *tableName)
{
    char line[150];

    sprintf(line,"lock record '%s' %s", anId, tableName);

    ob_makeCommand(conn,line);
    if (!ob_executeCommand(conn)) {
        return 0;
    }

    return 1;
}

int ob_markRowAlreadyMarkedByUser(OpenBase *conn, const char *anId, const char *tableName, char *userName)
{
    char buff[256];

    if(ob_markRow(conn, anId, tableName)) {
        if (userName) {
                userName[0] = '\0';
        }
        return 1;
    }
    // get the userName
    strcpy(buff,ob_serverMessage(conn));
    if (strncmp(buff,"Record already locked by ",25)==0) {
            strcpy(userName, &buff[25]);
    }
    return 0;
}

void _ob_estimateColumnWidths(OpenBase *conn)
{
	int readPosition = 0;
	int ct, i;

    for (ct=0; ct < (conn->resultset->columnsReturned+1); ct++) {
    	conn->resultset->columnWidths[ct] = 0;
    }
	while (readPosition < conn->resultset->resultPage->resultDataLength) {
	    for (ct=0; ct < conn->resultset->columnsReturned; ct++) {
	        i = strlen(&(conn->resultset->resultPage->resultData[readPosition]));
	        if (conn->resultset->columnWidths[ct] < i) {
	        	conn->resultset->columnWidths[ct] = i;
	    	}
	    	readPosition = readPosition + strlen(&(conn->resultset->resultPage->resultData[readPosition]))+1;
	    }
    }
    for (ct=0; ct < conn->resultset->columnsReturned; ct++) {
    	if ( conn->resultset->columnWidths[ct] < strlen(conn->resultset->columnNames[ct]) )
    		conn->resultset->columnWidths[ct] = strlen(conn->resultset->columnNames[ct]);
    }

}

int _ob_widthForColumn(OpenBase *conn, int col) 
{
	return conn->resultset->columnWidths[col];
}

int ob_nextCursorRow(OpenBaseCursor *cursor)
{
    int ct, len;
    
    int *bInt;
    double *bfloat;
    long *bL;
    long long *bLL;

    if (!cursor->resultPage->resultData) return 0;
    
    if (cursor->readPosition >= cursor->resultPage->resultDataLength){
        OpenBaseResultData *hold = cursor->resultPage;
        
        cursor->readPosition = 0;
        if (!cursor->resultPage->next) {
            return 0;
        }
        cursor->resultPage = cursor->resultPage->next;
        ob_deallocResultData(hold);
        // now make sure the new data object actually has records
        if (cursor->readPosition >= cursor->resultPage->resultDataLength){
           return 0;
        }
    }

    for (ct=0; ct < cursor->columnsReturned; ct++) {
        cursor->resultIsNull[ct] = 0;
        len = 0;
        if (cursor->bindVariables[ct] != NULL) {
            len = strlen(&(cursor->resultPage->resultData[cursor->readPosition]));
            switch(cursor->bindTargetTypes[ct]) {
                    case 'I':
                        bInt = (int *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bInt = 0;
                        } else {
                            *bInt = atoi(&(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                            //printf("INT VALUE(%d) = %d\n", ct, *bInt);
                        break;
                    case 'Q': // LONG LONG
                        bLL = (long long *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bLL = 0LL;
                        } else {
                            *bLL = ob_atoll(&(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                        break;
                    case 'L':
                        bL = (long *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bL = 0L;
                        } else {
                            *bL = atol(&(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                            //printf("LONG VALUE(%d) = %d\n", ct, *bL);
                        break;
                    case 'F':
                    case '!':
                        bfloat = (double *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bfloat = 0.0;
                        } else {
                            *bfloat = atof(&(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->targetTypes[ct]=='M'){
                                *bfloat = *bfloat / 100;
                            }
                        }
                        break;
                    case 'B':
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            strcpy(cursor->bindVariables[ct],"");
                        } else {
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                        break;
                    case 'b':
                        bInt = (int *)cursor->bindVariables[ct];
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            *bInt = 0;
                        } else {
                            if (atoi(&(cursor->resultPage->resultData[cursor->readPosition])) != 0) {
                                *bInt = 1;
                            } else {
                                *bInt = 0;
                            }
                        }
                        break;
                    case 'C':
                    case 'D':
                    case 'T':
                    default:
                        if (IS_NULL_VALUE(&cursor->resultPage->resultData[cursor->readPosition])) {
                            cursor->resultIsNull[ct] = 1;
                            strcpy(cursor->bindVariables[ct],"");
                        } else if (cursor->targetTypes[ct]=='D')
                        {
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->skipConvert == 0)
                            {
                            	convert_convertFromDate(cursor->bindVariables[ct], 0);
                            }
                        } else if (cursor->targetTypes[ct]=='T'){
                            strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            if (cursor->skipConvert == 0)
                            {
                            	convert_convertFromTime(cursor->bindVariables[ct], 0);
                            }
                        } else if (cursor->targetTypes[ct]=='M'){
                        	if (cursor->skipConvert == 0)
                            {
                            	convert_convertToMoney(ob_atoll(&cursor->resultPage->resultData[cursor->readPosition]), cursor->bindVariables[ct],"$","");
                            }
                            else
                            {
                            	strcpy(cursor->bindVariables[ct], &(cursor->resultPage->resultData[cursor->readPosition]));
                            	convert_movePointToLeft(cursor->bindVariables[ct]);
                            }
                        } else {
                            strcpy(cursor->bindVariables[ct],
                                   &(cursor->resultPage->resultData[cursor->readPosition]));
                        }
                        //printf("CHAR VALUE(%d) = %s\n", ct, conn->bindVariables[ct]);
                        break;
    
            }
        } else {
            //printf("BIND VALUE (%d) = NULL\n", ct);
            len = strlen(&(cursor->resultPage->resultData[cursor->readPosition]));
        }
        cursor->readPosition = cursor->readPosition + len + 1; //strlen(&(conn->resultData[conn->readPosition]))+1;
   }
    return 1;
}

OpenBaseCursor *ob_retrieveCursor(OpenBase *conn)
{
    char *values;
    int len;
    OpenBaseCursor *cursor = conn->resultset;
    OpenBaseResultData *startData = NULL;
    OpenBaseResultData *currentData = NULL;
    char *holdData;
    
    cursor->readPosition = 0;

    // reallocate data for datapage
    holdData = (char *)malloc(cursor->resultPage->resultDataLength);
    copyBytes(holdData, cursor->resultPage->resultData, cursor->resultPage->resultDataLength);
    
    // now set the resultData to the copied location
    cursor->resultPage->resultData = holdData;
    cursor->resultPage->resultDataNeedsDealloc = 1;
    
    // before we forget, replace the result set for the main connection;
    conn->resultset = ob_newResult();
    
    // now loop through all of the result pages and retrieve the data
    startData = cursor->resultPage;
    currentData = cursor->resultPage;
    while (cursor->readMoreResult) {
        currentData->next = ob_newResultData();
        currentData = currentData->next;
        
        // get next block of data
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            ob_deallocCursor(cursor);
            return NULL;
        }
        if (readResult(conn->connection) == 0) {
            ob_deallocCursor(cursor);
            return NULL; // failure
        }

        // get result data
        currentData->resultData = resultValueForKey(conn->connection, "data", &(currentData->resultDataLength));
        
        // reallocate data for datapage
        holdData = (char *)malloc(currentData->resultDataLength);
        copyBytes(holdData, currentData->resultData, currentData->resultDataLength);
        
        // now set the resultData to the copied location
        currentData->resultData = holdData;
        currentData->resultDataNeedsDealloc = 1;

        // now see if there is more in the result
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            cursor->readMoreResult = 1;
        } else {
            cursor->readMoreResult = 0;
        }
    }
    
    return cursor;
}

int ob_nextRow(OpenBase *conn)
{
    char *values;
    int len;
    

    if (!conn->resultset->resultPage->resultData) return 0;
    
    if (!ob_nextCursorRow(conn->resultset)) {
        if (!conn->resultset->readMoreResult) {
            conn->resultset->readPosition = 0;
            return 0;
        }
        
                // get next block of data
        prepareDictionary(conn->connection);
        addDictionaryPair(conn->connection, "action", "ready");
        if (!sendBuffer(conn->connection)){
            _setErrorMessage(conn, ERR_NOSERVER);
            return 0;
        }
        if (readResult(conn->connection) == 0) {
            return 0; // failure
        }

        // get result data
        conn->resultset->resultPage->resultData = resultValueForKey(conn->connection, "data", &(conn->resultset->resultPage->resultDataLength));
        values = resultValueForKey(conn->connection, "action", &len);
        if (values && (strcmp(values,"more") == 0)) {
            conn->resultset->readMoreResult = 1;
        } else {
            conn->resultset->readMoreResult = 0;
        }
        conn->resultset->readPosition = 0;
        if (!ob_nextCursorRow(conn->resultset)) {
            return 0;
        }
    }
    
    return 1;
}

char *ob_password(OpenBase *conn)
{
    return conn->databasePassword;
}

int ob_removeMarkOnRow(OpenBase *conn, const char *anId, const char *tableName)
{
    char line[150];

    sprintf(line,"unlock record '%s' %s", anId, tableName);

    ob_makeCommand(conn, line);
    if (!ob_executeCommand(conn)) {
        return 0;
    }

    return 1;
}

int ob_resultColumnCount(OpenBase *conn)
{
    return conn->resultset->columnsReturned;
}

char *ob_resultColumnName(OpenBase *conn, int col)
{
    if (col < 0) return NULL;
    if (col >= conn->resultset->columnsReturned) {
        return NULL;
    }
    return conn->resultset->columnNames[col];
}

int ob_resultColumnType(OpenBase *conn, int col)
{
    if ((col<0) || (col >= conn->resultset->columnsReturned))
            return -1;
    switch(conn->resultset->targetTypes[col]){
            case 'C': return 1;
            case 'I': return 2;
            case 'F': return 3;
            case 'L': return 4;
            case 'M': return 5;
            case 'D': return 6;
            case 'T': return 7;
            case 'O': return 8;
            case '!': return 9;
            case 'Q': return 10;
            case 'b': return 11;
            case 'B': return 12;
    }
    return 0;
}

int ob_resultReturned(OpenBase *conn)
{
    if (conn->resultset->columnsReturned && (conn->resultset->rowsAffected > 0)) {
        return 1;
    }
    return 0;
}

char *ob_resultTableName(OpenBase *conn, int col)
{
    if (col < 0) return NULL;
    if (col >= conn->resultset->columnsReturned) {
        return NULL;
    }
    return conn->resultset->tableNames[col];
}

int ob_rollbackTransaction(OpenBase *conn)
{
    ob_clearCommands(conn);
    ob_makeCommand(conn,"ROLLBACK");
    return ob_executeCommand(conn);
}

int ob_rowsAffected(OpenBase *conn)
{
    return conn->resultset->rowsAffected;
}

const char *ob_serverMessage(OpenBase *conn)
{
    char *values;
    int length;

    prepareDictionary(conn->connection);
    addDictionaryPair(conn->connection, "action", "call_message");
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }
    if (readResult(conn->connection) == 0) return NULL; // failure

    // get result data
    values = resultValueForKey(conn->connection, "result", &length);
    if (values) {
        return values;
    }
    return "";
}

const char *ob_uniqueRowIdForTable(OpenBase *conn, const char *tblname)
{
    char line[100];

    strcpy(conn->tmp,"");

    sprintf(line,"newid for %s ", tblname);
    ob_clearCommands(conn);
    ob_makeCommand(conn, line);
    if (ob_executeCommand(conn)) {
        ob_bindString(conn,conn->tmp);
        if (ob_nextRow(conn))  {
            return conn->tmp;
        }	
    }
    return "";
}

const char *ob_uniqueRowIdForTableColumn(OpenBase *conn, const char *tblname, const char *colname)
{
    char line[100];

    strcpy(conn->tmp,"");

    sprintf(line,"newid for %s %s ", tblname, colname);
    ob_clearCommands(conn);
    ob_makeCommand(conn, line);
    if (ob_executeCommand(conn)) {
        ob_bindString(conn,conn->tmp);
        if (ob_nextRow(conn))  {
            return conn->tmp;
        }	
    }
    return "";
}

const char *ob_insertBinary(OpenBase *conn, const char *data, int size)
{
    const char *resultValue;
    int length;

    prepareData(conn->connection, data, size, "", "call_insertFile");
    if (!sendBuffer(conn->connection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return "";
    }
    if (readResult(conn->connection) == 0) return ""; // failure

    // get result data
    resultValue = resultValueForKey(conn->connection, "result", &length);

    if (!resultValue) return "";
    return resultValue;
}

const char *ob_retrieveBinary(OpenBase *conn, const char *blobIdentifier, int *returnSize)
{
    const char *resultValue;

    prepareDictionary(conn->altConnection);
    addDictionaryPair(conn->altConnection, "action", "call_getFile");
    addDictionaryPair(conn->altConnection, "fileKey", blobIdentifier);
    if (!sendBuffer(conn->altConnection)){
        _setErrorMessage(conn, ERR_NOSERVER);
        return 0;
    }

    if (readResult(conn->altConnection) == 0) {
        *returnSize = 0;
        return NULL; // failure
    }

    resultValue = resultValueForKey(conn->altConnection, "data", returnSize);
    if (!resultValue) {
        *returnSize = 0;
        return NULL; // failure
    }
    return resultValue;
}
