/* CommAPI.h created by root on Sun 11-Jan-1998 */

#include <stdio.h>
#include "OpenBaseConnection.h"

#define COMM_VERSION "2.0"

char* MapAddressToName ( char* ipAddress, char* domainName );
char* MapNameToAddress ( char* domainName, char* ipAddress );

int connectToPort(NetConn *conn, int portNumber,char *hostName);

void initComm(NetConn *conn);
void clearComm(NetConn *conn);

// SENDING INFORMATION TO SERVER
int prepareData(NetConn *conn, const char *data, int datalen, const char *parameter, const char *action);

void prepareDictionary(NetConn *conn);
void addDictionaryPair(NetConn *conn, const char *key, const char *value);
int sendBuffer(NetConn *conn);

// GETTING INFORMATION FROM SERVER
int readResult(NetConn *conn);
char *resultValueForKey(NetConn *conn, const char *key, int *valuelength);

// COMMUNICATION VERSION - not to be called directly
int syncronizeVersion(NetConn *conn);

// SEND EXIT SIGNAL TO SERVER PORT
void sendExitSignal(NetConn *conn);

// PRIVATE TRANSMISSIONS
void startPrivateTransmission(NetConn *conn);