// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------

#ifndef __COMMAPI_H__
#define __COMMAPI_H__

#include "OpenBaseConnection.h"

#define COMM_VERSION "2.0"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef MACOS_CARBON
	char *MapAddressToName ( char* ipAddress, char* domainName, OTClientContextPtr outClientContext);
	char *MapNameToAddress ( char* domainName, char* ipAddress, OTClientContextPtr outClientContext);
#endif

#ifdef WINNT
	char *MapNameToAddress ( char* domainName, char* ipAddress );
#endif


void 	addDictionaryPair(NetConnPtr conn, const char *key, const char *value);
void 	clearComm(NetConnPtr conn);
int 	connectToPort(NetConnPtr conn, int portNumber, const char *hostName);
int 	ob_copyAndFixString(unsigned char **tostring, int *tosize, int position, 
						 const unsigned char *str, int length, unsigned char *codedmap);
void 	initComm(NetConnPtr conn);
void 	ob_bytesToInt(int *number, unsigned char *buffer);
void 	ob_intToBytes(unsigned char *buffer, int number);

		/* SENDING INFORMATION TO SERVER */
int 	prepareData(NetConnPtr conn, const char *data, int datalen, 
					const char *parameter, const char *action);
void 	prepareDictionary(NetConnPtr conn);

		/* GETTING INFORMATION FROM SERVER */
int		readResult(NetConnPtr conn);
char*	resultValueForKey(NetConnPtr conn, const char *key, int *valuelength);
int 	sendBuffer(NetConnPtr conn);

		/* SEND EXIT SIGNAL TO SERVER PORT */
void 	sendExitSignal(NetConnPtr conn);

		/* PRIVATE TRANSMISSIONS */
void 	startPrivateTransmission(NetConnPtr conn);

		/* COMMUNICATION VERSION - not to be called directly */
int 	syncronizeVersion(NetConnPtr conn);


#ifdef __cplusplus
	}
#endif

// ------------------------------------------------------------------------------------
#endif // __COMMAPI_H__
