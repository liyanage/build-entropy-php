// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------

void initDateTime();
//void initGMTOffset(int gmtadjustment);

char *OB_formatDate(double datevalue, char *buffer);
double dateToFloat(char *buffer);
