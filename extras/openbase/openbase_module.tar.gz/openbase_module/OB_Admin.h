/*
	OB_Admin.h
	OpenBase Unified Client
	�1996-2002 OpenBase International, Ltd.
	All rights reserved
	
	Derived from OpenBaseAdmin.h by Scott Keith.

	Disclaimer:
	-----------
	THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF 
	ANY KIND, EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT 
	LIMITATION THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF 
	THIS SOFTWARE. OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY 
	DEFECT IN, THIS SOFTWARE. IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, 
	SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE 
	POSSIBILITY OF SUCH DAMAGE.

	WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE 
	OPENBASE API SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#ifndef _OB_ADMIN_H
#define _OB_ADMIN_H

#ifdef __cplusplus
extern "C" {
#endif

//================================================================================
//	Includes
//================================================================================

	#ifndef _OB_API_HEADER_H
	#include "API_Header.h"
	#endif

	#ifndef _OB_COMMUNICATIONS_H
	#include "CommAPI.h"
	#endif

//================================================================================
//	Structures
//================================================================================

//--------------------------------------------------------------------------------
//	OpenBaseAdminConnection
//--------------------------------------------------------------------------------

typedef struct OpenBaseAdminConnectionStruct
{
	NetConn *connection;
} OpenBaseAdminConnection;

//--------------------------------------------------------------------------------
//	OpenBaseDatabaseList
//--------------------------------------------------------------------------------

typedef struct OpenBaseDatabaseListStruct
{
	char*	databases[OB_MAX_DATABASES];
	char*	hosts[OB_MAX_DATABASES];
	char*	keys[OB_MAX_DATABASES];
	int		databaseCount;
} OpenBaseDatabaseList;

//================================================================================
//	Functions
//================================================================================

//--------------------------------------------------------------------------------
//	Connecting and Disconnecting
//--------------------------------------------------------------------------------

	// connecting to the openexec process
	OpenBaseAdminConnection* oba_newAdminConnection(const char *hostName);

	// destroying the connection to the openexec process
	void oba_deallocAdminConnection(OpenBaseAdminConnection* admin_conn);

//--------------------------------------------------------------------------------
//	performing admin functions with the openexec process
//--------------------------------------------------------------------------------
	
	//	get the database list
	//	group_code is currently ignored
	//	caller must deallocate result with oba_deallocDatabaseList
	OpenBaseDatabaseList* oba_getDatabaseList(OpenBaseAdminConnection* admin_conn, const char* group_code);
	
	//	free the result
	void oba_deallocDatabaseList(OpenBaseDatabaseList* database_list);
	
	//	i don't understand the group code stuff	
	int oba_addDatabaseToGroupCode(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *groupCode, const char *password);

	int oba_startDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password);
	int oba_newDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password);
	int oba_duplicateDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *duplicatedName,  const char *password);
	int oba_renameDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *newDatabaseName, const char *password);
	int oba_moveDatabase(OpenBaseAdminConnection *adminConnection, const char *sourceDatabaseName, const char *sourcePassword, const char *targetHost, const char *targetHostPassword);
	int oba_deleteDatabase(OpenBaseAdminConnection *adminConnection, const char *databaseName, const char *password);

	int oba_checkPassword(OpenBaseAdminConnection *adminConnection, const char *password);
	int oba_setPassword(OpenBaseAdminConnection *adminConnection, const char *oldpassword, const char *newpassword);

#ifdef __cplusplus
}
#endif

#endif
