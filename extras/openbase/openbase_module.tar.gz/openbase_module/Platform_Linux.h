#define LINUX_UNIX		1
#define MOSX_UNIX		1

#include "platform.h"