// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
#include "platform.h"

#ifdef OBTRANSLATOR
#import "OBFoundation.h"
#else

#ifdef WINNT
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wtypes.h>
#else
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#endif

#endif

#include "OB_Memory.h"

#include "stringConversion.h"

static int mapquoted_encode[256];

static int mapsql_encode[256];
static int mapsql_decode[256];
static int sqlcoderDidInit = 0;

void initSQLCodeString()
{
    int ct;

    for (ct=0; ct < 256; ct++) {
        mapsql_encode[ct] = -1;
        mapsql_decode[ct] = -1;
    }

    mapsql_encode[0] = '0';
    mapsql_decode['0'] = '\0';

    for (ct=0; ct < 256; ct++) {
        mapquoted_encode[ct] = -1;
        switch((char)ct) {
            case '\n':
                mapquoted_encode[ct] = 'n';
                break;
            case '\r':
                mapquoted_encode[ct] = 'r';
                break;
            case '\t':
                mapquoted_encode[ct] = 't';
                break;
            case '\'':
                mapquoted_encode[ct] = '\'';
                break;
            case '\\':
                mapquoted_encode[ct] = '\\';
                break;
        }
    }


    sqlcoderDidInit = 1;
    return;

}

void encodeQUOTEDString(const unsigned char *string, unsigned char *buffer, int len)
{
    const unsigned char *pos;
    unsigned char *result;

    if (!sqlcoderDidInit) initSQLCodeString();

    pos = string;
    result = buffer;
    while ((len > 0) && (*pos != '\0')) {
        if (mapquoted_encode[*pos] == -1) {
            *result = *pos;
        } else if (mapquoted_encode[*pos] == -2) {
            sprintf((char *)result,"\\%03d",(int)*pos); result = result + 3; 
        } else {
            *result = '\\'; result++;
            *result = mapquoted_encode[*pos]; 
        }
        
        len--; result++; pos++;
    }
    *result= '\0';
}

void encodeSQLString(const unsigned char *string, unsigned char *buffer, int len)
{
    const unsigned char *pos;
    unsigned char *result;

    if (!sqlcoderDidInit) initSQLCodeString();

    pos = string;
    result = buffer;
    while (len > 0) {
        *result = *pos;
        if (mapsql_encode[*pos] != -1) {
            *result = '\\'; result++;
            *result = mapsql_encode[*pos]; 
        }
        len--; result++; pos++;
    }
    *result= '\0';
}

void encodeSQLStringConvertSlashes(const unsigned char *string, unsigned char *buffer, int len)
{
    const unsigned char *pos;
    unsigned char *result;

    if (!sqlcoderDidInit) initSQLCodeString();

    pos = string;
    result = buffer;
    while (len > 0) {
        *result = *pos;
        if (*pos == '\\') {
            result++;
            *result = '\\';
        } else if (mapsql_encode[*pos] != -1) {
            *result = '\\'; result++;
            *result = mapsql_encode[*pos];
        }
        len--; result++; pos++;
    }
    *result= '\0';
}


void decodeSQLString(const unsigned char *string, unsigned char *buffer, int *len)
{
    const unsigned char *pos;
    unsigned char *result;

    if (!sqlcoderDidInit) initSQLCodeString();

    *len = 0;
    pos = string;
    result = buffer;

    while (*pos != '\0') {
        if ((*pos == '\\') && (mapsql_decode[*(pos+1)] != -1))  {
            pos++;
            *result = mapsql_decode[*pos];
        } else {
            *result = *pos;
        }
        *len = *len + 1; result++; pos++;
    }
    *result= '\0';
}




