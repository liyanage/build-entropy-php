/*
   Copyright (c) 2000 OpenBase International, Ltd.
   All rights reserved.

   THIS SOFTWARE IS FURNISHED ON AN "AS-IS" BASIS. OPENBASE MAKES NO WARRANTIES OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, AS TO ANY MATTER WHATSOEVER, INCLUDING WITHOUT LIMITATION
   THE CONDITION, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE OF THIS SOFTWARE.
   OPENBASE DOES NOT ASSUME ANY LIABILITY REGARDING USE OF, OR ANY DEFECT IN, THIS SOFTWARE.
   IN NO EVENT SHALL OPENBASE BE LIABLE FOR ANY INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
   DAMAGES, EVEN IF IT HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   WARNING: MODIFY THIS SOURCE CODE AT YOUR OWN RISK.  IF YOU DON'T NEED TO MODIFY THE OPENBASE API
   SOURCE, WE RECOMMEND THAT YOU USE THE COMPILED LIBRARIES.
*/

#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <ctype.h>

#include "longlong.h"

#define	NO	0
#define YES	1

#define NXIsDigit(c)	isdigit(c)
#define NXIsXDigit(c)	isxdigit(c)


long long ob_llabs(long long value)
{
	if (value & MINLONGLONG) {
		return (value ^ MAXULONGLONG) + 1LL;
	}
	return value;
}

long long ob_atoll(const char *aString)
{
	int		x;
	long long	num = 0;
	int	neg = NO;
	
	for (x = 0; aString[x] && !(NXIsDigit(aString[x]) || (aString[x] == '-')); x++) ;
	for (x = 0; aString[x]; x++) {
		if (aString[x] == '-') {
			neg = YES;
		} else {
			num = num * 10LL + (aString[x] - '0');
		}
	}
	
	if (neg) return -num;
	return num;
}

long long ob_ahextoll(const char *aString)
{
	int		x;
	long long	num = 0;
	int	neg = NO;
	
	if (!aString) {
		return 0LL;
	}
	if (aString[0] == '-') {
		aString++;
		neg = YES;
	}
	
	if ((aString[0] == '0') && (aString[1] == 'x')) {
		aString = aString + 2;
	}
	
	for (x = 0; aString[x] && NXIsXDigit(aString[x]); x++) {
		if (NXIsDigit(aString[x])) {
			num = num * 16LL + (aString[x] - '0');
		} else {
			num = num * 16LL + (aString[x] - 'a' + 10);
		}
	}
	if (neg) return -num;
	return num;
}


void ob_lltoa(long long aNum, char *aString)
{
	ob_lltoas(aNum, aString, 0);
}


void ob_lltoas(long long aNum, char *aString, int separator)
{
	static char		buffer[40];
	static int			len, x;
	static int		neg;
	
	if (aNum & MINLONGLONG) {
		if (aNum == MINLONGLONG) {
			// Since Min Long Long throws all conversions off.
			if (separator) {
				sprintf(aString, "-9%c223%c372%c036%c854%c775%c808",
								separator, separator, separator,
								separator, separator, separator);
			} else {
				strcpy(aString, "-9223372036854775808");
			}
			return;
		}
		aNum = ob_llabs(aNum);
		neg = YES;
	} else {
		neg = NO;
	}

	if (aNum) {
		for (x = 0; aNum != 0LL; x++) {
			buffer[x] = '0' + (aNum % 10LL);
			aNum /= 10LL;
			if (separator && aNum && ((x - 2) % 4 == 0)) {
				x++;
				buffer[x] = separator;
			}
		}
	} else {
		buffer[0] = '0';
		x = 1;
	}
	
	if (neg) {
		buffer[x++] = '-';
	}
	buffer[x] = '\0';
	len = strlen(buffer);
	for (x = 0; x < len; x++) {
		aString[x] = buffer[len - x - 1];
	}
	aString[x] = '\0';
}

