#include "platform.h"

#ifdef __cplusplus
extern "C" {
#endif

#if MACOSX_UNIX || WINNT || LINUX || SOLARIS || RHAPSODY

	int  netConnect(int port, const char *hostName);
	void netClose(unsigned int socket);
	int  netSndRaw(unsigned char *rawdata, size_t len, int socket);
	long netRcvToken(unsigned char **buffer, int *bufsize, int socket, unsigned char *decodemap, int *flag);

	int  ob_socketread(int socketFD, unsigned char *buffer, size_t byteCount, int *flag);

	int  copyAndFixString(unsigned char **tostring, int *tosize, int position, const unsigned char *str, int length, unsigned char *codedmap);

	void ob_intToBytes(unsigned char *buffer, int number);
	void ob_bytesToInt(int *number, unsigned char *buffer);

#endif 

#if MACOS_CARBON 

	EndpointRef netConnect(	int inServerPort, const char * inServerName, OTClientContextPtr outClientContext);
	void netClose(EndpointRef inEndpoint);
	int  netSndRaw (	unsigned char* 	inRawdata, size_t inLength, EndpointRef inEndpoint);
	long netRcvToken (UInt8 **buffer, int *bufsize, EndpointRef inEndpoint, UInt8 *decodemap, int *flag) ;
						
	int ob_socketread(EndpointRef inEndpoint, void* ioBuffer, size_t inByteCount, int *flag);

	void ob_intToBytes(unsigned char *buffer, int number) ;
	void ob_bytesToInt(int *number, unsigned char *buffer) ;

#endif

#ifdef __cplusplus
	}
#endif

