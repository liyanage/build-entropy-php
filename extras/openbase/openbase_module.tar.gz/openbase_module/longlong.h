// ------------------------------------------------------------------------------
// 
// Copyright (c) 1996-2006 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------

#ifndef __LONGLONG_H__
#define __LONGLONG_H__

#ifdef __cplusplus
	extern "C" {
#endif

#define MAXLONGLONG			((long long)0x7FFFFFFFFFFFFFFFLL)
#define MINLONGLONG			((long long)0x8000000000000000LL)
#define MAXULONGLONG		((unsigned long long)0xFFFFFFFFFFFFFFFFLL)

#ifndef LONGLONG
#define LONGLONG long long
#endif

long long 	ob_atoll(const char *aString);
long long 	ob_ahextoll(const char *aString);
long long 	ob_llabs(long long value);	

void 		ob_lltoa(long long aNum, char *aString);
void 		ob_lltoas(long long aNum, char *aString, int separator);

#ifdef __cplusplus
	}
#endif

#endif // __LONGLONG_H__