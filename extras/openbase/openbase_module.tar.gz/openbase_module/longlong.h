//  Copyright 1996, Openbase International Ltd.
//  All rights reserved.

#define MAXLONGLONG			((long long)0x7FFFFFFFFFFFFFFFLL)
#define MINLONGLONG			((long long)0x8000000000000000LL)
#define MAXULONGLONG		((unsigned long long)0xFFFFFFFFFFFFFFFFLL)

long long ob_atoll(const char *aString);
long long ob_ahextoll(const char *aString);
void ob_lltoa(long long aNum, char *aString);
void ob_lltoas(long long aNum, char *aString, int separator);
long long ob_llabs(long long value);
