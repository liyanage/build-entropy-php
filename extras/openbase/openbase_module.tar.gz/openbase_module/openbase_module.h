#ifndef _OPENBASE_MODULE_H
#define _OPENBASE_MODULE_H

extern zend_module_entry openbase_module_entry;

#define phpext_openbase_module_ptr &openbase_module_entry

#endif /* _OPENBASE_MODULE_H */
