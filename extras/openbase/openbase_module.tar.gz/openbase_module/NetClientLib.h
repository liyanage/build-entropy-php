// ------------------------------------------------------------------------------
// 
// Copyright (c) 2004 OpenBase International Ltd.
// All rights reserved.
//
// ------------------------------------------------------------------------------
//
//	FILE:	NetClientLib.h
//
//	CREATION DATE:	12 mars 1999
//
// ------------------------------------------------------------------------------

#ifndef __NETCLIENTLIB_H__
#define __NETCLIENTLIB_H__

#ifdef MACOS_CARBON
	#include <size_t.h>
#endif

#include "OpenBaseConnection.h"


#ifdef __cplusplus
	using namespace std;
	extern "C" {
#endif

#ifdef MACOS_CARBON
	#include <OpenTransport.h>
	#include <OpenTptInternet.h>

	#include "MacCarbon_NetClient.h"
#endif

#ifdef __cplusplus
	}
#endif


#endif // __NETCLIENTLIB_H__
