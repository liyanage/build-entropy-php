#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

int netConnect(int port, const char *hostName);
void netClose(unsigned int socket);
int copyAndFixString(unsigned char **tostring, int *tosize, int position, const unsigned char *str, int length, unsigned char *codedmap);
int netSndRaw(unsigned char *rawdata, size_t len, int socket);
long netRcvToken(unsigned char **buffer, int *bufsize, int socket, unsigned char *decodemap);

int ob_socketread(int socketFD, unsigned char *buffer, size_t byteCount);

void ob_intToBytes(unsigned char *buffer, int number);
void ob_bytesToInt(int *number, unsigned char *buffer);