/* OpenBaseSupport.h created by root on Wed 14-Jan-1998 */
int copyIntoArray(char *array[],char *values, int *maxinit);

int copyString(unsigned char **tostring, int *tosize, int position, const char *str, int length);
int copyToIndex(char **tostring, int *tosize, int position, const char *str, const char tochar, int *isDone);

int copyBytes(char *destination, const char *source, int size);
